#ifndef PROJ_2
#define PROJ_2

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/mman.h>

#define LOCKED 0
#define UNLOCKED 1
#define HACKER 0
#define SERF 1
#define MEMBER 1
#define CAPTAIN 2

typedef struct{
    int p;   
    int h;    
    int s;   
    int r;      
    int w;
    int c;
} parametrs;

int init();
int clean();
void destroy(int sig);
int counter(int *x, int y);
int condition();
void free_sem(sem_t *sem_target, int free_seat);
int fork_build(FILE *fp, parametrs *pm, int time, int category);
void fork_children(FILE *fp, parametrs *pm, int category, int a, int *shared);
void boarding(int *seat, sem_t *sem_target, int free_seat, int num);

#endif //PROJ_2