#include "proj2.h"

//inicializace sdílených proměných a semaforů
sem_t
        *sem_counter = NULL,
        *sem_log = NULL, 
        *sem_hacker_wait = NULL,
        *sem_serf_wait = NULL, 
        *sem_landing = NULL;

int
        *sharedCounter,
        *sharedCat[2],
        *sharedPier,
        *sharedSEAT;

int
        shm_fd0,     
        shm_fd1,       
        shm_fd2,          
        shm_fd3,
        shm_fd4; 

FILE *fp = NULL;

const char *CATEGORY[] =
{
    [HACKER] = "HACK",
    [SERF] = "SERF",
};

int init() {

    int chyba = 0;

    if (    ((sem_counter = sem_open("/xzakji02_semafor_counter", O_CREAT | O_EXCL, 0644, UNLOCKED)) == SEM_FAILED)
            || ((sem_log = sem_open("/xzakji02_semafor_log", O_CREAT | O_EXCL, 0644, UNLOCKED)) == SEM_FAILED)
            || ((sem_hacker_wait = sem_open("/xzakji02_semafor_hacker_wait", O_CREAT | O_EXCL, 0644, LOCKED)) == SEM_FAILED)
            || ((sem_serf_wait = sem_open("/xzakji02_semafor_serf_wait", O_CREAT | O_EXCL, 0644, LOCKED)) == SEM_FAILED)
            || ((sem_landing = sem_open("/xzakji02_semafor_landing", O_CREAT | O_EXCL, 0644, LOCKED)) == SEM_FAILED)   ) 
    {
        chyba++;
    }

    if (     ((shm_fd0 = shm_open("/xzakji02_sharedMemory0", O_CREAT | O_EXCL | O_RDWR, 0644)) == -1)
          || ((shm_fd1 = shm_open("/xzakji02_sharedMemory1", O_CREAT | O_EXCL | O_RDWR, 0644)) == -1)
          || ((shm_fd2 = shm_open("/xzakji02_sharedMemory2", O_CREAT | O_EXCL | O_RDWR, 0644)) == -1)
          || ((shm_fd3 = shm_open("/xzakji02_sharedMemory3", O_CREAT | O_EXCL | O_RDWR, 0644)) == -1)
          || ((shm_fd4 = shm_open("/xzakji02_sharedMemory4", O_CREAT | O_EXCL | O_RDWR, 0644)) == -1)  )
    {
        chyba++;
    }

    if (    (ftruncate(shm_fd0, sizeof(int)) == -1)
         || (ftruncate(shm_fd1, sizeof(int)) == -1)
         || (ftruncate(shm_fd2, sizeof(int)) == -1)
         || (ftruncate(shm_fd3, sizeof(int)) == -1)
         || (ftruncate(shm_fd4, sizeof(int)) == -1) )
    {
        chyba++;
    }

    if (     ((sharedCounter = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd0, 0)) == MAP_FAILED)
          || ((sharedCat[HACKER] = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd1, 0)) == MAP_FAILED)
          || ((sharedCat[SERF] = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd2, 0)) == MAP_FAILED)
          || ((sharedPier = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd3, 0)) == MAP_FAILED)
          || ((sharedSEAT = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd4, 0)) == MAP_FAILED) )
    {
        chyba++;
    }

    return chyba;
}

// deinicializace semaforů a sdílených proměných
int clean() {
    
    int chyba = 0;

     if (   (sem_close(sem_counter) == -1)
            || (sem_close(sem_log) == -1)
            || (sem_close(sem_hacker_wait) == -1)
            || (sem_close(sem_serf_wait) == -1)
            || (sem_close(sem_landing) == -1)    )
    {
        chyba++;
    }

    if (    (sem_unlink("/xzakji02_semafor_counter") == -1)
         || (sem_unlink("/xzakji02_semafor_log") == -1)
         || (sem_unlink("/xzakji02_semafor_hacker_wait") == -1)
         || (sem_unlink("/xzakji02_semafor_serf_wait") == -1)
         || (sem_unlink("/xzakji02_semafor_landing") == -1)   )
    {
        chyba++;
    }

    if (    ((munmap(sharedCounter, sizeof(int))) != 0)
         || ((munmap(sharedCat[HACKER], sizeof(int))) != 0)
         || ((munmap(sharedCat[SERF], sizeof(int))) != 0)
         || ((munmap(sharedPier, sizeof(int))) != 0)
         || ((munmap(sharedSEAT, sizeof(int))) != 0) )
    {
        chyba++;
    }

    if (    (shm_unlink("/xzakji02_sharedMemory0") == -1)
         || (shm_unlink("/xzakji02_sharedMemory1") == -1)
         || (shm_unlink("/xzakji02_sharedMemory2") == -1)
         || (shm_unlink("/xzakji02_sharedMemory3") == -1)
         || (shm_unlink("/xzakji02_sharedMemory4") == -1) )
    {
        chyba++;
    }

    if (    (close(shm_fd0) == -1)
         || (close(shm_fd1) == -1)
         || (close(shm_fd2) == -1)
         || (close(shm_fd3) == -1)
         || (close(shm_fd4) == -1) )
    {
        chyba++;
    }
    
    if (fclose(fp) == EOF)
    {
        chyba++;
    }

    return chyba;
}

// destukce při chybě
void destroy(int sig){
    clean();
    kill(getgid(), SIGINT);
    exit(sig);
}

// funkce na přičítání do sdílených proměných
int counter(int *x, int y){
    int cache = 0;

    sem_wait(sem_counter);
    (*x) = (*x) + y;
    cache = *x;             
    sem_post(sem_counter);

    return cache;
}

//funkce na tvorbu kapitáná a členů posádky
int condition(){
    if(*sharedCat[HACKER] >= 4){

        counter(sharedCat[HACKER], -4);
        free_sem(sem_hacker_wait, 4);
        return CAPTAIN;

    } else if(*sharedCat[SERF] >= 4){

        counter(sharedCat[SERF], -4);
        free_sem(sem_serf_wait, 4);
        return CAPTAIN;

    } else if((*sharedCat[HACKER] == 2) && (*sharedCat[SERF] == 2)){

        counter(sharedCat[HACKER], -2);
        counter(sharedCat[SERF], -2);
        free_sem(sem_hacker_wait, 2);
        free_sem(sem_serf_wait, 2);
        return CAPTAIN;

    } else {
        return MEMBER;
    }
}

// funkce na otevírání semaforů
void free_sem(sem_t *sem_target, int free_seat){

    for(int pass = 0; pass < free_seat; pass++)
    {
        sem_post(sem_target);
    }
}

//funkce hlavního generátoru pro tvorbu procesů
int fork_build(FILE *fp, parametrs *pm, int time, int category){

    int a = 0;
    pid_t pid_fork;

    time++;

    while(a < pm->p){

        a++;

        usleep((random() % (time)) * 1000);

        pid_fork = fork();

        if(pid_fork == 0){
            fork_children(fp, pm, category, a, sharedCounter);
        } else if(pid_fork < 0){
            return -1;
        }
    }

    waitpid(-1, NULL, 0);
    exit(0);
}

// funkce na tvorbu procesů SERF a HACK
void fork_children(FILE *fp, parametrs *pm, int category, int a, int *shared){

    sem_wait(sem_log);       
    fprintf(fp, "%d     : %s %d     : starts\n", counter(shared, 1), CATEGORY[category], a);
    sem_post(sem_log);

    if(*sharedPier >= pm->c){
        sem_wait(sem_log);       
        fprintf(fp, "%d     : %s %d     : leaves queue     : %d     : %d\n", counter(shared, 1), CATEGORY[category], a, *sharedCat[0], *sharedCat[1]);
        sem_post(sem_log);

        usleep((random() % (pm -> w + 1)) * 1000);

        sem_wait(sem_log);                   
        fprintf(fp, "%d     : %s %d     : is back\n", counter(shared, 1), CATEGORY[category], a);
        sem_post(sem_log);
    }
    counter(sharedPier, 1);

    sem_wait(sem_log); 
    counter(sharedCat[category], MEMBER);
    fprintf(fp, "%d     : %s %d     : waits     : %d    : %d\n", counter(shared, 1), CATEGORY[category], a, *sharedCat[0], *sharedCat[1]);
    sem_post(sem_log);

    int who = condition();

    if (category == HACKER){                        
        sem_wait(sem_hacker_wait);
    } else {
        sem_wait(sem_serf_wait);
    }

    if(who == CAPTAIN){
        sem_wait(sem_log);
        fprintf(fp, "%d     : %s %d     : boards    : %d    : %d\n", counter(shared, 1), CATEGORY[category], a, *sharedCat[0], *sharedCat[1]);
        sem_post(sem_log);

        counter(sharedPier, -4); 

        srand(time(NULL)*getpid());

        usleep((random() % (pm -> r + 1)) * 1000);
    }

    sem_wait(sem_log); 
    boarding(sharedSEAT, sem_landing, 4, 4);
    sem_post(sem_log);

    sem_wait(sem_landing);

    if(who == MEMBER){
        sem_wait(sem_log);       
        fprintf(fp, "%d     : %s %d     : member exits      : %d    : %d\n", counter(shared, 1), CATEGORY[category], a, *sharedCat[0], *sharedCat[1]);
        sem_post(sem_log);
    } else {
        sem_wait(sem_log);      
        fprintf(fp, "%d     : %s %d     : captain exits      : %d    : %d\n", counter(shared, 1), CATEGORY[category], a, *sharedCat[0], *sharedCat[1]);
        sem_post(sem_log);
    }

    exit(0);
}

// funkce na otevírání semaforů
void boarding(int *seat, sem_t *sem_target, int free_seat, int num){
    
    counter(seat, 1);     
    sem_wait(sem_counter);

    if (*seat == num){
        (*seat) = 0;
        free_sem(sem_target, free_seat);
    }

    sem_post(sem_counter);
}

int main(int argc, char *argv[]) {

    if (argc == 7) {

        pid_t pid_hacker, pid_serf;
        char *ptr;

        parametrs *pm, ini;
        pm = &ini;

        pm->p = strtol(argv[1], &ptr, 10);
        if (*ptr != '\0') {
            fprintf(stderr, "Vstupni paramentry nejsou cisla \n");
            return -1;
        }
        if (pm->p < 2 || (pm->p % 2) != 0) {
            fprintf(stderr, "Pocet osob musi byt aspon 2 a musi byt delitelny dvema \n");
            return -1;
        }
        pm->h = strtol(argv[2], &ptr, 10);
        if (*ptr != '\0') {
            fprintf(stderr, "Vstupni paramentry nejsou cisla \n");
            return -1;
        }
        if (pm->h < 0 || pm->h > 2000) {
            fprintf(stderr, "Hackers ma casovy rozptyl od 0 do 2000 milisekund \n");
            return -1;
        }
        pm->s = strtol(argv[3], &ptr, 10);
        if (*ptr != '\0') {
            fprintf(stderr, "Vstupni paramentry nejsou cisla \n");
            return -1;
        }
        if (pm->s < 0 || pm->s > 2000) {
            fprintf(stderr, "Serfs ma casovy rozptyl od 0 do 2000 milisekund \n");
            return -1;
        }
        pm->r = strtol(argv[4], &ptr, 10);
        if (*ptr != '\0') {
            fprintf(stderr, "Vstupni paramentry nejsou cisla \n");
            return -1;
        }
        if (pm->r < 0 || pm->r > 2000) {
            fprintf(stderr, "Doba plavby ma casovy rozptyl od 0 do 2000 milisekund \n");
            return -1;
        }
        pm->w = strtol(argv[5], &ptr, 10);
        if (*ptr != '\0') {
            fprintf(stderr, "Vstupni paramentry nejsou cisla \n");
            return -1;
        }
        if (pm->w < 20 || pm->w > 2000) {
            fprintf(stderr, "Vraceni osob ma casovy rozptyl od 20 do 2000 milisekund \n");
            return -1;
        }
        pm->c = strtol(argv[6], &ptr, 10);
        if (*ptr != '\0') {
            fprintf(stderr, "Vstupni paramentry nejsou cisla \n");
            return -1;
        }
        if (pm->c < 5) {
            fprintf(stderr, "Kapacita mola musi byt aspon 5\n");
            return -1;
        }

        fp = fopen("proj2.out", "w");
        if (!fp) {
            fprintf(stderr, "Soubor se nepodarilo vytvorit\n");
            return 1;
        }
        setbuf(fp, NULL);

        if (init() != 0){           
            clean();
            return -1;
        }

        *sharedCounter = 0;   
        *sharedCat[HACKER] = 0;   
        *sharedCat[SERF] = 0;   
        *sharedSEAT = 0;
        *sharedPier = 0;

        pid_hacker = fork();
        if(pid_hacker == 0){
            if(fork_build(fp, pm, pm->h, HACKER) != 0){
                return -1;
            }
        } else if(pid_hacker < 0){
            destroy(SIGINT);
            return -1;
        }

        srand(time(NULL) * getpid());

        pid_serf = fork();
        if(pid_serf == 0){
            if(fork_build(fp, pm, pm->s, SERF) != 0){
                return -1;
            }
        } else if(pid_serf < 0){
            destroy(SIGINT);
            return -1;
        }

    } else {
        fprintf(stderr, "Spatny pocet argumentu\n");
    }

    clean();
    return 0;
}