// htab_iterator_set_value.c
// �e�en� IJC-DU2, p��klad 2, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include <stdlib.h>
#include "htab.h"

int htab_iterator_set_value(htab_iterator_t it, int val){
    if(it.ptr != NULL){
        return it.ptr->data = val;
    }
    return -1;
}