// htab_end.c
// �e�en� IJC-DU2, p��klad 2, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include <stdlib.h>
#include "htab.h"

htab_iterator_t htab_end(const htab_t * t) {
    htab_iterator_t iterator;
    iterator.t = t;
    
    for (int i = t->arr_size - 1; i > 0; i--) {
        if (t->data[i] != NULL) {
            iterator.idx = i;
            iterator.ptr = NULL;
            return iterator;
        }
    }
    iterator.idx = 0;
    iterator.ptr = NULL;
    return iterator;
}