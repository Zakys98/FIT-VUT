// htab_iterator_get_value.c
// �e�en� IJC-DU2, p��klad 2, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include <stdlib.h>
#include "htab.h"

int htab_iterator_get_value(htab_iterator_t it){
    if(it.ptr != NULL){
        return it.ptr->data;
    }
    return -1;
}