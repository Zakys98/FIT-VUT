// htab_lookup_add.c
// �e�en� IJC-DU2, p��klad 2, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "htab.h"

htab_iterator_t htab_lookup_add(htab_t * t, const char *key) {

    unsigned int hash = htab_hash_function(key);
    struct htab_item *item = t->data[hash];
    htab_iterator_t iterator;

    for (; item != NULL; item = item->next) {
        if (strcmp(key, item->key) == 0) {
            iterator.idx = hash;
            iterator.ptr = item;
            iterator.t = t;
            return iterator;
        }
        if (item->next == NULL)
            break;
    }

    struct htab_item *new = malloc(sizeof (struct htab_item));
    if (new == NULL) {
        fprintf(stderr, "Pamet se nealokovala\n");
    } else {
        int delka = strlen(key);
        new->key = (char *) calloc((delka + 1), sizeof (char));
        if (new->key == NULL) {
            free(new);
        } else {
            strncpy(new->key, key, delka);
            new->next = NULL;
            new->data = 0;

            if (t->data[hash] == NULL)
                t->data[hash] = new;
            else
                item->next = new;

            iterator.idx = hash;
            iterator.ptr = new;
            iterator.t = t;
        }
    }

    return iterator;
}