// tail.c
// �e�en� IJC-DU2, p��klad 1, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// count number of lines

int numberLines(FILE *fp) {
    int count = 0;
    for (char c = getc(fp); c != EOF; c = getc(fp)) {
        if (c == '\n')
            count++;
    }
    return count;
}

// print lines

void printLines(FILE *fp, int count) {
    int i = 0, velLine = 0;
    char line[1023];
    while (fgets(line, sizeof (line), fp)) {
        i++;
        velLine = strlen(line) - 1;
        line[velLine] = ' ';
        if (i == count) {
            printf("%s\n", line);
            count++;
        }
    }
}

int main(int argc, char *argv[]) {

    FILE *fp;
    int count;

    if (argc == 2) {

        fp = fopen(argv[1], "r");
        if (!fp) {
            fprintf(stderr, "Soubor se nepodarilo otevrit\n");
            exit(1);
        }

        count = numberLines(fp);
        count -= 9;
        rewind(fp);
        printLines(fp, count);
        fclose(fp);
        
    } else if (argc == 4) {

        char *cont = argv[2];
        int input = atoi(argv[2]);
        fp = fopen(argv[3], "r");
        if (!fp) {
            fprintf(stderr, "Soubor se nepodarilo otevrit\n");
            exit(1);
        }

        if ((cont[0] == '+') && (strcmp(argv[1], "-n") == 0)) {
            
            count = numberLines(fp);
            count = count - input - 9;
            rewind(fp);
            printLines(fp, count);

        } else if ((cont[0] == '-') && (strcmp(argv[1], "-n") == 0)) {
            
            count = numberLines(fp);
            count = count + input + 1;
            rewind(fp);
            printLines(fp, count);

        } else if (strcmp(argv[1], "-n") == 0) {

            count = numberLines(fp);
            count -= input - 1;
            rewind(fp);
            printLines(fp, count);

        } else {
            fprintf(stderr, "Spatne zadane parametry programu\n");
        }
        fclose(fp);
        
    } else {
        fprintf(stderr, "Spatne zadany pocet parametru\n");
    }

    return 0;
}
