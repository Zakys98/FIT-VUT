// htab_next.c
// �e�en� IJC-DU2, p��klad 2, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include <stdlib.h>
#include "htab.h"

htab_iterator_t htab_iterator_next(htab_iterator_t it) {
    if (it.ptr->next != NULL) {
        it.ptr = it.ptr->next;
        return it;
    }
    return htab_end(it.t);
}