// htab_begin.c
// �e�en� IJC-DU2, p��klad 2, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include <stdlib.h>
#include "htab.h"

htab_iterator_t htab_begin(const htab_t *t) {
    htab_iterator_t iterator;
    iterator.t = t;

    for (unsigned int i = 0; i < t->arr_size; i++) {
        if (t->data[i] != NULL) {
            iterator.idx = i;
            iterator.ptr = t->data[i];
            return iterator;
        }
    }
    iterator.idx = 0;
    iterator.ptr = NULL;
    return iterator;
}