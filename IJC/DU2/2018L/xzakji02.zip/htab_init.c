// htab_init.c
// �e�en� IJC-DU2, p��klad 2, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include <stdlib.h>
#include <stdio.h>
#include "htab.h"

htab_t *htab_init(size_t n) {
    
    htab_t *htable = malloc((sizeof (htab_t)) + (n * sizeof (struct htab_item)));

    if (htable == NULL) {
        fprintf(stderr, "Pamet se nealokovala\n");
        return NULL;
    }

    for (unsigned int i = 0; i < n; i++)
        htable->data[i] = NULL;
    htable->arr_size = n;
    htable->size = 0;
    
    return htable;
}