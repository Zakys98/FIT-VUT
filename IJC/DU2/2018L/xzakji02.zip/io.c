// io.c
// �e�en� IJC-DU2, p��klad 2, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include "io.h"


int get_word(char *s, int max, FILE *f) {
    int c = 0;
    int i = 0;
    
    while((c = fgetc(f)) != EOF && i < max - 1) {
        if (isspace(c) && i == 0) {
            continue;
        } else {
            if(!isspace(c)){
                s[i] = c;
                i++;
            }
            else
                break;
        }
    }
    if(c != EOF && isspace(c)==0){
        while((c = fgetc(f)) != EOF)
            if(isspace(c))
                break;
        fprintf(stderr, "Slovo je del�� ne� maxim�ln� zadan� hodnota: %d\n", max-1);
        return max-1;
    }
    if(c == EOF)
        return 0;
    
    s[i] = '\0';
    
    return i;
}