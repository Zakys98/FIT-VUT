// htab_clear.c
// �e�en� IJC-DU2, p��klad 2, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include <stdlib.h>
#include "htab.h"

void htab_clear(htab_t * t){
    for(unsigned int i = 0; i < t->arr_size; i++){
        struct htab_item *temp = NULL;
        struct htab_item *item = t->data[i];
        t->data[i] = NULL;
        while(item != NULL){
            temp = item;
            item = item->next;
            free(temp->key);
            free(temp);
        }
    }
}