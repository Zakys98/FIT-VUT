// wordcount.c
// �e�en� IJC-DU2, p��klad 2, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include <stdlib.h>
#include <stdio.h>
#include "htab.h"
#include "io.h"

#define max 127 

int main() {

    htab_t *table = htab_init(1024);
    char *word = (char *)calloc(max, sizeof(char));
    
    struct htab_item *item = NULL;

    htab_iterator_t iterator;
    
    while(get_word(word, max, stdin) != 1){
        iterator = htab_lookup_add(table, word);
		if (item == NULL)
		{
			free(word);
		}
		
	item->data++;
    }

    htab_iterator_t iteratorBegin = htab_begin(table);
    htab_iterator_t iteratorEnd = htab_end(table);
    

    while (htab_iterator_equal(iteratorBegin, iteratorEnd) == false)
	{
		htab_iterator_valid(iterator);
		printf("%s\t%d\n", iterator.ptr->key, iterator.ptr->data);
		iterator = htab_iterator_next(iteratorBegin);
    }

    htab_free(table);
    free(word);
    return 0;
}
