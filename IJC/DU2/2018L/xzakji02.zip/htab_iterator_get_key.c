// htab_iterator_get_key.c
// �e�en� IJC-DU2, p��klad 2, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include <stdlib.h>
#include "htab.h"

const char *htab_iterator_get_key(htab_iterator_t it) {
    if (it.ptr != NULL) {
        char *string = it.ptr->key;
        return string;
    }
    return (void*)-1;
}