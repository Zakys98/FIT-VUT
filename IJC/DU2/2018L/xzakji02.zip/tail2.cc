// tail2.cc
// �e�en� IJC-DU2, p��klad 1, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include <string>
#include <iostream>
#include <queue>
#include <fstream>
#include <cstring>

using namespace std;

void printFile(int count, string filename) {

    ifstream fp(filename);
    string word;
    queue<string> buffer;

    if (!fp) {
        cerr << "Soubor se nepodarilo otevrit\n";
        return;
    }
    
    for (int i = 0; i < count && getline(fp, word); i++) {
        buffer.push(word);
    }
    while (getline(fp, word)) {
        buffer.pop();
        buffer.push(word);
    }

    for (int i = 0; i < count; i++) {
        cout << buffer.front() << endl;
        buffer.pop();
        if (buffer.size() == 0) {
            fp.close();
            return;
        }
    }
}

int main(int argc, char* argv[]) {

    if (argc == 2) {
        printFile(10, argv[1]);
    } else if(argc == 4 && !strcmp(argv[1], "-n")){
        printFile(atoi(argv[2]), argv[3]);
    } else {
        cout << "Chyba v argumentech\n";
    }
    return 0;
}