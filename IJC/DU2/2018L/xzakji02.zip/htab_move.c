// htab_move.c
// �e�en� IJC-DU2, p��klad 2, 24.4.2019
// Autor: Ji�� ��k, FIT
// P�elo�eno: gcc 8.3


#include <stdlib.h>
#include <stdio.h>
#include "htab.h"

htab_t *htab_move(size_t n, htab_t *from) {

    htab_t *tab = malloc(sizeof (htab_t) + n * sizeof (struct htab_item));
    if (tab == NULL) {
        fprintf(stderr, "Nepodarilo se alokovat pamet\n");
        return NULL;
    }
    tab->arr_size = n;
    tab->size = from->size;

    htab_clear(from);

    return tab;
}