ICP projekt 2020

Spuštění projektu:
Kompilaci a spuštění projektu lze udělat příkazem make run.

Dokumentace:
Dokumentaci projektu lze vytvořit příkazem make doxygen.

Informace:
Projekt nepodporuje interaktivní zásahy.

Projekt jsem vytvořil sám, protože kolega se kterým jsem měl původně být mi týden před odevzdáním napsal, že projekt tvořit nebude, protože to nestíha. (má Javu jako hlavní volitelný předmět) Toto můžu doložit.

Vytvořil Jiří Žák (xzakji02).
