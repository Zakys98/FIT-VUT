/**
 * @file   vehicle.h
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief
 */
#ifndef VEHICLE_H
#define VEHICLE_H

/**
 * @brief The Vehicle class
 */
class Vehicle{
    private:
        /**
         * @brief position of vehicle
         */
        qreal position;
        /**
          * @brief direction of vehicle
          */
        bool direction{true};
    public:
        /**
         * @brief Constructor for vehicle
         */
        Vehicle() : position(0.0) {}
        /**
         * @brief getter for position
         * @return qreal position
         */
        qreal getPosition() { return this->position; }
        /**
         * @brief setteer for position
         * @param qreal r
         */
        void setPosition(qreal r) { this->position = r; }
        /**
         * @brief increment position
         */
        void incPosition() { this->position += 0.01; }
        /**
         * @brief decrement position
         */
        void decPosition() { this->position -= 0.01; }
        /**
         * @brief setter for direction
         * @param bool dir
         */
        void setDirection(bool dir) { this->direction = dir; }
        /**
         * @brief getter for direction
         * @return bool direction
         */
        bool getDirection() { return this->direction; }
};

#endif // VEHICLE_H
