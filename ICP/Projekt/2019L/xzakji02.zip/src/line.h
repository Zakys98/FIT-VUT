/**
 * @file   line.h
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief
 */
#ifndef LINE_H
#define LINE_H

#include <QGraphicsLineItem>
#include <QPainter>
#include <QVariantAnimation>
#include "street.h"
#include "vehicle.h"

/**
 * @brief The Line class
 */
class Line : public QObject, public QGraphicsLineItem
{
   Q_OBJECT
    public:
        /**
         * @brief Constructor for Line
         * @param QGraphicsitem *parents
         */
        Line(QGraphicsItem *parent = nullptr);
        /**
         * @brief start animation
         */
        void playAnim();
        /**
         * @brief setter for posStop
         * @param qreal num
         */
        void setPosStop(qreal num) { this->posStop = num; }
        /**
         * @brief getter for posStop
         * @return qreal posStop
         */
        qreal getPosStop() { return this->posStop; }
        /**
         * @brief setter for posVehicle
         * @param qreal num
         */
        void setPosVehicle(qreal num) { this->posVehicle = num; }
        /**
         * @brief getter for posVehicle
         * @return qreal posVehicle
         */
        qreal getPosVehicle() { return this->posVehicle; }
        /**
         * @brief setter for str
         * @param Street *s
         */
        void setStr(Street *s) { this->str = s; }
        /**
         * @brief getter for str
         * @return Street *str
         */
        Street* getStr() { return this->str; }
        /**
         * @brief setter for nextStr
         * @param Street *s
         */
        void setNextStr(Street *s) { this->nextStr = s; }
        /**
         * @brief getter for nextStr
         * @return Street *nextStr
         */
        Street* getNextStr() { return this->nextStr; }
        /**
         * @brief setter for prevStr
         * @param Street *s
         */
        void setPrevStr(Street *s) { this->prevStr = s; }
        /**
         * @brief getter for prevStr
         * @return Street *prevStr
         */
        Street* getPrevStr() { return this->prevStr; }

    protected:
        /**
         * @brief paints cars and stop on the street
         * @param QPainter *painter
         * @param QStyleOptionGraphicsItem* option
         * @param QWidget *widget
         */
        virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = Q_NULLPTR) override;
        /**
         * @brief for better painting lines
         * @return QRectf
         */
        virtual QRectF boundingRect() const;

    private:
        /**
         * @brief Animation
         */
        QVariantAnimation *animation{nullptr};
        /**
         * @brief Street
         */
        Street *str;
        /**
         * @brief Next street
         */
        Street *nextStr{nullptr};
        /**
         * @brief Previous street
         */
        Street *prevStr{nullptr};
        /**
         * @brief Vehicle
         */
        Vehicle *vehicle;
        /**
         * @brief position stop
         */
        qreal posStop;
        /**
         * @brief position vehicle
         */
        qreal posVehicle;

    private slots:
        /**
         * @brief Slot for animation
         * @param QVariant &value
         */
        void onAnim(const QVariant &value);
};

#endif // LINE_H
