/**
 * @file   street.h
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief
 */
#ifndef STREET_H
#define STREET_H

#include <QString>
#include <QVector>
#include "coordinate.h"
#include "stop.h"
#include "vehicle.h"

/**
 * @brief The Street class
 */
class Street{

    private:
        /**
         * @brief Id var
         */
        QString id;
        /**
         * @brief var, where street starts
         */
        Coordinate start;
        /**
         * @brief var, where street ends
         */
        Coordinate end;
        /**
         * @brief stop on the street
         */
        Stop stop;
        /**
          * @brief var for generating new Vehicles
          */
        int reset{0};
        /**
         * @brief vector with vehicles
         */
        QVector<Vehicle *> vehicles;
     public:
        /**
         * @brief getter for id
         * @return QString id
         */
        QString getId() { return this->id; }
        /**
         * @brief setter for id
         * @param Qstring name
         */
        void setId(QString name) { this->id = name; }
        /**
         * @brief getter for start
         * @return Coordinate start
         */
        Coordinate getStart() { return this->start; }
        /**
         * @brief setter for start
         * @param Coordinate start
         */
        void setStart(Coordinate start) { this->start = start; }
        /**
         * @brief getter for end
         * @return Coordinate start
         */
        Coordinate getEnd() { return this->end; }
        /**
         * @brief setter for end
         * @param Coordinate end
         */
        void setEnd(Coordinate end) { this->end = end; }
        /**
         * @brief getter for stop
         * @return Stop stop
         */
        Stop getStop() { return this->stop; }
        /**
         * @brief setter for stop
         * @param Stop s
         */
        void setStop(Stop s) { this->stop = s; }
        /**
         * @brief getter for reset
         * @return int reset
         */
        int getReset() { return this->reset; }
        /**
         * @brief increment reset
         */
        void incReset() { this->reset++; }
        /**
         * @brief decrement reset
         */
        void decReset() { this->reset--; }
        /**
         * @brief getter for vehicles
         * @return vector vehicles
         */
        QVector<Vehicle *> getVehicles() { return this->vehicles; }
        /**
         * @brief Add vehicle in vehicles
         * @param Vehicle v
         */
        void addVehicle(Vehicle *v) { this->vehicles.push_back(v); }
        /**
         * @brief Delete first vehicle in vehicles
         */
        void deleteVehicle() { this->vehicles.removeFirst(); }
};

#endif // STREET_H
