/**
 * @file   route.h
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief
 */
#ifndef ROUTE_H
#define ROUTE_H

#include "street.h"
#include "coordinate.h"
#include <QVector>

/**
 * @brief The Route class
 */
class Route{
    private:
        /**
         * @brief id
         */
        QString id;
        /**
         * @brief generate time for next vehicle
         */
        int generateTime;
        /**
         * @brief generate actual time for next vehicle
         */
        int generateActual;
        /**
         * @brief number of vehicles in route to generate
         */
        int numberOfVehicles;
        /**
         *  @brief number of vehicles on track
         */
        int numberOfActualVehicles{0};
        /**
         * @brief vector of streets in route
         */
        QVector<Street *> streets;
    public:
        /**
         * @brief setter for id
         * @param QString s
         */
        void setId(QString s) { this->id = s; }
        /**
         * @brief getter for id
         * @return QString id
         */
        QString getId() {return this->id; }
        /**
         * @brief setter for numberOfVehicles
         * @param int n
         */
        void setNumberOfVehicles(int n) { this->numberOfVehicles = n; }
        /**
         * @brief getter for numberOfVehicles
         * @return int numberofVehicles
         */
        int getNumberOfVehicles() { return this->numberOfVehicles; }
        /**
         * @brief setter for numberOfActualVehicles
         * @param int n
         */
        void setNumberOfActualVehicles(int n) { this->numberOfActualVehicles = n; }
        /**
         * @brief getter for numberOfActualVehicles
         * @return int numberOfActualVehicles
         */
        int getNumberOfActualVehicles() { return this->numberOfActualVehicles; }
        /**
         * @brief increment numberOfActualVehicles
         */
        void incNumberOfActualVehicles() { this->numberOfActualVehicles++; }
        /**
         * @brief decrement numberOfActualVehicles
         */
        void decNumberOfActualVehicles() { this->numberOfActualVehicles--; }
        /**
         * @brief setter for generateTime
         * @param int n
         */
        void setGenerateTime(int n) { this->generateTime = n; }
        /**
         * @brief getter for generateTime
         * @return int generateTime
         */
        int getGenerateTime() { return this->generateTime; }
        /**
         * @brief increment generateActual
         */
        void incGenerateActual() { this->generateActual++; }
        /**
         * @brief setter for generateActual
         * @param int n
         */
        void setGenerateActual(int n) { this->generateActual = n; }
        /**
         * @brief getter for generateActual
         * @return int generateActual
         */
        int getGenerateActual() { return this->generateActual; }
        /**
         * @brief getter for streets
         * @return
         */
        QVector<Street *> getStreets() { return this->streets; }
        /**
         * @brief Add street to streets
         * @param Street *s
         */
        void addStreet(Street *s) { this->streets.push_back(s); }
};

#endif // ROUTE_H
