/**
 * @file   scene.h
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief  class for gui part
 */
#ifndef SCENE_H
#define SCENE_H

#include <QGraphicsScene>
#include "line.h"
#include "controller.h"

/**
 * @brief The Scene class
 */
class Scene : public QGraphicsScene
{
        Q_OBJECT
    private:
        /**
         * @brief Line for creating objects
         */
        Line *editedLine;
    public:
        /**
         * @brief Consrtuctor for scene
         * @param parent
         */
        explicit Scene(QObject *parent = nullptr); 
        /**
         * @brief Create lines from streets
         * @param Controller *con
         */
        void makeLines(Controller *con);
        /**
         * @brief Add previous and next street to each line in specific route
         * @param Controller *con
         */
        void setNextPrev(Controller *con);
};

#endif // SCENE_H
