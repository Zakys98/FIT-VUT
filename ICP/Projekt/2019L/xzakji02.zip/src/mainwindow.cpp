/**
 * @file   mainwindow.cpp
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief
 */
#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QPainter>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

void MainWindow::initMap(){

    scene = new Scene(ui->graphicsView);
    ui->graphicsView->setScene(scene);

    con = new Controller();
    con->parseMap();
    con->parseLines();
    scene->makeLines(con);
    scene->setNextPrev(con);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);

    connect(ui->zoomInButton, &QPushButton::clicked, this, &MainWindow::zoomIn);
    connect(ui->zoomOutButton, &QPushButton::clicked, this, &MainWindow::zoomOut);
    connect(ui->start, &QPushButton::clicked, this, &MainWindow::startTimer);
    connect(ui->stop, &QPushButton::clicked, this, &MainWindow::stopTimer);

    timer = new QTimer(this);
    timer->setInterval(500);
    connect(timer, &QTimer::timeout, this, &MainWindow::onTimer);
    timer->start();
}

MainWindow::~MainWindow(){
    delete ui;
    delete timer;
    delete con;
    delete scene;
    delete vehicle;
}

void MainWindow::onTimer(){

    for (int i = 0; i < con->getRoutes().size(); ++i) {
        if(con->getRoutes()[i]->getGenerateActual() == con->getRoutes()[i]->getGenerateTime()){
            if(con->getRoutes()[i]->getNumberOfActualVehicles() < con->getRoutes()[i]->getNumberOfVehicles()){
                vehicle = new Vehicle();
                con->getRoutes()[i]->getStreets()[0]->addVehicle(vehicle);
                con->getRoutes()[i]->incNumberOfActualVehicles();
            }
            if(con->getRoutes()[i]->getStreets()[0]->getReset() > 0){
                con->getRoutes()[i]->decNumberOfActualVehicles();
                con->getRoutes()[i]->getStreets()[0]->decReset();
            }
            con->getRoutes()[i]->setGenerateActual(0);
        } else {
            con->getRoutes()[i]->incGenerateActual();
        }
    }

    for (int i = 0; i < con->getLines().size(); ++i) {
        line = con->getLines()[i];
        line->playAnim();
    }

}

void MainWindow::zoomIn(){
    ui->graphicsView->scale(1.25, 1.25);
}

void MainWindow::zoomOut(){
    ui->graphicsView->scale(0.8, 0.8);
}

void MainWindow::startTimer(){
    timer->start();
}

void MainWindow::stopTimer(){
    timer->stop();
}
