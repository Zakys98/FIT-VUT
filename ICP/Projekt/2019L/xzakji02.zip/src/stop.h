/**
 * @file   stop.h
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief
 */
#ifndef STOP_H
#define STOP_H

/**
 * @brief The Stop class
 */
class Stop{
    private:
        /**
         * @brief var for position stop
         */
        qreal cor;
    public:
        /**
         * @brief getter for cor
         * @return qreal cor
         */
        qreal getCor() { return this->cor; }
        /**
         * @brief setter for cor
         * @param qreal cor
         */
        void setCor(qreal cor) { this->cor = cor; }
};

#endif // STOP_H
