/**
 * @file   scene.cpp
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief
 */
#include "scene.h"

Scene::Scene(QObject *parent) : QGraphicsScene(parent)
{

}

void Scene::makeLines(Controller *con)
{
    for (int i = 0; i < con->getStreets().size(); i++) {
        editedLine = new Line();
        editedLine->setStr(con->getStreets()[i]);
        editedLine->setPosStop(con->getStreets()[i]->getStop().getCor());
        editedLine->setLine(QLineF(con->getStreets()[i]->getStart().getX(), con->getStreets()[i]->getStart().getY(), con->getStreets()[i]->getEnd().getX(), con->getStreets()[i]->getEnd().getY()));
        con->addLine(editedLine);
        addItem(editedLine);
    }
}

void Scene::setNextPrev(Controller *con)
{
    int position = 0;
    for (int i = 0; i < con->getRoutes().size(); ++i) {
        for (int j = 0; j < con->getRoutes()[i]->getStreets().size(); ++j) {
            editedLine = con->getLines()[position];
            if(j + 1 < con->getRoutes()[i]->getStreets().size())
                editedLine->setNextStr(con->getRoutes()[i]->getStreets()[j + 1]);
            if(j - 1 >= 0)
                editedLine->setPrevStr(con->getRoutes()[i]->getStreets()[j - 1]);
            position++;
        }
    }
}
