/**
 * @file   coordinate.h
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief  Coordinate for Streets, Stops, Lines
 */
#ifndef COORDINATE_H
#define COORDINATE_H

/**
 * @brief The Coordinate class
 */
class Coordinate
{
    private:
        /**
         * @brief position x var
         */
        int x;
        /**
         * @brief position y var
         */
        int y;

    public:
       /**
        * @brief setter for x
        * @param int x
        */
        void setX(int x) { this->x = x; }
        /**
         * @brief getter for x
         * @return int x
         */
        int getX() { return this->x; }
        /**
         * @brief setter for y
         * @param int y
         */
        void setY(int y) { this->y = y; }
        /**
         * @brief getter for y
         * @return int x
         */
        int getY() { return this->y; }
};

#endif // COORDINATE_H
