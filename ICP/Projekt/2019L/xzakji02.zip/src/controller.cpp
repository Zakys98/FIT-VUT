/**
 * @file   controller.cpp
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief
 */
#include "controller.h"

void Controller::parseMap() {
    QFile file("examples/example.map");
    if(!file.open(QIODevice::ReadOnly))
        exit(0);
    QTextStream in(&file);

    while (!in.atEnd()) {
        QStringList splittedLeft = in.readLine().split('|');
        QStringList splittedRight = splittedLeft[1].split(' ');

        int x1, y1, x2, y2;
        QString name;

        name = splittedLeft[0];
        x1 = splittedRight[0].toInt();
        y1 = splittedRight[1].toInt();
        x2 = splittedRight[2].toInt();
        y2 = splittedRight[3].toInt();

        if(x1 == x2 && x2 == y1 && y1 == y2 && y2 == 0)
            break;
        Street *str = new Street();
        str->setId(name);
        Coordinate co1;
        co1.setX(x1);
        co1.setY(y1);
        str->setStart(co1);
        Coordinate co2;
        co2.setX(x2);
        co2.setY(y2);
        str->setEnd(co2);

        Stop stop;
        stop.setCor((qrand() % 10) / 10.0);
        str->setStop(stop);

        this->streets.push_back(str);
    }
    file.close();
}

void Controller::parseLines() {

    QFile file("examples/example.lines");
    if(!file.open(QFile::ReadOnly | QFile::Text)){
       qDebug() << "Cannot read file" << file.errorString();
       exit(0);
    }

    QXmlStreamReader reader(&file);

    if (reader.readNextStartElement()) {
        if (reader.name() == "TransportLines") {

            // cteni vsech linek
            while(reader.readNextStartElement()) {
                if(reader.name() == "Line") {

                    Route *rt = new Route();

                    QString addedLineName = reader.attributes().value("name").toString();
                    rt->setId(addedLineName);

                    while (reader.readNextStartElement()) {

                       // Zastavky
                       if (reader.name() == "Stops") {

                          /*  bool streetStartSet = false;

                            while (reader.readNextStartElement()) {
                                if(reader.name() == "Stop") {
                                    qDebug() << "Zastávka: " << reader.attributes().value("name").toString() << reader.attributes().value("onStreet").toString();
                                    Stop *stop = new Stop();
                                    stop->setId(reader.attributes().value("name").toString());
                                    stop->setX(reader.attributes().value("x").toInt());
                                    stop->setY(reader.attributes().value("y").toInt());
                                    Street street;

                                    rt.addStop(stop);

                                    for (int i = 0; i < this->streets.length(); i++) {
                                        if (this->streets[i]->getId() == reader.attributes().value("onStreet").toString()) {
                                            this->streets[i]->addStop(stop);
                                            qDebug() << "pridano: " << stop->getX() << stop->getY() << stop->getId();
                                            qDebug() << "Ulice obsahuje: " << this->streets[i]->getStops();
                                            for (int y = 0; y < this->streets[i]->getStops().length(); y++) {
                                                qDebug() << "U: " << this->streets[i]->getStops()[y]->getId();
                                            }

                                            // pridani do route/linky
                                            rt.route_streets.push_back(*this->streets[i]);
                                            if (!streetStartSet) {
                                                rt.setStart(this->streets[i]->getStart());
                                            }
                                            rt.setEnd(this->streets[i]->getEnd());

                                        }
                                    }

                                    reader.readNext();
                                }
                            }

                            this->routes.push_back(rt);
                            qDebug() << "zacatek trasy: " << getRoutes()[0].getStart().getX() << "konec trasy: " << getRoutes()[0].getEnd().getX();

*/
                        // Spoje (Vozidla)
                        } else if (reader.name() == "Options") {

                            while (reader.readNextStartElement()) {
                                if(reader.name() == "number") {
                                    rt->setNumberOfVehicles(reader.readElementText().toInt());
                                } else if(reader.name() == "generate"){
                                    rt->setGenerateActual(reader.readElementText().toInt());
                                    rt->setGenerateTime(rt->getGenerateActual());
                                }
                                reader.readNext();
                            }

                        } else if(reader.name() == "Streets"){

                           while(reader.readNextStartElement()){
                               if(reader.name() == "Street"){

                                   bool in = false;
                                   Street *str;
                                   for (int i = 0; i < getStreets().size(); ++i) {
                                       if(reader.attributes().value("name").toString() == getStreets()[i]->getId()){
                                           in = true;
                                           str = getStreets()[i];
                                           break;
                                       }
                                   }
                                   if(in)
                                      rt->addStreet(str);
                                   reader.readNext();
                               }
                           }

                       }

                    }
                    this->routes.push_back(rt);
                }

            }
        }
    }

}
