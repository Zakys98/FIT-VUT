/**
 * @file   line.cpp
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief
 */
#include "line.h"

Line::Line(QGraphicsItem *parent) :
    QObject(),
    QGraphicsLineItem(parent)
{
    setPen(QPen({Qt::black}, 3));
    setFlag(QGraphicsItem::ItemIsSelectable);
    this->posVehicle = 0.0;

    animation = new QVariantAnimation(this);
    animation->setDuration(500);
    connect(animation, &QVariantAnimation::valueChanged, this, &Line::onAnim);
}

void Line::playAnim()
{
    animation->setStartValue(this->posVehicle);
    qreal end = posVehicle + 0.1;
    animation->setEndValue(end);
    animation->start();
}

void Line::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawLine(line());

    QColor yellow("#f0d048");
    QBrush brush(yellow);
    painter->setBrush(brush);
    painter->drawEllipse(line().pointAt(posStop), 3, 3);
    QColor red("#ff0000");
    QBrush br(red);
    painter->setBrush(br);
    for (int i = 0; i < str->getVehicles().size(); ++i) {
        if(str->getVehicles()[i]->getPosition() > 1.0 || str->getVehicles()[i]->getPosition() < 0){
            if(str->getVehicles()[i]->getDirection()){
                if(nextStr != nullptr){
                    vehicle = new Vehicle();
                    nextStr->addVehicle(vehicle);
                    str->deleteVehicle();
                } else {
                    str->deleteVehicle();
                    vehicle = new Vehicle();
                    vehicle->setPosition(1.0);
                    vehicle->setDirection(false);
                    str->addVehicle(vehicle);
                }
            } else {
                if(prevStr != nullptr){
                    vehicle = new Vehicle();
                    vehicle->setPosition(1.0);
                    vehicle->setDirection(false);
                    str->deleteVehicle();
                    prevStr->addVehicle(vehicle);
                } else {
                    str->incReset();
                    str->deleteVehicle();
                }
            }
        } else {
            painter->drawEllipse(line().pointAt(str->getVehicles()[i]->getPosition()), 2, 2);
            if(str->getVehicles()[i]->getDirection()){
                str->getVehicles()[i]->incPosition();
            } else {
                str->getVehicles()[i]->decPosition();
            }
       }
    }
}

QRectF Line::boundingRect() const
{
    QPainterPath pp;
    pp.addRect(QGraphicsLineItem::boundingRect());
    pp.addEllipse(line().pointAt(posStop), 3, 3);
    for (int i = 0; i < str->getVehicles().size(); ++i) {
        pp.addEllipse(line().pointAt(str->getVehicles()[i]->getPosition()), 2, 2);
    }
    return pp.boundingRect();
}

void Line::onAnim(const QVariant &value)
{
    this->posVehicle = value.toReal();
    update();
}
