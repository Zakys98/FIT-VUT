/**
 * @file   controller.h
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief  Contrller for whole project
 */
#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <QVector>
#include <QString>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include "street.h"
#include "line.h"
#include "route.h"
#include <QXmlStreamReader>

/**
 * @brief The Controller class
 */
class Controller {
   private:
        /**
         * @brief vector streets
         */
        QVector<Street *> streets;
        /**
         * @brief vector routes
         */
        QVector<Route *> routes;
        /**
         * @brief vector lines
         */
        QVector<Line *> lines;
   public:
        /**
         * @brief parse map from file
         */
        void parseMap();
        /**
         * @brief parse routes and options from file
         */
        void parseLines();
        /**
         * @brief getter for streets
         * @return vector streets
         */
        QVector<Street *> getStreets() { return this->streets; }
        /**
         * @brief getter for routes
         * @return vector routes
         */
        QVector<Route *> getRoutes() { return this->routes; }
        /**
         * @brief getter for lines
         * @return vector lines
         */
        QVector<Line *> getLines() { return this->lines; }
        /**
         * @brief add item to lines
         * @param Line *l
         */
        void addLine(Line *l) { this->lines.push_back(l); }
};

#endif // CONTROLLER_H
