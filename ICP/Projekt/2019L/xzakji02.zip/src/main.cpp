/**
 * @file   main.cpp
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief
 */
#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.initMap();
    w.show();

    return a.exec();
}
