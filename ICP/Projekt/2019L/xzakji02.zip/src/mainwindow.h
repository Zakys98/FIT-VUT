/**
 * @file   mainwindow.h
 * @author Jiří Žák (xzakji02)
 * @date   May 2020
 * @brief  class for gui part
 */
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDebug>
#include <QTimer>
#include "controller.h"
#include "scene.h"
#include <QGraphicsView>
#include "line.h"
#include "vehicle.h"

namespace Ui {
    class MainWindow;
}

/**
 * @brief Gui class contains graphics and gui methods
 */
class MainWindow : public QMainWindow
{
        Q_OBJECT

    public:
        /**
         * @brief Aplication window constructor, setup in mainwindow.ui file
         * @param QWidget *parent
         */
        explicit MainWindow(QWidget *parent = 0);
        /**
         * @brief Destructor for aplication window
         */
        ~MainWindow();
        /**
         * @brief Initialization map and connect slots at start
         */
        void initMap();

    private slots:
        /**
         * @brief Slot for timer ticking
         */
        void onTimer();
        /**
         * @brief Slot for zoom in
         */
        void zoomIn();
        /**
         * @brief Slot for zoom out
         */
        void zoomOut();
        /**
         * @brief Slot for timer start
         */
        void startTimer();
        /**
         * @brief Slot for timer stop
         */
        void stopTimer();

    private:
        /**
         * @brief Aplication UI class
         */
        Ui::MainWindow *ui;
        /**
         * @brief Timer class
         */
        QTimer *timer;
        /**
         * @brief Scene class
         */
        Scene *scene;
        /**
         * @brief Controller class
         */
        Controller *con;
        /**
         * @brief Vehicle class
         */
        Vehicle *vehicle;
        /**
         * @brief Line class
         */
        Line *line;
};

#endif // MAINWINDOW_H
