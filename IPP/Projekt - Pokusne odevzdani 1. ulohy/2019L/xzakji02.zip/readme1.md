dokumentace k prvni casti
