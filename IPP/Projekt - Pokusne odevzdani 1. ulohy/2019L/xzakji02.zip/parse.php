<?php

const error_missing_param = 10;
const error_input_file = 11;
const error_output_file = 12;
const error_missing_header = 21;
const error_op_code = 22;
const error_syntax_lex = 23;
const error_intern = 99;

class Statistics
{
    private $loc;
    private $comments;
    private $jumps;
    private $labels;

    public function __construct()
    {
        $this->loc = 0;
        $this->comments = 0;
        $this->jumps = 0;
        $this->labels = 0;
    }

    public function setLoc($loc)
    {
        $this->loc = $loc;
    }

    public function getLoc()
    {
        return $this->loc;
    }

    public function incComments()
    {
        $this->comments++;
    }

    public function getComments()
    {
        return $this->comments;
    }

    public function incJumps()
    {
        $this->jumps++;
    }

    public function getJumps()
    {
        return $this->jumps;
    }

    public function incLabels()
    {
        $this->labels++;
    }

    public function getLabels()
    {
        return $this->labels;
    }
}

function generate_instruction_start($xw, &$line, $word)
{
    $line++;
    xmlwriter_start_element($xw, 'instruction');
    xmlwriter_start_attribute($xw, 'order');
    xmlwriter_text($xw, $line);
    xmlwriter_end_attribute($xw);
    xmlwriter_start_attribute($xw, 'opcode');
    xmlwriter_text($xw, $word);
    xmlwriter_end_attribute($xw);
}

function generate_instruction_end($xw)
{
    xmlwriter_end_element($xw);
}

function generate_argument($xw, $argument, $type, $attribute)
{
    xmlwriter_start_element($xw, $argument);
    xmlwriter_start_attribute($xw, 'type');
    xmlwriter_text($xw, $type);
    xmlwriter_end_attribute($xw);
    xmlwriter_text($xw, $attribute);
    xmlwriter_end_element($xw);
}

function var_reg($txt)
{
    if (preg_match('/^(LF|TF|GF)@[[:alnum:]\_\-\$\&\%\*]+/', $txt))
        return true;
    return false;
}

function generate_symbol($xw, $word, $ord)
{
    $argument = "arg" . $ord;
    if (var_reg($word[$ord]) !== 1) {
        $text = explode("@", $word[$ord]);
        if (count($text) == 1) {
            generate_argument($xw, $argument, $text[0], "");
        } else {
            generate_argument($xw, $argument, $text[0], $text[1]);
        }
    } else {
        generate_argument($xw, $argument, "var", $word[$ord]);
    }
}

function symb_reg($txt)
{
    if (
        (preg_match('/^(LF|TF|GF)@[[:alnum:]\_\-\$\&\%\*]+/', $txt)) ||
        (preg_match('/^((bool@)(true|false))$/', $txt)) ||
        (preg_match('/^(int@(\+|\-)[[:digit:]]+)|(int@[[:digit:]]+)|int@/', $txt)) ||
        (preg_match('/^float@0x[[:digit:]]+\.([a-f]|[[:digit:]])+p(\+|\-)[[:digit:]]+|flaot@/', $txt)) ||
        (preg_match('/^(string@[[:alnum:]]+)|string@/', $txt)) ||
        (preg_match('/^nil@nil/', $txt))
    ) {
        return true;
    }
    return false;
}




$longopts = array(
    "stat::"
);
$params = getopt("", $longopts);

$stat_exist = false;
if ($argc > 1) {
    if ($argc == 2) {
        if ($argv[1] == "--help") {
            echo ("Help\n");
            exit(0);
        } elseif (preg_match('/^--stat=[[:alnum:]\_\-\.]*/', $argv[1])){
            $stat_exist = true;
        } else {
            exit(error_missing_param);
        }
    } else {
        for ($i = 1; $i < $argc; $i++) {
            switch($argv[$i]){
                case '--help':
                    exit(error_missing_param);
                case '--loc':
                case '--labels':
                case '--jumps':
                case '--comments':
                    break;
                default:
                    if(preg_match('/^--stat=[[:alnum:]\_\-\.]*/', $argv[$i])){
                        $stat_exist = true;
                        break;
                    }
                    exit(error_missing_param);
            }  
        }
        if($stat_exist == false)
            exit(error_missing_param);
    }
}

$file_name = 'php://stdin';
$input_file = fopen($file_name, 'r') or die("Couldn't open the file");
$stat = new Statistics();
$line_number = 0;
$instructions = "MOVE|CREATEFRAME|PUSHFRAME|POPFRAME|DEFVAR|CALL|RETURN|PUSHS|POP|ADD|SUB|MUL|IDIV|LT|GT|EQ|".
                "AND|OR|NOT|INT2CHAR|STR2INT|READ|WRITE|CONCAT|STRLEN|GETCHAR|SETCHAR|TYPE|LABEL|JUMP|JUMPIFEQ|".
                "JUMPIFNEQ|EXIT|DPRINT|BREAK";

$xw = xmlwriter_open_memory();
xmlwriter_set_indent($xw, 1);
$res = xmlwriter_set_indent_string($xw, '    ');

xmlwriter_start_document($xw, '1.0', 'UTF-8');

while (!feof($input_file)) {

    $line = fgets($input_file);
    $word = explode(" ", $line);

    if ($word[0] == "\n")
        continue;
    
    $word[count($word) - 1] = preg_replace('/\s/', '', $word[count($word) - 1]);

    switch (strtoupper($word[0])) {
        case 'STRLEN':
        case 'INT2CHAR':
        case 'TYPE':
        case 'NOT':
        case 'MOVE':
            if ((var_reg($word[1]) && (symb_reg($word[2])))) {
                generate_instruction_start($xw, $line_number, $word[0]);
                generate_argument($xw, "arg1", "var", $word[1]);
                generate_symbol($xw, $word, 2);
                generate_instruction_end($xw);
            } else {
                exit(error_syntax_lex);
            }
            break;
        case 'POPS':
        case 'DEFVAR':
            if (var_reg($word[1])) {
                generate_instruction_start($xw, $line_number, $word[0]);
                generate_argument($xw, "arg1", "var", $word[1]);
                generate_instruction_end($xw);
            } else {
                exit(error_syntax_lex);
            }
            break;
        case 'CALL':
            if (preg_match('/[(a-zA-Z0-9)|(\_\-\$\&\%\*)]+/', $word[1])) {
                generate_instruction_start($xw, $line_number, $word[0]);
                generate_argument($xw, "arg1", "label", $word[1]);
                generate_instruction_end($xw);
            } else {
                exit(error_syntax_lex);
            }
            break;
        case 'DPRINT':
        case 'EXIT':
        case 'WRITE':
        case 'PUSHS':
            if (symb_reg($word[1])) {
                generate_instruction_start($xw, $line_number, $word[0]);
                generate_symbol($xw, $word, 1);
                generate_instruction_end($xw);
            } else {
                exit(error_syntax_lex);
            }
            break;
        case 'ADD':
        case 'SUB':
        case 'MUL':
        case 'IDIV':
        case 'LT':
        case 'GT':
        case 'EQ':
        case 'AND':
        case 'OR':
        case 'STR2INT':
        case 'CONCAT':
        case 'GETCHAR':
        case 'SETCHAR':
            if ((var_reg($word[1])) && (symb_reg($word[2])) && (symb_reg($word[3]))) {
                generate_instruction_start($xw, $line_number, $word[0]);
                generate_argument($xw, "arg1", "var", $word[1]);
                generate_symbol($xw, $word, 2);
                generate_symbol($xw, $word, 3);
                generate_instruction_end($xw);
            } else {
                exit(error_syntax_lex);
            }
            break;
        case 'READ':
            if ((var_reg($word[1])) && (preg_match('/int|float|string|bool/', $word[2]))) {
                generate_instruction_start($xw, $line_number, $word[0]);
                generate_argument($xw, "arg1", "var", $word[1]);
                generate_argument($xw, "arg2", "type", $word[2]);
                generate_instruction_end($xw);
            } else {
                exit(error_syntax_lex);
            }
            break;
        case 'LABEL':
        case 'JUMP':
            if (preg_match('/\S+/', $word[1])) {
                generate_instruction_start($xw, $line_number, $word[0]);
                generate_argument($xw, "arg1", "label", $word[1]);
                generate_instruction_end($xw);
                if ($word[0] == "LABEL")
                    $stat->incLabels();
                else
                    $stat->incJumps();
            } else {
                exit(error_syntax_lex);
            }
            break;
        case 'JUMPIFEQ':
        case 'JUMPIFNEQ':
            if ((preg_match('/\S+/', $word[1])) && (symb_reg($word[2])) && (symb_reg($word[3]))) {
                generate_instruction_start($xw, $line_number, $word[0]);
                generate_argument($xw, "arg1", "label", $word[1]);
                generate_symbol($xw, $word, 2);
                generate_symbol($xw, $word, 3);
                generate_instruction_end($xw);
                $stat->incJumps();
            } else {
                exit(error_syntax_lex);
            }
            break;
        case 'RETURN':
        case 'BREAK':
        case 'CREATEFRAME':
        case 'PUSHFRAME':
        case 'POPFRAME':
            generate_instruction_start($xw, $line_number, $word[0]);
            generate_instruction_end($xw);
            break;
        case '#':
            break;
        default:
            
            if ($line_number == 0) {
                if (preg_match('/^.IPPcode20$/i', $word[0])) {
                    xmlwriter_start_element($xw, 'program');
                    xmlwriter_start_attribute($xw, 'language');
                    xmlwriter_text($xw, 'IPPcode20');
                    xmlwriter_end_attribute($xw);
                } else {
                    exit(error_missing_header);
                }
            } else if ($word[0] == "") {
                
            } else if (preg_match('/('. $instructions .')/', $word[0]) == 0) {
                exit(error_op_code);
            }
            
            break;
    }

    foreach ($word as $value) {
        if (preg_match('/#.*/', $value)) {
            $stat->incComments();
        }
    }
}
$stat->setLoc($line_number);

if($stat_exist){
    if(count($params) == 0)
        exit(error_output_file);
    $output_file = fopen($params['stat'], 'w') or exit(error_output_file);
    for ($i = 1; $i < $argc; $i++) {
        switch($argv[$i]){
            case '--loc':
                fwrite($output_file, $stat->getLoc() . "\n");
                break;
            case '--labels':
                fwrite($output_file, $stat->getLabels() . "\n");
                break;
            case '--jumps':
                fwrite($output_file, $stat->getJumps() . "\n");
                break;
            case '--comments':
                fwrite($output_file, $stat->getComments() . "\n");
                break;
            default:
                break;
        }  
    }
    fclose($output_file);
}

echo xmlwriter_output_memory($xw);
echo "</program>\n";

fclose($input_file);
exit(0);
