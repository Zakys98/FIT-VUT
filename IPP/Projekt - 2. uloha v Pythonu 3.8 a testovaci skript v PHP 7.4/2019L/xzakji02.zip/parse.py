"""
  Název: parse.py
  Vytvořil: Jiří Žák
  Datum: 28.3.2020
  Popis: pomocná třída interpretu do IPP
 """
import xml.etree.cElementTree as ET
from error import *
from instruction import Instruction
import operator

# třída na parsování xml reprezentace programu
class XMLParser:
    def __init__(self):
        self.instruction = 0

    def incInstruction(self):
        self.instruction += 1

    def parse(self, xmlInput, where, labels):
        if(where == False):
            try:
                tree = ET.ElementTree(ET.fromstring(xmlInput))
            except ET.ParseError:
                raise ExceptionXmlInputFormat()
        else:
            try:
                tree = ET.parse(xmlInput)
            except ET.ParseError:
                raise ExceptionXmlInputFormat()

        root = tree.getroot()
        if(root.tag != "program" or root.attrib.get('language') != 'IPPcode20'):
            raise ExceptionXmlLexSem()

        instructions = list()
        duplicity = list()          #duplicity order
        for instr in root:
            if(instr.tag == 'instruction'):
                
                if('order' not in instr.attrib.keys() or 'opcode' not in instr.attrib.keys()):
                    raise ExceptionXmlLexSem()

                if(instr.attrib['order'] in duplicity):
                    raise ExceptionXmlLexSem()
                else:
                    duplicity.append(instr.attrib['order'])

                try:
                    if(int(instr.attrib['order']) <= 0):
                        raise ExceptionXmlLexSem()
                except ValueError:
                    raise ExceptionXmlLexSem() 
                
                instr.attrib['opcode'] = instr.attrib['opcode'].upper()
                instructions.append(Instruction(instr, labels, self.instruction))
                self.incInstruction()
            else:
                raise ExceptionXmlLexSem()
        
        return sorted(instructions, key=operator.attrgetter('order'))
