"""
  Název: instruction.py
  Vytvořil: Jiří Žák
  Datum: 28.3.2020
  Popis: pomocná třída interpretu do IPP
 """
from error import *
from stacks import FrameStack, IStack
import sys
import re

# třída pro zpracování jednotlivých instrukcí
class Instruction:
    def __init__(self, instructionXML, labels, instruction_position):
        self.op_code = instructionXML.attrib['opcode']
        self.order = int(instructionXML.attrib['order'])
        self.arguments = []
        self.arguments_list = {
            'MOVE':         ["var", "symb"],
            'CREATEFRAME':  [],
            'PUSHFRAME':    [],
            'POPFRAME':     [],
            'DEFVAR':       ["var"],
            'CALL':         ["label"],
            'RETURN':       [],
            'PUSHS':        ["symb"],
            'POPS':         ["var"],
            'ADD':          ["var", "symb", "symb"],
            'SUB':          ["var", "symb", "symb"],
            'MUL':          ["var", "symb", "symb"],
            'IDIV':         ["var", "symb", "symb"],
            'LT':           ["var", "symb", "symb"],
            'GT':           ["var", "symb", "symb"],
            'EQ':           ["var", "symb", "symb"],
            'AND':          ["var", "symb", "symb"],
            'OR':           ["var", "symb", "symb"],
            'NOT':          ["var", "symb"],
            'STRI2INT':     ["var", "symb", "symb"],
            'INT2CHAR':     ["var", "symb"],
            'READ':         ["var", "type"],
            'WRITE':        ["symb"],
            'CONCAT':       ["var", "symb", "symb"],
            'STRLEN':       ["var", "symb"],
            'GETCHAR':      ["var", "symb", "symb"],
            'SETCHAR':      ["var", "symb", "symb"],
            'TYPE':         ["var", "symb"],
            'LABEL':        ["label"],
            'JUMP':         ["label"],
            'JUMPIFEQ':     ["label", "symb", "symb"],
            'JUMPIFNEQ':    ["label", "symb", "symb"],
            'EXIT':         ["symb"],
            'DPRINT':       ["symb"],
            'BREAK':        []
        }
        self.symb_list = ["string", "int", "float",
                          "nil", "bool", "GF", "LF", "TF"]
        self.var_list = ["GF", "LF", "TF"]
        self.type_list = ["type"]
    
        if(self.op_code not in self.arguments_list):    #kontrola jeslti tato instrukce vůbec existuje
            raise ExceptionXmlLexSem()

        args = list(instructionXML)
        if(args != None):
            for i in range(len(instructionXML)):
                if(args[i].tag not in ["arg1", "arg2", "arg3"]):
                    raise ExceptionXmlLexSem()
                a = dict()
                a['type'] = args[i].attrib['type']
                a['value'] = args[i].text
                if(a['type'] == "var"):
                    a['type'] = args[i].text.split('@')[0]
                    a['value'] = args[i].text.split('@')[1]
                self.arguments.append(a)

        if(self.op_code == "LABEL"):
            self.check_number_of_arguments()
            self.check_type_of_arguments()
            if(self.arguments[0]['value'] in labels):
                raise ExceptionUndefinedRedefinedLabel()
            labels[self.arguments[0]['value']] = instruction_position

#funkce, která kontrola správný počet argumentů
    def check_number_of_arguments(self):
        if(len(self.arguments) != len(self.arguments_list[self.op_code])):
            raise ExceptionXmlLexSem()
        return

#funkce, která kontroluje, jestli mají argumenty správné typy
    def check_type_of_arguments(self):
        for i in range(len(self.arguments)):
            if(self.arguments_list[self.op_code][i] == self.arguments[i]['type']):
                pass
            elif(self.arguments_list[self.op_code][i] == "symb" and self.arguments[i]['type'] in self.symb_list):
                pass
            elif(self.arguments_list[self.op_code][i] == "var" and self.arguments[i]['type'] in self.var_list):
                pass
            elif(self.arguments_list[self.op_code][i] == "type" and self.arguments[i]['type'] in self.type_list):
                pass
            else:
                raise ExceptionBadTypeOperands()

#funkce, která kontroluje, jestli je argument var
    def var(self, index):
        if(self.arguments[index]['type'] in self.var_list):
            return True
        return False

#funkce, která kontroluje, jestli je zadaná proměnná už ve frame_stacku
    def exists(self, frame_stack, index):
        if(self.arguments[index]['type'] == "GF"):
            if(self.arguments[index]['value'] in frame_stack.globalFrame):
                return True
            else:
                return False
        elif(self.arguments[index]['type'] == "LF"):
            if(len(frame_stack.stackFrame) < 1):
                raise ExceptionBadFrame()
            if(self.arguments[index]['value'] in frame_stack.stackFrame[-1]):
                return True
            else:
                return False
        elif(self.arguments[index]['type'] == "TF"):
            if(frame_stack.tmpFrame == None):
                raise ExceptionBadFrame()
            try:
                if(self.arguments[index]['value'] in frame_stack.tmpFrame.keys()):
                    return True
                else:
                    return False
            except AttributeError:
                return False
        else:
            return True

    def reg(self, text):
        match = re.findall(r'\\\d\d\d', text)
        for i in range(len(match)):
            lol = '\\' + match[i]
            hah = int(match[i][1:])
            text = re.sub(lol, str(chr(hah)), text)
        return text

#funkce na získání hodnoty z frame_stacku
    def get_from_frame(self, frame_stack, index): 
        if(self.arguments[index]['type'] == "GF"):
            if(self.arguments[index]['value'] in frame_stack.globalFrame):
                return frame_stack.globalFrame[self.arguments[index]['value']]
            else:
                raise ExceptionBadVariable()
        elif(self.arguments[index]['type'] == "LF"):
            if(len(frame_stack.stackFrame) < 1):
                raise ExceptionBadFrame()
            if(self.arguments[index]['value'] in frame_stack.stackFrame[-1]):
                return frame_stack.stackFrame[-1][self.arguments[index]['value']]
            else:
                raise ExceptionBadVariable()
        elif(self.arguments[index]['type'] == "TF"):
            if(frame_stack.tmpFrame == None):
                raise ExceptionBadFrame()
            if(self.arguments[index]['value'] in frame_stack.tmpFrame):
                return frame_stack.tmpFrame[self.arguments[index]['value']]
            else:
                raise ExceptionBadVariable()

#funkce, která uloží hodnotu do frame_stacku
    def save_value(self, frame_stack, which_frame, variable_name, value):
        if(which_frame == "GF"):
            if(variable_name in frame_stack.globalFrame):
                frame_stack.globalFrame[variable_name] = value
            else:
                raise ExceptionBadFrame()
        elif(which_frame == "LF"):
            if(frame_stack.stackFrame):
                frame_stack.stackFrame[-1][variable_name] = value
        elif (which_frame == "TF"):
            try:
                if(variable_name in frame_stack.tmpFrame.keys()):
                    frame_stack.tmpFrame[variable_name] = value    
            except AttributeError:
                raise ExceptionBadFrame()
        else:
            raise ExceptionXmlLexSem()

#funkce, která skočí na zadaný label
    def jump_label(self, labels, ip_stack, where):
        if(where in labels):
            ip_stack.position = labels[where]
        else:
            raise ExceptionUndefinedRedefinedLabel()

#funkce na interpretaci jednotlivých instrukcí
    def make_instruction(self, frame_stack, ip_stack, labels, data_stack):
        self.check_number_of_arguments()
        self.check_type_of_arguments()

        if(self.op_code == "MOVE"):

            if(self.exists(frame_stack, 0) == False):
                raise ExceptionBadVariable()

            symbol1_value = self.arguments[1]['value']
            symbol1_type = self.arguments[1]['type']
            if(self.var(1)):
                symbol1 = self.get_from_frame(frame_stack, 1)
                try:
                    symbol1_value = symbol1[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol1_type = symbol1[1]
            if(symbol1_value == None):
                symbol1_value = ""
            if(symbol1_type == "string"):
                symbol1_value = self.reg(symbol1_value)
            self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], [symbol1_value, symbol1_type])

        elif(self.op_code == "CREATEFRAME"):
            frame_stack.createFrame()
        elif(self.op_code == "PUSHFRAME"):
            frame_stack.pushFrame()
        elif(self.op_code == "POPFRAME"):
            frame_stack.popFrame()
        elif(self.op_code == "DEFVAR"):
            if(self.var(0)):
                if(self.arguments[0]['type'] == "GF"):
                    if(self.arguments[0]['value'] in frame_stack.globalFrame):
                        raise ExceptionUndefinedRedefinedLabel()
                    frame_stack.globalFrame[self.arguments[0]['value']] = None
                elif(self.arguments[0]['type'] == "LF"):
                    if(frame_stack.stackFrame):
                        pass
                    else:
                        raise ExceptionBadFrame()
                    try:
                        if(self.arguments[0]['value'] in frame_stack.stackFrame[-1]):
                            raise ExceptionUndefinedRedefinedLabel()
                    except AttributeError:
                        pass
                    frame_stack.stackFrame[-1][self.arguments[0]['value']] = None
                elif(self.arguments[0]['type'] == "TF"):
                    if(frame_stack.tmpFrame == None):
                        raise ExceptionBadFrame()
                    if(self.arguments[0]['value'] in frame_stack.tmpFrame.keys()):
                        raise ExceptionUndefinedRedefinedLabel()
                    frame_stack.tmpFrame[self.arguments[0]['value']] = None
                else:
                    raise ExceptionBadFrame()
            else:
                raise ExceptionBadTypeOperands()
        elif(self.op_code == "CALL"):
            ip_stack.pushIStack(ip_stack.position)
            self.jump_label(labels, ip_stack, self.arguments[0]['value'])
        elif(self.op_code == "RETURN"):
            ip_stack.position = ip_stack.popIStack()
        elif(self.op_code == "PUSHS"):
            if(self.exists(frame_stack, 0) == False):
                raise ExceptionBadVariable()
            data_stack.pushData([self.arguments[0]['value'], self.arguments[0]['type']])
        elif(self.op_code == "POPS"):
            if(self.exists(frame_stack, 0) == False):
                raise ExceptionBadVariable()
            return self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], data_stack.popData())
        elif(self.op_code in ["ADD", "SUB", "MUL", "IDIV"]):

            if(self.exists(frame_stack,0) == False):
                raise ExceptionBadVariable()

            symbol1_type = self.arguments[1]['type']
            symbol1_value = self.arguments[1]['value']
            if(self.var(1)):
                symbol1 = self.get_from_frame(frame_stack, 1)
                try:
                    symbol1_value = symbol1[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol1_type = symbol1[1]

            symbol2_type = self.arguments[2]['type']
            symbol2_value = self.arguments[2]['value']
            if(self.var(2)):
                symbol2 = self.get_from_frame(frame_stack, 2)
                try:
                    symbol2_value = symbol2[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol2_type = symbol2[1]

            if(symbol1_type != "int" or symbol2_type != "int"):
                raise ExceptionBadTypeOperands()
            
            try:
                symbol2_value = int(symbol2_value)
                symbol1_value = int(symbol1_value)
            except ValueError:
                raise ExceptionXmlLexSem()     

            value = 0
            if(self.op_code == "ADD"):
                value = symbol1_value + symbol2_value
            elif(self.op_code == "SUB"):
                value = symbol1_value - symbol2_value
            elif(self.op_code == "MUL"):
                value = symbol1_value * symbol2_value
            elif(self.op_code == "IDIV"):
                if(symbol2_value == 0):
                    raise ExceptionWrongOperandValue()
                value = symbol1_value / symbol2_value
                value = int(value)
            self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], [value, "int"])
            
        elif(self.op_code in ["LT", "GT", "EQ"]):
            
            if(self.exists(frame_stack, 0) == False):
                raise ExceptionBadVariable()

            symbol1_type = self.arguments[1]['type']
            symbol1_value = self.arguments[1]['value']
            if(self.var(1)):
                symbol1 = self.get_from_frame(frame_stack, 1)
                try:
                    symbol1_value = symbol1[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol1_type = symbol1[1]

            symbol2_type = self.arguments[2]['type']
            symbol2_value = self.arguments[2]['value']
            if(self.var(2)):
                symbol2 = self.get_from_frame(frame_stack, 2)
                try:
                    symbol2_value = symbol2[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol2_type = symbol2[1]

            if(self.op_code != "EQ"):
                if(symbol1_type != symbol2_type or symbol1_type == "nil" or symbol2_type == "nil"):
                    raise ExceptionBadTypeOperands()
            else:
                if(symbol1_type != "nil" and symbol2_type != "nil"):
                    if(symbol1_type != symbol2_type):
                        raise ExceptionBadTypeOperands()

            if(symbol1_type == "string" and symbol1_value == None):
                symbol1_value = ""
            else:
                symbol1_value = self.reg(symbol1_value)
            if(symbol2_type == "string" and symbol2_value == None):
                symbol2_value = ""
            else:
                symbol2_value = self.reg(symbol2_value)

            value = 'true'
            if(self.op_code == "EQ"):
                if(symbol1_value == symbol2_value):
                    value = 'true'
                else:
                    value = 'false'
            elif(self.op_code == "LT"):
                if(symbol1_type == "int"):
                    if(int(symbol1_value) < int(symbol2_value)):
                        value = 'true'
                    else:
                        value = 'false'
                elif(symbol1_type == "bool"):
                    if(symbol1_value == 'false' and symbol2_value == 'true'):
                        value = 'true'
                    else:
                        value = 'false'
                else:
                    if(symbol1_value == None): #kontrola jestli tam neco je
                        symbol1_value = ""
                    else:
                        symbol1_value = self.reg(symbol1_value)
                    if(symbol2_value == None): #kontrola jeslti tam neco je
                        symbol2_value = ""
                    else:
                        symbol2_value = self.reg(symbol2_value)
                    if(symbol1_value < symbol2_value):
                        value = 'true'
                    else:
                        value = 'false'
            else:
                if(symbol1_type == "int"):
                    if(int(symbol1_value) > int(symbol2_value)):
                        value = 'true'
                    else:
                        value = 'false'
                elif(symbol1_type == "bool"):
                    if(symbol1_value == 'true' and symbol2_value == 'false'):
                        value = 'true'
                    else:
                        value = 'false'
                else:
                    if(symbol1_value > symbol2_value):
                        value = 'true'
                    else:
                        value = 'false'

            self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], [value, "bool"])
     
        elif(self.op_code in ["AND", "OR"]):

            if(self.exists(frame_stack, 0) == False):
                raise ExceptionBadVariable()

            symbol1_type = self.arguments[1]['type']
            symbol1_value = self.arguments[1]['value']
            if(self.var(1)):
                symbol1 = self.get_from_frame(frame_stack, 1)
                try:
                    symbol1_value = symbol1[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol1_type = symbol1[1]
            
            symbol2_type = self.arguments[2]['type']
            symbol2_value = self.arguments[2]['value']
            if(self.var(2)):
                symbol2 = self.get_from_frame(frame_stack, 2)
                try:
                    symbol2_value = symbol2[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol2_type = symbol2[1]

            if(symbol1_type != "bool" or symbol2_type != "bool"):
                raise ExceptionBadTypeOperands()

            value = 'true'
            if(self.op_code == "AND"):
                if(symbol1_value == symbol2_value == 'true'):
                    value = 'true'
                else:
                    value = 'false'
            else:
                if(symbol1_value == 'true' or symbol2_value == 'true'):
                    value = 'true'
                else:
                    value = 'false'
            self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], [value, "bool"])

        elif(self.op_code == "NOT"):
            
            if(self.exists(frame_stack, 0) == False):
                raise ExceptionBadVariable()

            symbol1_value = self.arguments[1]['value']
            symbol1_type = self.arguments[1]['type']
            if(self.var(1)):
                symbol1 = self.get_from_frame(frame_stack, 1)
                try:
                    symbol1_value = symbol1[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol1_type = symbol1[1]

            if(symbol1_type != "bool"):
                raise ExceptionBadTypeOperands()

            if(symbol1_value == "false" or symbol1_value == False):
                symbol1_value = False
            else: 
                symbol1_value = True
            value = not symbol1_value
            if(value):
                value = "true"
            else:
                value = "false"
            self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], [value, "bool"])

        elif(self.op_code == "INT2CHAR"):
            
            if(self.exists(frame_stack, 0) == False):
                raise ExceptionBadVariable()

            symbol1_value = self.arguments[1]['value']
            symbol1_type = self.arguments[1]['type']
            if(self.var(1)):
                symbol = self.get_from_frame(frame_stack, 1)
                try:
                    symbol1_value = symbol[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol1_type = symbol[1]
                
            try:    
                symbol1_value = int(symbol1_value)
            except ValueError:
                raise ExceptionBadTypeOperands()
            try:
                chr(symbol1_value)
            except ValueError:
                raise ExceptionString()

            value = chr(symbol1_value)
            self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], [value, "string"])
        
        elif(self.op_code == "READ"):
            
            if(self.exists(frame_stack, 0) == False):
                raise ExceptionBadVariable()

            try:
                value = input()
            except EOFError:
                value = "nil"
                self.arguments[1]['value'] = ""

            if(self.arguments[1]['value'] == "int"):
                try:
                    value = int(value)
                except ValueError:
                    value = "nil"
                    self.arguments[1]['value'] = ""
            elif(self.arguments[1]['value'] == "bool"):
                value = value.lower()
                if(value == "true"):
                    pass
                elif(value != "nil"):
                    value = "false"
                else:
                    pass

            elif(self.arguments[1]['value'] == "string"):
                self.arguments[1]['value'] = self.reg(self.arguments[1]['value'])
            self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], [value, self.arguments[1]['value']])

        elif(self.op_code == "WRITE"):

            type = self.arguments[0]['type']
            value = self.arguments[0]['value']
            if(self.var(0)):
                symbol = self.get_from_frame(frame_stack, 0)
                try:
                    value = symbol[0]
                except TypeError:
                    raise ExceptionMissingValue()
                type = symbol[1]

            if(type == "string" and value != None):
                value = self.reg(value)

            if(type == "nil"):
                print("", end="")
            else:
                print(value, end="")

        elif(self.op_code == "CONCAT"):
            
            if(self.exists(frame_stack, 0) == False):
                raise ExceptionBadVariable()

            symbol1_value = self.arguments[1]['value']
            symbol1_type = self.arguments[1]['type']
            if(self.var(1)):
                symbol1 = self.get_from_frame(frame_stack, 1)
                try:
                    symbol1_value = symbol1[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol1_type = symbol1[1]

            symbol2_type = self.arguments[2]['type']
            symbol2_value = self.arguments[2]['value']
            if(self.var(2)):
                symbol2 = self.get_from_frame(frame_stack, 2)
                try:
                    symbol2_value = symbol2[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol2_type = symbol2[1]

            if(symbol1_type != "string" or symbol2_type != "string"):
                raise ExceptionBadTypeOperands()

            if(symbol1_value == None):
                symbol1_value = ""
            else:
                symbol1_value = self.reg(symbol1_value)
            if(symbol2_value == None):
                symbol2_value = ""
            else:
                symbol2_value = self.reg(symbol2_value)
            self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], [symbol1_value + symbol2_value, "string"])

        elif(self.op_code == "STRLEN"):
            
            if(self.exists(frame_stack, 0) == False):
                raise ExceptionBadVariable()

            symbol1_value = self.arguments[1]['value']
            symbol1_type = self.arguments[1]['type']
            if(self.var(1)):
                symbol1 = self.get_from_frame(frame_stack, 1)
                try:
                    symbol1_value = symbol1[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol1_type = symbol1[1]
            
            if(symbol1_type != "string"):
                raise ExceptionBadTypeOperands()
            try:
                value = len(symbol1_value)
            except TypeError:
                value = 0
            self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], [value, "int"])

        elif(self.op_code in ["GETCHAR", "STRI2INT"]):
            
            if(self.exists(frame_stack, 0) == False):
                raise ExceptionBadVariable()

            symbol1_value = self.arguments[1]['value']
            symbol1_type = self.arguments[1]['type']
            if(self.var(1)):
                symbol1 = self.get_from_frame(frame_stack, 1)
                try:
                    symbol1_value = symbol1[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol1_type = symbol1[1]

            symbol2_type = self.arguments[2]['type']
            symbol2_value = self.arguments[2]['value']
            if(self.var(2)):
                symbol2 = self.get_from_frame(frame_stack, 2)
                try:
                    symbol2_value = symbol2[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol2_type = symbol2[1]

            try:
                symbol2_value = int(symbol2_value)
            except ValueError:
                raise ExceptionBadTypeOperands()

            if(self.op_code == "GETCHAR"):
                if(symbol1_type != "string" or symbol2_type != "int"):
                    raise ExceptionBadTypeOperands()
                if(symbol2_value >= len(symbol1_value) or symbol2_value < 0):
                    raise ExceptionString()
                self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], [symbol1_value[symbol2_value], "string"])
            else:
                if(symbol1_type != "string" or symbol2_type != "int"):
                    raise ExceptionBadTypeOperands()
                if(symbol2_value >= len(symbol1_value) or symbol2_value < 0):
                    raise ExceptionString()
                self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], [ord(symbol1_value[symbol2_value]), "int"])
       
        elif(self.op_code == "SETCHAR"):

            symbol1_value = self.arguments[1]['value']
            symbol1_type = self.arguments[1]['type']
            if(self.var(1)):
                symbol1 = self.get_from_frame(frame_stack, 1)
                try:
                    symbol1_value = symbol1[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol1_type = symbol1[1]

            symbol2_type = self.arguments[2]['type']
            symbol2_value = self.arguments[2]['value']
            if(self.var(2)):
                symbol2 = self.get_from_frame(frame_stack, 2)
                try:
                    symbol2_value = symbol2[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol2_type = symbol2[1]

            if(symbol1_type != "int" or symbol2_type != "string"):
                    raise ExceptionBadTypeOperands()
            
            symbol1_value = int(symbol1_value)
            if(symbol2_value != None):
                symbol2_value = self.reg(symbol2_value)
            var = self.get_from_frame(frame_stack, 0)
            try:
                var_value = var[0]
            except TypeError:
                raise ExceptionMissingValue()
            if(var[1] != "string"):
                raise ExceptionBadTypeOperands()
            if(symbol1_value >= len(var_value) or symbol1_value < 0 or (symbol2_value == "")):
                raise ExceptionString()
            str = list(var_value)
            if(symbol2_value == None):
                raise ExceptionString()
            symbol2_value = list(symbol2_value)
            str[symbol1_value] = symbol2_value[0]
            value = ''.join(str)
            self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], [value, "string"])

        elif(self.op_code == "TYPE"):
            
            if(self.exists(frame_stack, 0) == False):
                raise ExceptionBadVariable()

            symbol1_type = self.arguments[1]['type']
            if(self.var(1)):
                symbol1 = self.get_from_frame(frame_stack, 1)
                if(symbol1 is None):
                    symbol1_type = None
                else:
                    symbol1_type = symbol1[1]

            if(symbol1_type is None):
                value = ""
            else:
                value = symbol1_type
            self.save_value(frame_stack, self.arguments[0]['type'], self.arguments[0]['value'], [value, "string"])

        elif(self.op_code == "LABEL"):
            pass
        elif(self.op_code == "JUMP"):   
            self.jump_label(labels, ip_stack, self.arguments[0]['value'])
        elif(self.op_code in ["JUMPIFEQ", "JUMPIFNEQ"]):

            symbol1_type = self.arguments[1]['type']
            symbol1_value = self.arguments[1]['value']
            if(self.var(1)):
                symbol1 = self.get_from_frame(frame_stack, 1)
                try:
                    symbol1_value = symbol1[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol1_type = symbol1[1]

            symbol2_type = self.arguments[2]['type']
            symbol2_value = self.arguments[2]['value']
            if(self.var(2)):
                symbol2 = self.get_from_frame(frame_stack, 2)
                try:
                    symbol2_value = symbol2[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol2_type = symbol2[1]

            if(symbol1_type != "nil" and symbol2_type != "nil"): 
                if(symbol1_type != symbol2_type):
                    raise ExceptionBadTypeOperands()

            if(symbol1_type == "int"):
                symbol1_value = int(symbol1_value)
            if(symbol2_type == "int"):
                symbol2_value = int(symbol2_value)
            if(symbol1_type == "string" and symbol1_value != None):
                symbol1_value = self.reg(symbol1_value)
            if(symbol2_type == "string" and symbol2_value != None):
                symbol2_value = self.reg(symbol2_value)

            if(self.arguments[0]['value'] not in labels.keys()):
                raise ExceptionUndefinedRedefinedLabel()

            if(self.op_code == "JUMPIFEQ"):
                if(symbol1_value == symbol2_value):
                    self.jump_label(labels, ip_stack, self.arguments[0]['value'])
            else:
                if(symbol1_value != symbol2_value):
                    self.jump_label(labels, ip_stack, self.arguments[0]['value'])

        elif(self.op_code == "EXIT"):

            symbol1_type = self.arguments[0]['type']
            symbol1_value = self.arguments[0]['value']
            if(self.var(0)):
                symbol1 = self.get_from_frame(frame_stack, 0)
                try:
                    symbol1_value = symbol1[0]
                except TypeError:
                    raise ExceptionMissingValue()
                symbol1_type = symbol1[1]

            try:
                symbol1_value = int(symbol1_value)    
            except ValueError:
                raise ExceptionBadTypeOperands()
            
            if(symbol1_type != "int"):
                raise ExceptionBadTypeOperands()

            if(0 <= symbol1_value <= 49):
                sys.exit(int(symbol1_value))
            else:
                raise ExceptionWrongOperandValue()

        elif(self.op_code == "DPRINT"):

            value = self.arguments[0]['value']
            if(self.var(0)):
                symbol1 = self.get_from_frame(frame_stack, 0)
                value = symbol1[0]
            print(value, file=sys.stderr)

        elif(self.op_code == "BREAK"):
            print(self.order, file=sys.stderr)
            print(frame_stack.globalFrame, file=sys.stderr)
            print(frame_stack.stackFrame, file=sys.stderr)
            print(frame_stack.tmpFrame, file=sys.stderr)
