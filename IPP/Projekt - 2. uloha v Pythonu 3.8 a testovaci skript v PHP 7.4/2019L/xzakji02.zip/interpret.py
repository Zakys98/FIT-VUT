"""
  Název: interpret.py
  Vytvořil: Jiří Žák
  Datum: 28.3.2020
  Popis: interpret do IPP
 """

import sys
import getopt
from error import *
from parse import XMLParser
from stacks import *

# třída pro interpretování instrukcí
class Interpret():
    def __init__(self, instructions):
        self.frame = FrameStack()
        self.instruction_list = instructions
        self.ipStack = IStack()
        self.data_stack = DataStack()

    def run(self, labels):
        if(self.instruction_list != None):
            while self.ipStack.position in range(0, len(self.instruction_list)):
                #print(self.instruction_list[self.ipStack.position].order, self.instruction_list[self.ipStack.position].op_code)
                self.instruction_list[self.ipStack.position].make_instruction(self.frame, self.ipStack, labels, self.data_stack)
                self.ipStack.position += 1;

def main():
    try:
        options, remainder = getopt.getopt(sys.argv[1:], '', ['help', 'source=', 'input=', 'stat=', 'insts', 'vars'])
    except getopt.GetoptError:
        raise ExceptionMissingParam

    if (len(remainder) != 0):           # zadany nejaky parametr navic
        raise ExceptionMissingParam
    
    checkSource = False
    checkInput = False
    source_file_name = ""
    input_file_name = ""
    for i in range(len(options)):
        if(options[i][0] == "--help" and len(options) == 1): #kontrola jestli kdyz tam je help, tak jestli je sam
            print("help")
            raise OK
        elif(options[i][0] == "--help" and len(options) != 1): # error protoze neni sam
            raise ExceptionMissingParam
        if(options[i][0] == "--source" and options[i][1] != ""):
            source_file_name = options[i][1]
            checkSource = True
        if(options[i][0] == "--input" and options[i][1] != ""):
            input_file_name = options[i][1]
            checkInput = True

    if(checkInput == False and checkSource == False):   #kdyz chybi jak input tak source
        raise ExceptionMissingParam

    if(checkInput == False):
        pass
    else:
        try:
            sys.stdin = open(input_file_name, "r")
        except IOError:
            raise ExceptionInputFile
    
    if(checkSource == False):
        source_file = sys.stdin.read()
        where = False
    else:
        try:
            source_file = open(source_file_name, "r")
            where = True
        except IOError:
            raise ExceptionOutputFile

    labels = dict()
    xml_parser = XMLParser()
    instructions = xml_parser.parse(source_file, where, labels)

    interpret = Interpret(instructions)
    interpret.run(labels)
    

if __name__ == "__main__":
    error = Error()
    try:
        main() 
    except ExceptionMissingParam:
        #print(error.error_missing_param)
        sys.exit(error.error_missing_param)
    except ExceptionInputFile:
        sys.exit(error.error_input_file)
    except ExceptionOutputFile:
        #print(error.error_output_file)
        sys.exit(error.error_output_file)
    except ExceptionXmlInputFormat:
        #print(error.error_xml_input_format)
        sys.exit(error.error_xml_input_format)
    except ExceptionXmlLexSem:
        #print(error.error_xml_lex_sem)
        sys.exit(error.error_xml_lex_sem)
    except ExceptionBadTypeOperands:
        #print(error.error_bad_type_operands)
        sys.exit(error.error_bad_type_operands)
    except ExceptionBadVariable:
        #print(error.error_bad_variable)
        sys.exit(error.error_bad_variable)
    except ExceptionBadFrame:
        #print(error.error_bad_frame)
        sys.exit(error.error_bad_frame)
    except ExceptionWrongOperandValue:
        #print(error.error_wrong_operand_value)
        sys.exit(error.error_wrong_operand_value)
    except ExceptionUndefinedRedefinedLabel:
        #print(error.error_undefined_redefined_label)
        sys.exit(error.error_undefined_redefined_label)
    except ExceptionString:
        #print(error.error_string)
        sys.exit(error.error_string)
    except ExceptionMissingValue:
        #print(error.error_missing_value)
        sys.exit(error.error_missing_value)
    except ExceptionInternal:
        #print(error.error_internal)
        sys.exit(error.error_internal)
    except OK:
        pass

    sys.exit(error.OK)
