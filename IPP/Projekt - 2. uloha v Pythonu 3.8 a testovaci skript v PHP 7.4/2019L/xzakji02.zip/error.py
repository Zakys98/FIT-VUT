"""
  Název: error.py
  Vytvořil: Jiří Žák
  Datum: 28.3.2020
  Popis: pomocná třída interpretu do IPP
 """
 # třída se všema chybama, které se během interpretace mohou vyskytnout
class Error:
    def __init__(self):
        self.OK = 0

        self.error_missing_param = 10 
        self.error_input_file = 11
        self.error_output_file = 12

        self.error_xml_input_format = 31
        self.error_xml_lex_sem = 32

        self.error_undefined_redefined_label = 52
        self.error_bad_type_operands = 53
        self.error_bad_variable = 54
        self.error_bad_frame = 55
        self.error_missing_value = 56
        self.error_wrong_operand_value = 57
        self.error_string = 58

        self.error_internal = 99
class OK(Exception):
    pass
class ExceptionMissingParam(Exception):
    pass
class ExceptionInputFile(Exception):
    pass
class ExceptionOutputFile(Exception):
    pass
class ExceptionXmlInputFormat(Exception):
    pass
class ExceptionXmlLexSem(Exception):
    pass
class ExceptionUndefinedRedefinedLabel(Exception):
    pass
class ExceptionBadTypeOperands(Exception):
    pass
class ExceptionBadVariable(Exception):
    pass
class ExceptionBadFrame(Exception):
    pass
class ExceptionMissingValue(Exception):
    pass
class ExceptionWrongOperandValue(Exception):
    pass
class ExceptionString(Exception):
    pass
class ExceptionInternal(Exception):
    pass