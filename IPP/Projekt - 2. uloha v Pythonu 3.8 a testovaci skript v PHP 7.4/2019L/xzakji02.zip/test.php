<?php

/**
 * Název: test.php
 * Vytvořil: Jiří Žák
 * Datum: 28.3.2020
 * Popis: Pomocný testovací program do IPP
 */

$arguments = new Arguments();
$arguments->parse_arguments();
$scan = new ScanDirectory();
$scan->scanDirs($arguments->directory, $arguments->recursive);
$tmp_file = new TmpFile();
$HTML = new HTMLgenerator($scan);

foreach ($scan->dirs as $dir) {
    foreach ($scan->files[$dir] as $test) {
        $src_file = $dir . $test['name'] . ".src";
        $rc_file = $dir . $test['name'] . ".rc";
        $in_file = $dir . $test['name'] . ".in";
        $out_file = $dir . $test['name'] . ".out";

        unset($array);
        $tmp_file->reset();
        if ($arguments->parse_only) {
            exec('php7.4 ' . $arguments->parse_script . '<' . $src_file, $array, $ret_code_parse);
            if ($ret_code_parse == file_get_contents($rc_file)) {
                $tmp_file->write($array);
                if ($ret_code_parse == 0) {
                    exec('java -jar ' . $arguments->jexamxml . ' ' . $out_file . ' ' . $tmp_file->getPwd() . ' -D /pub/courses/ipp/jexamxml/options', $alalal, $ret_code_jexam);
                    if ($ret_code_jexam == 0) {
                        $scan->addResult($dir, $test['name'], 0, '', true);
                    } else {
                        $scan->addResult($dir, $test['name'], 0, '', false);
                    }
                } else {
                    $scan->addResult($dir, $test['name'], $ret_code_parse, '', true);
                }
            } else {
                $scan->addResult($dir, $test['name'], $ret_code_parse, '', false);
            }
        } elseif ($arguments->int_only) {
            exec('python3.8 ' . $arguments->int_script . ' --source=' . $src_file . '<' . $in_file, $array, $ret_code_int);
            if ($ret_code_int == file_get_contents($rc_file)) {
                $tmp_file->write($array);
                if ($ret_code_int == 0) {
                    exec('diff ' . $tmp_file->getPwd() . ' ' . $out_file, $alalal, $ret_code_diff);
                    if ($ret_code_diff == 0) {
                        $scan->addResult($dir, $test['name'], '', 0, true);
                    } else {
                        $scan->addResult($dir, $test['name'], '', 0, false);
                    }
                } else {
                    $scan->addResult($dir, $test['name'], '', $ret_code_int, true);
                }
            } else {
                $scan->addResult($dir, $test['name'], '', $ret_code_int, false);
            }
        } else {
            exec('php7.4 ' . $arguments->parse_script . '<' . $src_file, $array, $ret_code_parse);
            if ($ret_code_parse == 0) {
                $tmp_file->write($array);
                unset($array);
                exec('python3.8 ' . $arguments->int_script . ' --source=' . $tmp_file->getPwd() . '<' . $in_file, $array, $ret_code_int);
                $tmp_file->reset();
                $tmp_file->write($array);
                if ($ret_code_int == file_get_contents($rc_file)) { // spravny navratovy kod interpretu
                    if ($ret_code_int == 0) {
                        exec('diff ' . $tmp_file->getPwd() . ' ' . $out_file, $alalal, $ret_code_diff);
                        if ($ret_code_diff == 0) {
                            $scan->addResult($dir, $test['name'], 0, 0, true);
                        } else {
                            $scan->addResult($dir, $test['name'], 0, 0, false);
                        }
                    } else {
                        $scan->addResult($dir, $test['name'], 0, $ret_code_int, true);
                    }
                } else { // spatny navratovy kod interpretu
                    $scan->addResult($dir, $test['name'], 0, $ret_code_int, false);
                }
            } else { // parser chybovy kod
                if ($ret_code_parse == file_get_contents($rc_file)) {
                    $scan->addResult($dir, $test['name'], $ret_code_parse, '', true);
                } else {
                    $scan->addResult($dir, $test['name'], $ret_code_parse, '', false);
                }
            }
        }
    }
}

$HTML->generate();

/**
 * Třída pro scanování složek
 */
class ScanDirectory
{
    public $dirs;
    public $files;
    /**
     * Konstruktor
     */
    public function __construct()
    {
        $this->dirs = [];
        $this->files = [];
    }
    private function getName($ooh)
    {
        return preg_replace('/^(.*\/)?(.+)\.src$/', '\2', $ooh);
    }
    private function getDir($ooh)
    {
        return preg_replace('/^(.*\/).+\.(in|out|rc|src)$/', '\1', $ooh);
    }
    public function scanDirs($dira, $recursive)
    {
        $directory = new RecursiveDirectoryIterator($dira);
        if ($recursive) {
            $iter = new RecursiveIteratorIterator($directory);
        } else {
            $iter = new IteratorIterator($directory);
        }

        $reg = new RegexIterator($iter, '/^.+\.src$/i', REGEXITERATOR::GET_MATCH);
        foreach ($reg as $file) {
            $file_name = $this->getName($file[0]);
            $dir = $this->getDir($file[0]);
            $this->files[$dir][$file_name]['name'] = $file_name;
            if (!in_array($dir, $this->dirs))
                $this->dirs[] = $dir;

            if (!file_exists($dir . $file_name . ".rc"))
                file_put_contents($dir . $file_name . ".rc", "0");
            if (!file_exists($dir . $file_name . ".in"))
                file_put_contents($dir . $file_name . ".in", "");
            if (!file_exists($dir . $file_name . ".out"))
                file_put_contents($dir . $file_name . ".out", "");
        }
    }
    /**
     * Zapíše výsledky testů do files
     */
    public function addResult($directory, $fileName, $parseReturn, $intReturn, $result)
    {
        $this->files[$directory][$fileName]['parse'] = $parseReturn;
        $this->files[$directory][$fileName]['int'] = $intReturn;
        $this->files[$directory][$fileName]['result'] = $result;
    }
}

/**
 * Třída pro generování HTML stránky
 */
class HTMLgenerator
{
    public $scan_directory;
    public function __construct($scanDir)
    {
        $this->scan_directory = $scanDir;
    }
    public function generate()
    {
        $testCounter = 0;
        $testCodePass = 0;
        $testPass = 0;
        $web =
            "<!DOCTYPE html>
        <html>
        <head>
            <meta charset=\"utf-8\">
            <title>IPP TEST</title>
            <style>
		        h1{
			        text-align: center;
		        }
		        table{
			        width: 100%;
                }
                tr:hover {
                    background-color: yellow;
                }
		        th {
                    border-style: dashed;
                }
                td {
                    text-align: center;
                    border-style: inset;
                }
	        </style>
        </head>
        <body>
        <h1>IPP test</h1>
        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Zdroj</th>
                    <th>Parse</th>
                    <th>Interpret</th>
                    <th>Očekávající návratový kod</th>
                    <th>Navrácený kod</th>
                    <th>Výsledek</th>
                </tr>
            </thead>";

        foreach ($this->scan_directory->dirs as $dir) {
            $testDirCounter = 0;
            $testDirCodePass = 0;
            $testDirPass = 0;
            foreach ($this->scan_directory->files[$dir] as $test) {
                $testDirCounter++;
                $src_file = $test['name'] . ".src";
                $rc_file = $dir . $test['name'] . ".rc";
                $web = $web . "<tr>";
                $testCounter++;
                $web = $web . "<td>" . $testCounter . "</td>\n";
                $web = $web . "<td>" . $src_file . "</td>\n";
                $web = $web . "<td>" . $test['parse'] . "</td>\n";
                $web = $web . "<td>" . $test['int'] . "</td>\n";
                $web = $web . "<td>" . file_get_contents($rc_file) . "</td>\n";
                if (($test['int'] == "" && $test['parse'] == file_get_contents($rc_file)) || ($test['int'] == file_get_contents($rc_file))) {
                    $web = $web . "<td>&#10004;</td>\n";
                    $testCodePass++;
                    $testDirCodePass++;
                } else {
                    $web = $web . "<td>&#10007;</td>\n";
                }
                if ($test['result']) {
                    $web = $web . "<td>&#10004;</td>\n";
                    $testPass++;
                    $testDirPass++;
                } else {
                    $web = $web . "<td>&#10007;</td>\n";
                }
                $web = $web . "</tr>\n";
            }
            $web = $web . "
            <tr style='background-color: #87CEEB'>
                <td>Dir results</td>
                <td>" . $dir . "</td>
                <td>" . $testDirCounter . "</td>
                <td>" . $testDirCodePass . "</td>
                <td>" . $testDirPass . "</td> 
            </tr>
            ";
        }

        $web = $web . "
            <tr style='background-color: #9ACD32'>
                <td>Results</td>
                <td>Numer of tests: " . $testCounter . "</td>
                <td>" . $testCodePass . "</td>
                <td>" . $testPass . "</td> 
            </tr>
        </table>
        </body>
        </html> ";
        echo $web;
    }
}

/**
 * Třída pro dočasný soubor
 */
class TmpFile
{
    public $file;
    /**
     * Konstruktor
     */
    public function __construct()
    {
        $this->create();
    }
    /**
     * Vytvoření dočasného souboru
     */
    public function create()
    {
        $this->file = tmpfile();
    }
    /**
     * Smazání dočasného souboru
     */
    public function close()
    {
        fclose($this->file);
    }
    /**
     * Smazání a pak vytvoření dočasného souboru
     */
    public function reset()
    {
        $this->close();
        $this->create();
    }
    /**
     * Zapsání výsledků do souboru
     */
    public function write($array)
    {
        fwrite($this->file, implode("\n", $array));
    }
    /**
     * Vrací složku kde je dočasný soubor uložený
     */
    public function getPwd()
    {
        return stream_get_meta_data($this->file)['uri'];
    }
}
/**
 * Třída pro parsování argumentů
 */
class Arguments
{
    public $directory;
    public $recursive;
    public $parse_script;
    public $int_script;
    public $parse_only;
    public $int_only;
    public $jexamxml;
    public function __construct()
    {
        $this->directory = getcwd() . '/';
        $this->recursive = false;
        $this->parse_script = "./parse.php";
        $this->int_script = "./interpret.py";
        $this->parse_only = false;
        $this->int_only = false;
        $this->jexamxml = "/pub/courses/ipp/jexamxml/jexamxml.jar";
    }
    public function parse_arguments()
    {
        global $argc;
        $validArgs = 0;
        $opt = getopt("", ["help", "directory:", "recursive", "parse-script:", "int-script:", "parse-only", "int-only", "jexamxml:"]);
        if ($argc == 1) {
            if (!file_exists($this->parse_script)) {
                exit(10);
            }
            if (!file_exists($this->int_script)) {
                exit(10);
            }
        } else {
            if (array_key_exists('help', $opt)) {
                if ($argc == 2) {
                    print("help");
                    exit(0);
                } else {
                    exit(10);
                }
            }
            if (array_key_exists('recursive', $opt)) {
                $this->recursive = true;
                $validArgs++;
            }
            if (array_key_exists('directory', $opt)) {
                if (substr($opt['directory'], -1) != '/')
                    $opt['directory'] = $opt['directory'] . "/";
                $this->directory = $opt['directory'];
                $validArgs++;
            }
            if (array_key_exists('parse-script', $opt)) {
                $this->parse_script = $opt['parse-script'];
                $validArgs++;
            }
            if (array_key_exists('int-script', $opt)) {
                $this->int_script = $opt['int-script'];
                $validArgs++;
            }
            if (array_key_exists('parse-only', $opt)) {
                $this->parse_only = true;
                $validArgs++;
            }
            if (array_key_exists('int-only', $opt)) {
                $this->int_only = true;
                $validArgs++;
            }
            if (array_key_exists('jexamxml', $opt)) {
                $this->jexamxml = $opt['jexamxml'];
                $validArgs++;
            }
            if ($validArgs != $argc - 1) {
                exit(10);
            }
        }
        if ($this->int_only == true) {
            if ($this->parse_only == true || strcmp($this->parse_script, "./parse.php") != 0) {
                exit(10);
            }
        }
        if ($this->parse_only == true) {
            if ($this->int_only == true || strcmp($this->int_script, "./interpret.py") != 0) {
                exit(10);
            }
        }
        if (!file_exists($this->directory))
            exit(11);
        if ($this->parse_only == false) {
            if (!file_exists($this->int_script))
                exit(10);
        }
        if ($this->int_only == false) {
            if (!file_exists($this->parse_script))
                exit(10);
        }
    }
}
