"""
  Název: stacks.py
  Vytvořil: Jiří Žák
  Datum: 28.3.2020
  Popis: pomocná třída interpretu do IPP
 """
from error import *

# třída pro frame_stack
class FrameStack():
    def __init__(self):
        self.stackFrame = []
        self.globalFrame = {}
        self.tmpFrame = None

    def createFrame(self):
        self.tmpFrame = dict()

    def pushFrame(self):
        if(self.tmpFrame == None):
            raise ExceptionBadFrame()
        self.stackFrame.append(self.tmpFrame)
        self.tmpFrame = None

    def popFrame(self):
        if(len(self.stackFrame) == 0):
            raise ExceptionBadFrame()
        self.tmpFrame = self.stackFrame.pop()

# třída pro ip_stack
class IStack():
    def __init__(self):
        self.iStack = list()
        self.position = 0

    def pushIStack(self, ip):
        self.iStack.append(ip)

    def popIStack(self):
        if(self.iStack):
            return self.iStack.pop()
        else:
            raise ExceptionMissingValue()

# třída pro data_stack
class DataStack():
    def __init__(self):
        self.dataStack = list()

    def pushData(self, new):
        self.dataStack.append(new)

    def popData(self):
        if(self.dataStack):
            return self.dataStack.pop()
        else:
            raise ExceptionMissingValue()