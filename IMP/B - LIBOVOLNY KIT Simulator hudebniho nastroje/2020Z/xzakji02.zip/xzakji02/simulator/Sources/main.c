/**
 * Projekt: Mikroprocesorove a vestavene systemy
 * Autor: Jiri Zak (xzakji02)
 */

#include "MK60D10.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SPK 0x10

#define INIT_ALLOC_SIZE 10
#define OK 0
#define FAIL 1

#define C_4 262
#define D_4 293
#define DS_4 311
#define E_4 330
#define F_4 349
#define G_4 392
#define GS_4 415
#define A_4 440
#define B_4 494
#define C_5 523
#define D_5 587
#define DS_5 622
#define E_5 659
#define F_5 699
#define G_5 784
#define A_5 880
#define B_5 988
#define PA  1

#define osminova 400
#define ctvrtova 800
#define polova   1600

#define inputFrequence 3000000

typedef struct {
    char *pString;
    int length;
    int allocLength;
} string;

typedef struct {
    int frequency;
    int delay;
} tone;

tone my_song [] = {{E_5, osminova},{DS_5, osminova},{E_5, osminova},{DS_5, osminova},{E_5, osminova},{B_4, osminova},{D_5, osminova},{C_5, osminova},{A_4, ctvrtova},{PA, osminova},
{C_4, osminova},{E_4, osminova},{A_4, osminova},{B_4, ctvrtova},{PA, osminova},
{E_4, osminova},{GS_4, osminova},{B_4, osminova},{C_5, ctvrtova},{PA,osminova},
{E_4, osminova},{E_5, osminova},{DS_5, osminova},{E_5, osminova},{DS_5, osminova},{E_5, osminova},{B_4, osminova},{D_5, osminova},{C_5, osminova},{A_4, ctvrtova},{PA, osminova},
{C_4, osminova},{E_4, osminova},{A_4, osminova},{B_4, ctvrtova},{PA, osminova},
{E_4, osminova},{C_5, osminova},{B_4, osminova},{A_4, polova},{PA, osminova}
};

int initStr(string *str) {
    void *init;
    init = (char *)calloc(INIT_ALLOC_SIZE, sizeof(char));
    str->length = 0;
    str->allocLength = INIT_ALLOC_SIZE;
    if (init == NULL) {
        return FAIL;
    }
    str->pString = init;
    return OK;
}

int addChar(string *str, char c) {
    if (str->length + 1 >= str->allocLength) {
        void *random;
        random = (char *)realloc(str->pString, str->allocLength + INIT_ALLOC_SIZE);
        if (random == NULL) {
            return FAIL;
        }
        str->pString = random;
        str->allocLength += INIT_ALLOC_SIZE;
    }
    str->pString[str->length] = c;
    str->length++;
    str->pString[str->length] = '\0';
    return OK;
}

int addStr(string *str, char *data) {
    if (data == NULL || str == NULL) {
        return FAIL;
    }
    int result;
    for (int i = 0; data[i] != '\0'; i++) {
        result = addChar(str, data[i]);
    }
    return result;
}

void clearStr(string *str) {
    str->length = 0;
    str->pString[0] = '\0';
}

void delay(long long bound) {
  long long i;
  for(i = 0; i < bound; i++);
}

void play(int frequence){
	FTM0_MOD = inputFrequence / frequence;
	FTM0_C1V = (inputFrequence / frequence) / 2;
}

void stop(void){
	FTM0_C1V = 0;
}

void checkInput(string s) {
    tone song[20];
    int tone_count = 0;
    char *pom;
    char *token;
    token = strtok(s.pString, ",");
    while (token != NULL) {
    	switch (token[0]) {
			case 'q':
				song[tone_count].frequency = C_4;
				break;
			case 'w':
				song[tone_count].frequency = D_4;
				break;
			case 'e':
				song[tone_count].frequency = DS_4;
				break;
			case 'r':
				song[tone_count].frequency = E_4;
				break;
			case 't':
				song[tone_count].frequency = F_4;
				break;
			case 'z':
				song[tone_count].frequency = G_4;
				break;
			case 'u':
				song[tone_count].frequency = A_4;
				break;
			case 'i':
				song[tone_count].frequency = B_4;
				break;
			case 'a':
				song[tone_count].frequency = C_5;
				break;
			case 's':
				song[tone_count].frequency = D_5;
				break;
			case 'd':
				song[tone_count].frequency = DS_5;
				break;
			case 'f':
				song[tone_count].frequency = E_5;
				break;
			case 'g':
				song[tone_count].frequency = F_5;
				break;
			case 'h':
				song[tone_count].frequency = G_5;
				break;
			case 'j':
				song[tone_count].frequency = A_5;
				break;
			case 'k':
				song[tone_count].frequency = B_5;
				break;
			default:
				return;
		}
        if (token[1] != ':')
            return;

        char *delay = &token[2];
        if (strcmp(delay, "") == 0)
            return;
        song[tone_count].delay = strtol(delay, &pom, 10);
        if (strcmp(pom, "") != 0)
            return;
        tone_count++;
        token = strtok(NULL, ",");
    }
    for (int i = 0; i < tone_count; i++) {
    	play(song[i].frequency);
    	delay(song[i].delay * 1000);
    	stop();
    }
}


void MCUInit(void)  {
    MCG_C4 |= ( MCG_C4_DMX32_MASK | MCG_C4_DRST_DRS(0x01) );
    SIM_CLKDIV1 |= SIM_CLKDIV1_OUTDIV1(0x00);
    WDOG_STCTRLH &= ~WDOG_STCTRLH_WDOGEN_MASK;
}

void PortsInit(void){
	SIM->SCGC1 = SIM_SCGC1_UART5_MASK;
	SIM->SCGC5 = SIM_SCGC5_PORTE_MASK | SIM_SCGC5_PORTA_MASK | SIM_SCGC5_PORTB_MASK;
	SIM->SCGC6 = SIM_SCGC6_FTM0_MASK;

	PORTE->PCR[8] = (0 | PORT_PCR_MUX(0x03));
	PORTE->PCR[9] = (0 | PORT_PCR_MUX(0x03));
	PORTA->PCR[4] = PORT_PCR_MUX(0x03);
}

void UART5Init(void) {
	UART5->C2 &= ~(UART_C2_TE_MASK | UART_C2_RE_MASK);
	UART5->BDH = 0;
	UART5->BDL = 26;
	UART5->C4 = 15;
	UART5->C1 = 0;
	UART5->C3 = 0;
	UART5->MA1 = 0;
	UART5->MA2 = 0;
	UART5->C2 |= (UART_C2_TE_MASK | UART_C2_RE_MASK);
}

void TimerInit(void){
	FTM0_CNT = 0;
	FTM0_C1SC =	0b00101000;
	FTM0_SC = 0b00001100;
}

void SendCh(char ch)  {
	while(!(UART5->S1 & UART_S1_TDRE_MASK) && !(UART5->S1 & UART_S1_TC_MASK));
	UART5->D = ch;
}

void SendStr(char *s)  {
	int i = 0;
	while (s[i] != 0){
		SendCh(s[i++]);
	}
}

char ReceiveCh(void) {
	while(!(UART5->S1 & UART_S1_RDRF_MASK));
	return UART5->D;
}

int main(void){
	MCUInit();
	PortsInit();
	UART5Init();
	TimerInit();

	char c;
	string song;
	initStr(&song);
    SendStr(" Klavesy od q-i a od a-k\r\n");
    while (1) {
    	c = ReceiveCh();
    	if (c == 13) {
			checkInput(song);
			SendStr("\r\n");
			clearStr(&song);
		} else if (c == 32) {
			SendStr("Pro Elisku\r\n");
			for(int i = 0;i<41;i++){
				play(my_song[i].frequency);
				delay(my_song[i].delay * 1000);
				stop();
			}
		} else {
			SendCh(c);
			addChar(&song, c);
		}
    }
}
