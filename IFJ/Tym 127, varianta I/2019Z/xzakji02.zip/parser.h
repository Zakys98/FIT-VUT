/*
* Predmet  :   IFJ / IAL
* Súbor    :   parser.h - Syntaktický a semantický analyzátor
* Projekt  :   Implementácia prekladača imperatívneho jazyka IFJ19
* Tým č    :   127
* Varianta :   I
* Autoři   : xhalom00, Ivan Halomi
*            xhiner00, Martin Hiner
*            xsevci64, Adam Ševčík
*            xzakji02, Jiří Žák
*/

#ifndef IFJ_PARSER_H
#define IFJ_PARSER_H

#include <stdio.h>
#include "scanner.h"
#include "string.h"
#include "err_code.h"
#include "symtable.h"
#include "exprParser.h"
#include "functionParser.h"
#include "instruction-list.h"

int parse(); // zavola funkci doParse()

int doParse();  // nacita postupne tokeny a pracuje s nimi podle LL gramatiky

int keyWords(); // funkce pro práci s keywordy

int declaration(); // zjisteni jestli se jedna o fuknci nebo proměnou

int declarationVariable(); // deklarace proměné

int checkVariable(); // kontroluje jeslti existuje proměná v tabulce symbolů

int declarationFunctionHead(); // deklarace hlavičky fuknce

int declarationFunctionBody(); // deklarace těla funkce

int loadParams(); // nacita parametre funkcie

#endif //IFJ_PARSER_H
