#!/usr/bin/env python
# -*- coding: ascii -*-
import numpy as np
import matplotlib.pyplot as plt
import soundfile as sf
from scipy.signal import spectrogram, lfilter, freqz, tf2zpk
from scipy.stats import pearsonr

s, fs = sf.read('sx167.wav')
s = s[:250000]
t = np.arange(s.size) / fs

#kod pro vypocet spektogramu
f, ti, sgr = spectrogram(s, fs, nperseg=400, noverlap=240, nfft=511)
sgr_log = 10 * np.log10(sgr+1e-20)

"""
# vykresleni spektogramu
plt.figure(figsize=(9,3))
plt.pcolormesh(t,f,sgr_log)
plt.gca().set_xlabel('Cas [s]')
plt.gca().set_ylabel('Frekvence [Hz]')
cbar = plt.colorbar()
cbar.set_label('Spektralni hustota vykonu [dB]', rotation=270, labelpad=15)
plt.tight_layout()
plt.show()
"""

fig, axs = plt.subplots(3)

axs[0].set_title('employee and reorganization vs. sx167')
axs[0].plot(t, s)
axs[0].margins(0)
axs[0].set_ylabel('signal')

def ctyrka (sgr, sgr_log):
    new_sgr = np.zeros([sgr.shape[0] // 16, sgr.shape[1]])
    sestnact = vypocet = pom = 0
    for i in range(len(sgr_log[0])):
        for j in range(len(sgr_log)):
            vypocet += sgr_log[j][i]
            sestnact += 1
            if sestnact == 16:
                new_sgr[pom][i] = vypocet
                sestnact = vypocet = 0
                pom += 1
        pom = 0
    return new_sgr

nova_sgrSA1 = ctyrka(sgr, sgr_log)

def petka(new_sgr, new_sgr2):
    F = np.array(new_sgr)
    F = F.transpose()
    Q = np.array(new_sgr2)
    Q = Q.transpose()
    pp = 0
    score = 0.0
    rating_array = np.zeros([len(F)-len(Q)])

    while pp < len(F)-len(Q) :
        for k in range(len(Q)):
            rcoef, pval = pearsonr(Q[k], F[k + pp])
            score += rcoef
        rating_array[pp] = score/len(Q)
        pp += 1
        score = 0
    return rating_array

sq1, fsq1 = sf.read('../queries/q1.wav')
sq1 = sq1[:250000]
f2, t2, sgrq1 = spectrogram(sq1, fsq1, nperseg=400, noverlap=240, nfft=511)
sgrq1_log = 10 * np.log10(sgrq1+1e-20)
nova_sgrQ1 = ctyrka(sgrq1, sgrq1_log)
ratQ1 = petka(nova_sgrSA1, nova_sgrQ1)

sq2, fsq2 = sf.read('../queries/q2.wav')
sq2 = sq2[:250000]
f3, t3, sgrq2 = spectrogram(sq2, fsq2, nperseg=400, noverlap=240, nfft=511)
sgrq2_log = 10 * np.log10(sgrq2+1e-20)
nova_sgrQ2 = ctyrka(sgrq2, sgrq2_log)
ratQ2 = petka(nova_sgrSA1, nova_sgrQ2)

x = np.array([0,100,200,300,400, 500, 600])
my_xticks = ['0', '1', '2', '3', '4', '5', '6']
plt.xticks(x, my_xticks)

axs[1].set_xticklabels(['0', '0.5', '1', '1.5', '2', '2.5', '3', '3.5', '4'])
#axs[1].set_xticklabels(['0', '1', '2', '3', '4', '5', '6', '7'])
axs[1].pcolormesh(nova_sgrSA1)
axs[1].set_ylabel('features')
axs[1].margins(0)

axs[2].set_xlabel('sec')
axs[2].set_ylabel('scores')
axs[2].margins(0)
axs[2].plot(ratQ1, label="employee")
axs[2].plot(ratQ2, label="reorganization")
axs[2].legend(loc="lower right")
plt.show()

