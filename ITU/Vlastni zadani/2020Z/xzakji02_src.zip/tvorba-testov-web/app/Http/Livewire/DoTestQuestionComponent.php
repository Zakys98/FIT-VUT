<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\VariantQuestion;
use Carbon\Carbon;

class DoTestQuestionComponent extends Component
{
	public VariantQuestion $variantQuestion;
	public $fulltextAnswer;
	public $options = [];
    public $radioOption;

	protected $listeners = ['testSaved' => 'save'];

    public function mount()
    {
        if ($this->variantQuestion->question->type == 'fulltext')
        {
            $this->fulltextAnswer = $this->variantQuestion->answer->answer_text;
        }
        else if($this->variantQuestion->question->is_multichoice)
        {
            $checkedIds = [];
            foreach($this->variantQuestion->answer->options as $option)
            {
                $checkedIds[$option->id] = true;
            }
            foreach($this->variantQuestion->question->options as $option)
            {
                if(isset($checkedIds[$option->id]))
                    $this->options[$option->id] = true;
                else
                    $this->options[$option->id] = false;
            }
        }
        else
        {
            $checkedOptions = $this->variantQuestion->answer->options;
            if($checkedOptions->count())
            {
                $this->radioOption = $checkedOptions[0]->id;
            }
        }
    }

    public function render()
    {
        return view('livewire.do-test-question');
    }

    public function save()
    {   
        if (Carbon::now()->gt($this->variantQuestion->testVariant->testHistory->end))
            return redirect('/testVariant/'.$this->variantQuestion->testVariant->id);

    	if ($this->variantQuestion->question->type == 'fulltext')
    	{
    		$this->variantQuestion->answer->answer_text = $this->fulltextAnswer;
            $this->variantQuestion->answer->save();
    	}
    	else if($this->variantQuestion->question->is_multichoice)
    	{
    		$checkedIds = [];
    		foreach ($this->options as $id => $checked)
    		{
    			if ($checked)
    				$checkedIds[] = $id;
    		}
    		$this->variantQuestion->answer->options()->sync($checkedIds);
    	}
        else if(isset($this->radioOption)) //radio
        {
            $checkedIds = [ $this->radioOption ];
            $this->variantQuestion->answer->options()->sync($checkedIds);
        }
    }
}
