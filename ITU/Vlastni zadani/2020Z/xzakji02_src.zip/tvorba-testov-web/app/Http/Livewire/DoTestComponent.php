<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\TestVariant;
use App\Models\Approval;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

use App\Http\Controllers\TestVariantsController;

class DoTestComponent extends Component
{
	public TestVariant $testVariant;
    public $ended = false;

    protected $listeners = ['testSaved' => 'save'];

    public function render()
    {
        if (Auth::id() != $this->testVariant->user->id)
            return view('livewire.not-found');
        else if (Carbon::now()->gt($this->testVariant->testHistory->end))
            $this->ended = true;
        return view('livewire.do-test');
    }

    public function save()
    {
        session()->flash('message', 'Odpovede testu boli úspešne uložené.');
    }
}
