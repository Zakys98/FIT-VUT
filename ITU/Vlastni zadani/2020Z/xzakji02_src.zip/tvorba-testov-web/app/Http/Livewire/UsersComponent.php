<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\User;

// use App\Actions\Fortify\UpdateUserProfileInformation;
use Illuminate\Support\Facades\Auth;
use Laravel\Fortify\Contracts\UpdatesUserProfileInformation;

class UsersComponent extends Component
{
    public $users, $name, $user_id, $email, $role;
    public $modalOpened = 0;
  
    public function render()
    {
        $user = Auth::user();
        if ($user->role != "admin")
            return view('livewire.not-found');
        //admin
        $this->users = User::all();
        return view('livewire.users');
    }
  
    private function resetInputs(){
        $this->name = '';
        $this->email = '';
        $this->role = '';
        $this->user_id = '';
    }
     
    public function store(UpdatesUserProfileInformation $updater)
    {
        // Validator::make($this, [
        //     'name' => ['required', 'string', 'max:255'],
        //     'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
        //     'role' => ['required', Rule::in(['admin', 'professor', 'assistent', 'student'])],
        // ])->validate();

        $updater->update(User::find($this->user_id), [
            'name' => $this->name,
            'email' => $this->email,
            'role' => $this->role
        ]);
   
        // Post::updateOrCreate(['id' => $this->post_id], [
        //     'name' => $this->name,
        //     'email' => $this->email,
        //     'role' => $this->role
        // ]);
  
        session()->flash('message', 'Užívateľ úspešne aktualizovaný');
  
        $this->closeModal();
        $this->resetInputs();
    }

    public function edit($id)
    {
        $user = User::findOrFail($id);
        $this->user_id = $id;
        $this->name = $user->name;
        $this->email = $user->email;
        $this->role = $user->role;
    
        $this->openModal();
    }
     
    public function delete($id)
    {
        User::find($id)->delete();
        session()->flash('message', 'Užívateľ úspešne odstránený.');
    }

    public function openModal()
    {
        $this->modalOpened = true;
    }
  
    public function closeModal()
    {
        $this->modalOpened = false;
    }
}
