<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Carbon\Carbon;
use Auth;
use DB;
use App\Models\TestVariant;

class ResultsComponent extends Component
{
    public $completedTests, $detail, $testQuestions, $detailTestName;

    public function mount()
    {
        $this->detail = false;
    }

    public function render()
    {
        $userId = Auth::id();
        $this->completedTests = TestVariant::select('test_variants.id as id', 'test_variants.test_id as test_id', 'test_variants.checked as checked', 'tests.name as name', DB::raw('SUM(variant_questions.max_score) as fullscore'), DB::raw('SUM(answers.score) as score'))
                                ->join('variant_questions', 'test_variants.id', '=', 'variant_questions.test_variant_id')
                                ->join('answers', 'variant_questions.id', '=', 'answers.variant_question_id')
                                ->join('tests', 'test_variants.test_id', '=', 'tests.id')
                                ->where('test_variants.user_id', '=', $userId)
                                ->with(['testHistory'=>function($query) {
                                    $query->select('created_at', 'end');
                                }])
                                ->wherehas('testHistory', function($query) {
                                    $query->where('end', '<', Carbon::now()->toDateTimeString());
                                })
                                ->groupBy('test_variants.id', 'test_variants.test_id', 'tests.name', 'test_variants.checked')
                                ->get();
        
        return view('livewire.results');
    }

    public function detail($testVariantId, $testName) {
        $this->testQuestions = TestVariant::select('questions.text as text', 'variant_questions.number as number', 'answers.score as score', 'variant_questions.max_score as fullscore')
                                ->join('variant_questions', 'test_variants.id', '=', 'variant_questions.test_variant_id')
                                ->join('answers', 'variant_questions.id', '=', 'answers.variant_question_id')
                                ->join('questions', 'variant_questions.question_id', '=', 'questions.id')
                                ->where('test_variants.id', '=', $testVariantId)
                                ->get();

        $this->detailTestName = $testName;
        $this->detail = true;
    }

    public function back() {
        $this->detail = false;
    }
}
