<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use App\Models\Test;
use App\Models\TestVariant;
use Carbon\Carbon;
use DB;

class CheckTestsComponent extends Component
{
    public $tests, $actualRole, $testVariants;
    public $modalOpened = 0;

    public function render()
    {
        $this->actualRole = Auth::user()->role;

        if ($this->actualRole == "admin" || $this->actualRole == "professor")
        {
            $this->tests = Auth::user()->createdTests()->select('id', 'name')->orderByRaw('id ASC')->get();
        }
        else if ($this->actualRole == "assistant")
        {
            $this->tests = Test::select('id', 'name', 'user_id')
            ->with(['approvals'=>function($query){
                $query->select('id', 'approved', 'type', 'user_id', 'test_id');
            }, 'creator'=>function($query){
                $query->select('id', 'name', 'email');
            }])
            ->whereHas('approvals', function($query){
                $query->where('approved', true)
                    ->where('type', 'fix')
                    ->where('user_id', Auth::id());
            })->orderByRaw('id ASC')->get();
        }
        else //student
            return view('livewire.not-found');

        return view('livewire.check-tests');
    }

    public function checkTest($testId)
    {
        $this->testVariants = TestVariant::select('test_variants.id', 'for_printing', 'user_id', 'test_history_id', 'test_variants.created_at', 'checked', 'test_id', DB::raw('SUM(answers.score) as score'), DB::raw('SUM(variant_questions.max_score) as max_score'))
        ->join('variant_questions', 'test_variants.id', '=', 'variant_questions.test_variant_id')
        ->join('answers', 'variant_questions.id', '=', 'answers.variant_question_id')
        ->where('for_printing', false)->where('test_id', $testId)
        ->with(['user'=>function($query){
             $query->select('id', 'name', 'email');
        }, 'testHistory'=>function($query){
             $query->select('created_at', 'end');
        }, 'test'=>function($query){
            $query->select('tests.id', DB::raw('SUM(sections.question_score) as test_score'))
                ->join('sections', 'sections.test_id', '=', 'tests.id')
                ->join('question_section', 'question_section.section_id', '=', 'sections.id')
                ->groupBy('tests.id');
        }])
        ->whereHas('testHistory', function($query){
            $query->where('end', '<', Carbon::now()->toDateTimeString());
        })
        ->groupBy('test_variants.id', 'for_printing', 'user_id', 'test_history_id', 'test_variants.created_at', 'checked', 'test_id')
        ->orderByRaw('created_at DESC')->get();

        $this->openModal();
    }

    public function checkVariant($variantId)
    {
        return redirect()->to('/checkTests/'.$variantId);
    }

    public function openModal()
    {
        $this->modalOpened = true;
    }
  
    public function closeModal()
    {
        $this->modalOpened = false;
    }

    //check questions with option, for now not multichoice
    public function automaticCheck()
    {
        $refresh = false;
        foreach ($this->testVariants as $testVariant)
        {
            if($testVariant->checked) // already checked
            {
                continue;
            }
            $checkedQstns = 0; // number of automatically checked questions
            foreach($testVariant->variantQuestions as $variantQuestion)
            {
                if($variantQuestion->question->type == 'fulltext' || $variantQuestion->question->is_multichoice)
                    continue; // check only options

                //CHECK NOT-MULTICHOICE QUESTION
                $refresh = true;
                if($variantQuestion->answer->options()->count() == 1) // just to be sure
                {
                    if($variantQuestion->answer->options[0]->is_true)
                        $variantQuestion->answer->update(['score'=>$variantQuestion->max_score]);
                    else
                        $variantQuestion->answer->update(['score'=>0]);
                }
                else{
                    $variantQuestion->answer->update(['score'=>0]);
                }

                $checkedQstns++;
            }

            if($checkedQstns == $testVariant->variantQuestions()->count()) {
                $testVariant->checked = 1;
                $testVariant->save();
            }
        }
        if($refresh)
            $this->checkTest($this->testVariants[0]->test->id);
    }
}
