<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\TestVariant;
use App\Models\TestHistory;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use App\Repositories\Interfaces\TestVariantsRepositoryInterface;

class TestLobbyComponent extends Component
{
	public $activeVariants;
	public $testVariantId = NULL;

    public function mount(TestVariantsRepositoryInterface $testVariantsRepository)
    {
        $user = Auth::user();

        if($user->role == "professor" || $user->role == "admin")
        {
            $testHistories = TestHistory::where('end', '>=', Carbon::now()->toDateTimeString())
            ->with(['test', 'testVariants'])
            ->whereHas('test', function($query){
                $query->where('user_id', Auth::id());
            })->get(); // get professor's running tests

            foreach($testHistories as $testHistory) {
                if ($user->testVariants()->where('test_history_id', $testHistory->id)->count())
                    continue;
                $testVariantsRepository->generateOnlineVariant($testHistory->test, $user->id, $testHistory);
            }
        }
    }

    public function render()
    {
    	$this->activeVariants = Auth::user()->testVariants()
		->select('id', 'name', 'test_id', 'test_history_id')
    	->with(['test'=>function($query){
                $query->select('id', 'name');
        	}, 'testHistory'=>function($query){
                $query->select('created_at', 'end');
            }])
    	->whereHas('testHistory', function($query){
            $query->where('end', '>=', Carbon::now()->toDateTimeString());
        })->get();

        return view('livewire.test-lobby');
    }

    public function redirectToTest()
    {
    	if($this->testVariantId == NULL)
    		return redirect('/testVariant/'.$this->activeVariants[0]->id);
    	else
    		return redirect('/testVariant/'.$this->testVariantId);
    }
}
