<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Approval;
use Illuminate\Support\Facades\Auth;

class ApprovalsComponent extends Component
{

    public $approvals, $title, $actualRole;

    public function render()
    {
        $this->actualRole = Auth::user()->role;
        if ($this->actualRole == "assistant")
        {
            // show only students which are registered to tests where I (assistant) am approved
            $this->approvals = Approval::orderByRaw('id DESC')
            ->with(['test'=>function($query){
                $query->select('id','name');
            }, 'user'=>function($query){
                $query->select('id', 'name', 'email', 'role');
            }])
            ->whereHas('user', function($query){
                $query->where('role', 'student');
            })
            ->whereHas('test', function($query){
                $query->whereHas('approvals', function ($query) {
                   $query->where('approvals.user_id', Auth::id())
                        ->where('approved', 1);
                });
            })->get();
        }
        else if ($this->actualRole == "professor")
        {
            // show students + assistents which are registered to my tests
            $this->approvals = Approval::orderByRaw('id DESC')
            ->with(['test'=>function($query){
                $query->select('id','name');
            }, 'user'=>function($query){
                $query->select('id', 'name', 'email', 'role');
            }])
            ->whereHas('user', function($query){
                $query->where('role', 'assistant')
                ->orWhere('role', 'student');
            })
            ->whereHas('test', function($query){
               $query->where('user_id', Auth::id());
            })->get();
        }
        else if ($this->actualRole == "admin")
        {
            //show all students and assistants
            $this->approvals = Approval::orderByRaw('id DESC')
            ->with(['test'=>function($query){
                $query->select('id','name');
            }, 'user'=>function($query){
                $query->select('id', 'name', 'email', 'role');
            }])
            ->whereHas('user', function($query){
                $query->where('role', 'assistant')
                ->orWhere('role', 'student');
            })->get();
        }
        else //students don't see approvals
            return view('livewire.not-found');

        return view('livewire.approvals');
    }

    public function edit($id)
    {
        $approval = Approval::findOrFail($id);
        $approval->approved = ($approval->approved ? 0 : 1);
        $approval->save();
    }
}
