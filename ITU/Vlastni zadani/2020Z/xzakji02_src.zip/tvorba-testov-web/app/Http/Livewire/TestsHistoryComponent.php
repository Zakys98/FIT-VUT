<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use App\Models\TestHistory;
use App\Models\Test;
use Carbon\Carbon;
use DB;
use App\Repositories\Interfaces\TestVariantsRepositoryInterface;

class TestsHistoryComponent extends Component
{
	protected $testVariantsRepository; // generating test variants

	public $testHistories;   //all the test that have been run
	public $modalOpened = 0;
	public $testsToRun;
	public $testId, $duration; // running new test

	public function mount(TestVariantsRepositoryInterface $testVariantsRepository)
	{
		$this->testVariantsRepository = $testVariantsRepository;
	}

    public function render()
    {
    	$user = Auth::user();
    	if ($user->role == "assistant" || $user->role == "student")
        	return view('livewire.not-found');
        //admin/professor

       	$this->testHistories = TestHistory::select('created_at', 'test_id', 'end')
       		->with(['test'=>function($query){
                $query->select('id', 'user_id', 'name');
        	}])
       	->whereHas('test', function($query){
            $query->where('user_id', Auth::id());
        })->orderByRaw('created_at DESC')->get();

        $this->testsToRun = $user->createdTests()->select('id', 'name')
        	->with(['testHistories'=>function($query){
                $query->select('id', 'created_at', 'end', 'duration');
        	}])
        ->whereDoesntHave('testHistories', function($query){
            $query->where('end', '>=', Carbon::now()->toDateTimeString());
        })->get();

        return view('livewire.run-test');
    }

    private function resetInputs(){
        $this->testId = '';
        $this->duration = '';
    }

    public function create()
    {
        $this->resetInputs();
        $this->openModal();
    }

    public function store(TestVariantsRepositoryInterface $testVariantsRepository)
    {
    	$this->testVariantsRepository = $testVariantsRepository;
    	
        $this->validate([
            'testId' => 'required|exists:tests,id',
            'duration' => 'required|integer|min:5',
        ]);

        $runnable = false;
        foreach($this->testsToRun as $testToRun) {
        	if ($testToRun->id == $this->testId) {
        		$runnable = true;
        		break;
        	}
        }

        if (!$runnable) {
        	session()->flash('message', 'Test nie je možné spustiť. Nesnažte sa hacknúť systém.');
	        $this->closeModal();
	        $this->resetInputs();
        }

        $testHistory = new TestHistory;
        $testHistory->test_id = $this->testId;
        $testHistory->duration = $this->duration;
  		$testHistory->save();

  		if ($testHistory->id)
  		{
  			foreach($testHistory->test->approvals as $approval) {
  				if($approval->type == "do" && $approval->approved)
	  			{
	  				$this->testVariantsRepository->generateOnlineVariant($testHistory->test,
                        $approval->user_id, $testHistory);
                    $approval->delete();
	  			}
  			}

        	session()->flash('message', 'Všetky varianty vygenerované, test je spustený');
        	$testHistory->end = $testHistory->created_at->copy()
                ->addMinutes(intval($this->duration))->toDateTimeString();
        	$testHistory->save();
  		}
        else
        	session()->flash('message', 'Nepodarilo sa spustiť test.');
  
        $this->closeModal();
        $this->resetInputs();
    }

    public function runTest()
    {
        $this->openModal();
    }

    public function openModal()
    {
        $this->modalOpened = true;
    }

    public function closeModal()
    {
        $this->modalOpened = false;
    }
}
