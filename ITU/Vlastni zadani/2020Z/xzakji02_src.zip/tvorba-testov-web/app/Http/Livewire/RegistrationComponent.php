<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use App\Models\Approval;
use DB;

class RegistrationComponent extends Component
{
    public $doTests, $fixTests, $approvals, $userId, $tab, $userRole;

    public function mount()
    {
        $this->tab = 'do';
    }

    public function setTab($tabName)
    {
        $this->tab = $tabName;
    }

    public function render()
    {
        $user = Auth::user();
        $userId = $user->id;
        $this->userRole = $user->role;

        $this->doTests = DB::table('tests')
                                ->where('tests.user_id', '!=', $userId)
                                ->orWhereNull('tests.user_id')
                                ->leftJoin('approvals', function($join) use($userId) {
                                     $join->on('tests.id', '=', 'approvals.test_id')
                                     ->where('approvals.user_id', '=', $userId)
                                     ->where('approvals.type', '=', 'do' );
                                 })
                                ->join('users', function($join) {
                                    $join->on('tests.user_id', '=', 'users.id');
                                })
                                ->select('tests.id as id', 'tests.name as name', 'users.name as creator', 'approvals.approved', 'approvals.id as approvalId')
                                ->get();

        foreach ($this->doTests as $test) {
            if ($test->approved === true) {
                $test->state = "approved";
            } else if ($test->approved === false) {
                $test->state = "waiting";
            } else {
                $test->state = "na";
            }
        }

        if ($user->role == "assistant") {
            $this->fixTests = DB::table('tests')
                                ->leftJoin('approvals', function($join) use($userId) {
                                     $join->on('tests.id', '=', 'approvals.test_id')
                                     ->where('approvals.user_id', '=', $userId)
                                     ->where('approvals.type', '=', 'fix' );
                                 })
                                ->join('users', function($join) {
                                    $join->on('tests.user_id', '=', 'users.id');
                                })
                                ->select('tests.id as id', 'tests.name as name', 'approvals.approved as approved', 'approvals.id as approvalId', 'users.name as creator')
                                ->get();

            foreach ($this->fixTests as $test) {
                if ($test->approved === true) {
                    $test->state = "approved";
                } else if ($test->approved === false) {
                    $test->state = "waiting";
                } else {
                    $test->state = "na";
                }
            }
        }

        return view('livewire.registration');
    }

    public function register($testId, $type)
    {
        $userId = Auth::id();
        DB::table('approvals')->insert([
            'user_id' => $userId,
            'test_id' => $testId,
            'type' => $type,
            'approved' => false,
        ]);
    }

    public function unregister($approvalId)
    {
        Approval::where('id', $approvalId)->delete();
    }


}





