<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\VariantQuestion;
use Illuminate\Support\Facades\Validator;

class CheckVariantQuestionComponent extends Component
{
	public VariantQuestion $variantQuestion;
    public $score;

    protected $rules;

	protected $listeners = ['pointsSaved' => 'save'];

    public function mount()
    {
        $this->score = $this->variantQuestion->answer->score ?? 0;
    }

    public function render()
    {
        return view('livewire.check-variant-question');
    }

    public function save()
    {
        $validator = Validator::make(['score' => $this->score], [
            'score' => 'required|numeric|min:0|max:'.strval($this->variantQuestion->max_score)
        ]);
        if($validator->fails()){
            $this->addError('score', '0 až max');
            $this->emitUp('onValidationResult', 'error');
        }

        $this->variantQuestion->answer->score = $this->score;
        $this->variantQuestion->answer->save();
        $this->variantQuestion->testVariant->checked = 1;
        $this->variantQuestion->testVariant->save();
        $this->emitUp('onValidationResult', 'success');
    }
}
