<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\TestVariant;
use Illuminate\Support\Facades\Auth;

class CheckVariantComponent extends Component
{
    public TestVariant $testVariant;
    public $message = null;

    protected $listeners = ['onValidationResult'];

    public function render()
    {
    	$actualRole = Auth::user()->role;
    	$forbidden = true;

        if ($actualRole == "admin" || $actualRole == "professor" &&
    		($this->testVariant->test->creator->id == Auth::id()))
        {
        	$forbidden = false;
        }
        else if ($actualRole == "assistant" && ($this->testVariant->test->approvals()
        	->where('approvals.type', 'fix')->where('user_id', Auth::id())->where('approved', 1))->count())
        {
        	$forbidden = false;
        }

        if ($forbidden) //student, not creator, or not allowed to check
        	return view('livewire.not-found');

        return view('livewire.check-variant');
    }

    public function save()
    {
        // clear message
        $this->message = null;
        $this->emit('pointsSaved');
    }

    public function onValidationResult($result)
    {
        if($result == 'error')
        {
            $this->message = 'error';
        }
        else if($this->message != 'error')
        {
            $this->message = 'success';
            return redirect()->to('/checkTests');
        }
    }
}
