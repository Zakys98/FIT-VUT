<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Test;
use App\Models\Section;
use App\Models\Question;
use App\Repositories\Interfaces\QuestionsRepositoryInterface;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;

class QuestionsController extends Controller
{
    private $questionsRepository;

    public function __construct(QuestionsRepositoryInterface $questionsRepository)
    {
        $this->questionsRepository = $questionsRepository;
    }

    public function allQuestions()
    {
        return response()->json($this->questionsRepository->getQuestionsList());
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Test $test, Section $section)
    {
        return response()->json($this->questionsRepository->getSectionQuestionsList($section));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, Test $test, Section $section)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'type' => ['required', Rule::in(['fulltext', 'choice'])],
            'text' => 'required',
            'answer_text' => 'nullable',
            'is_multichoice' => 'nullable|boolean',
            'attachment_id' => 'nullable|exists:attachments,id',
        ]);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->messages()
            ], 500);
        }
        $question = new Question($data);
        $question->save();
        $section->questions()->attach($question->id);
        return response()->json($question, 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Question $question)
    {
        $question->load('options', 'attachment');
        return response()->json($question, 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Test $test, Section $section, Question $question)
    {
        if (!($section->questions->contains($question->id))) 
        {
            return response()->json([
                'errors' => 'Not found!'
            ], 404);
        }
        //WARNING, the question wil be edited in all the tests
        $data = $request->all();
        $validator = Validator::make($data, [
            'type' => ['required', Rule::in(['fulltext', 'choice'])],
            'text' => 'required',
            'answer_text' => 'nullable',
            'is_multichoice' => 'nullable|boolean',
            'attachment_id' => 'nullable|exists:attachments,id',
        ]);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->messages()
            ], 500);
        }
        $question->fill($data);
        $question->save();
        return response()->json($question, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Question $question)
    {
        if ($question->sections_count == 0)
        {
            $question->delete();
            return response()->json([], 200);
        }
    }

    public function detach(Test $test, Section $section, Question $question)
    {
        if (!($section->questions->contains($question->id))) 
        {
            return response()->json([
                'errors' => 'Not found!'
            ], 404);
        }
        $section->questions()->detach($question);
        return response()->json([], 200);
    }

    public function attach(Test $test, Section $section, Question $question)
    {
        $section->questions()->attach($question->id);
        return response()->json([], 200);
    }

}
