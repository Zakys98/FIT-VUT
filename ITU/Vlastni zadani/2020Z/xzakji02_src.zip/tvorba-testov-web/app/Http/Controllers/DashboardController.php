<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    /**
     * Display teacher's or student's dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function render()
    {
    	$user = Auth::user();
    	if ($user->role == "professor")
    		return view('prof-dashboard');
    	else if ($user->role == "assistant")
        	return view('assist-dashboard');
        else if ($user->role == "student")
        	return view('stud-dashboard');
        else if ($user->role == "admin")
        	return view('admin-dashboard');
    }
}
