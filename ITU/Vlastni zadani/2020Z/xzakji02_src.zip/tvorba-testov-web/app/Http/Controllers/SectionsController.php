<?php

namespace App\Http\Controllers;

use App\Models\Section;
use App\Models\Test;
use Illuminate\Http\Request;
use App\Repositories\Interfaces\SectionsRepositoryInterface;
use Illuminate\Support\Facades\Validator;

class SectionsController extends Controller
{
    private $sectionsRepository;

    public function __construct(SectionsRepositoryInterface $sectionsRepository)
    {
        $this->sectionsRepository = $sectionsRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Test $test)
    {
        return response()->json($this->sectionsRepository->getSectionsList($test));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, Test $test)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'name' => 'required',
        ]);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->messages()
            ], 500);
        }
        $section = new Section($data);
        $test->sections()->save($section);
        return response()->json($section, 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Section  $section
     * @return \Illuminate\Http\Response
     */
    public function show(Section $section)
    {
        return response()->json($section, 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Section  $section
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Test $test, Section $section)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'name' => 'required',
            'test_id' => 'nullable|exists:tests,id',
        ]);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->messages()
            ], 500);
        }
        $section->fill($data);
        $section->save();
        return response()->json($section, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Section  $section
     * @return \Illuminate\Http\Response
     */
    public function destroy(Test $test, Section $section)
    {
        $section->delete();
        return response()->json([], 200);
    }
}
