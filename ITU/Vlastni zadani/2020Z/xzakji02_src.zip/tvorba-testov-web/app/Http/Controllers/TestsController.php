<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Test;
use App\Repositories\Interfaces\TestsRepositoryInterface;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class TestsController extends Controller
{
    private $testsRepository;

    public function __construct(TestsRepositoryInterface $testsRepository)
    {
        $this->testsRepository = $testsRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return response()->json($this->testsRepository->getTestsList());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'name' => 'required|max:255',
            'category_id' => 'nullable|exists:categories,id',
        ]);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->messages()
            ], 500);
        }
        $test = new Test($data);
        // $test->user_id = Auth::id(); // UNCOMMENT
        $test->save();
        return response()->json($test, 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Test $test)
    {
        // if ($test->user_id != Auth::id())
        //     return response()->json(['errors' => 'Not the owner of the category'], 500);

        $test->load(['sections' => function($query) {
            $query->with(['questions' => function ($query) {
                $query->with('options', 'attachment');
            }]);
        }]);

        return response()->json($test);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Test $test)
    {
        // if ($test->user_id != Auth::id())
        //     return response()->json(['errors' => 'Not the owner of the category'], 500);

        $data = $request->all();
        $validator = Validator::make($data, [
            'name' => 'required|max:255',
            'category_id' => 'nullable|exists:categories,id',
        ]);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->messages()
            ], 500);
        }
        $test->fill($data);
        $test->save();
        return response()->json($test, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Test $test)
    {
        // if ($test->user_id != Auth::id())
        //     return response()->json(['errors' => 'Not the owner of the category'], 500);
        
        $test->delete();
        return response()->json([], 200);
    }
}
