<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Test;
use App\Models\TestVariant;
use App\Models\VariantQuestion;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use App\Repositories\Interfaces\TestVariantsRepositoryInterface;
use DB;

//variants to be printed
class PrintVariantsController extends Controller
{
    private $testVariantsRepository;

    public function __construct(TestVariantsRepositoryInterface $testVariantsRepository)
    {
        $this->testVariantsRepository = $testVariantsRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Test $test)
    {
        return response()->json($this->testVariantsRepository->getPrintVariantsList($test));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, Test $test)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'number' => 'required|integer',
        ]);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->messages()
            ], 500);
        }

        $this->testVariantsRepository->generatePrintVariants($test, $data['number']);
        
        return response()->json($this->testVariantsRepository->getPrintVariantsList($test), 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Test $test, TestVariant $testVariant)
    {
        // if ($test->user_id != Auth::id())
        //     return response()->json(['errors' => 'Not the owner of the test'], 500);

        $testVariant->load(['variantQuestions' => function($query) {
            $query->with(['question' => function ($query) {
                $query->with('options', 'attachment');
            }]);
        }]);

        return response()->json($testVariant);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Test $test, TestVariant $testVariant)
    {
        // if ($test->user_id != Auth::id())
        //     return response()->json(['errors' => 'Not the owner of the test'], 500);
        
        $testVariant->delete();
        return response()->json([], 200);
    }
}
