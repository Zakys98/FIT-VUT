<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Repositories\Interfaces\CategoriesRepositoryInterface;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class CategoriesController extends Controller
{
    private $categoriesRepository;

    public function __construct(CategoriesRepositoryInterface $categoriesRepository)
    {
        $this->categoriesRepository = $categoriesRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return response()->json($this->categoriesRepository->getCategoriesTree());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'name' => 'required|max:255',
            'supercategory_id' => 'nullable|exists:categories,id',
        ]);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->messages()
            ], 500);
        }
        $category = new Category($data);
        // $category->user_id = Auth::id(); // UNCOMMENT
        $category->save();
        return response()->json($category, 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Category $category)
    {
        // if ($category->user_id = Auth::id())
            return response()->json($category, 200);
        // else
        //     return response()->json(['errors' => 'Not the owner of the category'], 500);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Category $category)
    {
        // if ($category->user_id != Auth::id())
        //     return response()->json(['errors' => 'Not the owner of the category'], 500);

        $data = $request->all();
        $validator = Validator::make($data, [
            'name' => 'required|max:255',
            'supercategory_id' => 'nullable|exists:categories,id',
        ]);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->messages()
            ], 500);
        }
        $category->fill($data);
        $category->save();
        return response()->json($category, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Category $category)
    {
        // if ($category->user_id != Auth::id())
        //     return response()->json(['errors' => 'Not the owner of the category'], 500);
        
        $category->delete();
        return response()->json([], 200);
    }
}
