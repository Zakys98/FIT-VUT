<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Attachment;
use App\Repositories\Interfaces\AttachmentsRepositoryInterface;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class AttachmentsController extends Controller
{
    private $attachmentsRepository;

    public function __construct(AttachmentsRepositoryInterface $attachmentsRepository)
    {
        $this->attachmentsRepository = $attachmentsRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return response()->json($this->attachmentsRepository->getAttachmentsList());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'title' => 'required|max:255',
            'type' => ['required', Rule::in(['text', 'image'])],
            'text' => 'nullable',
            'file' => 'nullable|file|image|max:2048',
        ]);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->messages()
            ], 500);
        }

        $attachment = new Attachment($data);
        if ($request->has('file'))
        {
            $attachment->save();
            $file = $request->file('file');
            $name = $attachment->id . '.' . $file->getClientOriginalExtension();
            $request->file->storeAs('images', $name);
            $attachment->file = $name;
        }
        $attachment->save();
        return response()->json($attachment, 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Attachment $attachment)
    {
        if ($attachment->type == 'text')
            return $attachment->text;
        else if (Storage::exists('images/'.$attachment->file))
            return Storage::download('images/'.$attachment->file);
        else return "";
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Attachment $attachment)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'title' => 'required|max:255',
            'type' => ['required', Rule::in(['text', 'image'])],
            'text' => 'nullable',
            'file' => 'nullable|file|image|max:2048',
        ]);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->messages()
            ], 500);
        }

        $attachment->fill($data);
        $attachment->save();
        return response()->json($attachment, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Attachment $attachment)
    {
        $attachment->loadCount('questions');
        if ($attachment->questions_count)
        {
            return response()->json([
                'errors' => 'Attachment is also in another question.'
            ], 500);
        }
        $attachment->delete();
        return response()->json([], 200);
    }

    public function showInVariant(Attachment $attachment)
    {
        $access = false;
        $userId = Auth::id();

        foreach($attachment->questions as $question)
        {
            foreach($question->variantQuestions as $variantQuestion)
            {
                if ($variantQuestion->testVariant->user->id == $userId || // user's variant
                    ($variantQuestion->testVariant->test->creator->id == $userId) || // creator
                    ($variantQuestion->testVariant->test->approvals()->where('approved', 1)
                    ->where('type', 'fix')->where('user_id', $userId)->count())) // checker
                {
                    $access = true;
                    break;
                }
            }
            if ($access)
                break;
        }
        if ($access) {
            return \Storage::response('images/'.$attachment->file);
            // return response()->file(storage_path("app\images\\".$attachment->file));
        }
    }
}
