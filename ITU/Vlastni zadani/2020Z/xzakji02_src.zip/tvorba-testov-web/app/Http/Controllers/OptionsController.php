<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Option;
use App\Repositories\Interfaces\OptionsRepositoryInterface;
use Illuminate\Support\Facades\Validator;

class OptionsController extends Controller
{
    private $optionsRepository;

    public function __construct(OptionsRepositoryInterface $optionsRepository)
    {
        $this->optionsRepository = $optionsRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return response()->json($this->optionsRepository->getOptionsList());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'text' => 'required|max:255',
            'is_true' => 'required|boolean',
            'question_id' => 'nullable|exists:questions,id',
        ]);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->messages()
            ], 500);
        }
        $option = new Option($data);
        $option->save();
        return response()->json($option, 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Option $option)
    {
        return response()->json($option, 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Option $option)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'text' => 'required|max:255',
            'is_true' => 'required|boolean',
            'question_id' => 'nullable|exists:questions,id',
        ]);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->messages()
            ], 500);
        }
        $option->fill($data);
        $option->save();
        return response()->json($option, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Option $option)
    {
        $option->delete();
        return response()->json([], 200);
    }
}
