<?php

namespace App\Repositories;

use App\Repositories\Interfaces\QuestionsRepositoryInterface;
use App\Models\Question;
use App\Models\Section;
use Illuminate\Support\Facades\Auth;

class QuestionsRepository implements QuestionsRepositoryInterface
{
    public function getQuestionsList()
    {
        return Question::select('id','text')->with(['sections'=>function($query){
            $query->select('test_id')->with(['test'=>function($query){
                $query->select('tests.id', 'tests.name');
            }]);
        }])->get();
        // return Question::select('id','text')->with(['sections'=>function($query){
        //     $query->select('test_id')->with(['test'=>function($query){
        //         $query->select('tests.id', 'tests.name');
        //     }]);
        // }])->whereHas('sections', function($query)
        // {
        //     $query->whereHas('test', function($query){
        //         $query->where('tests.user_id', Auth::id());
        //     });
        // })->get();
    }

    public function getSectionQuestionsList(Section $section)
    {
        return $section->questions()->select('questions.id','text')->get();
    }
}
