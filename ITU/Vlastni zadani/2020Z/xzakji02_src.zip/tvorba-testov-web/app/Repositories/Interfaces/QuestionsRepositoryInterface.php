<?php

namespace App\Repositories\Interfaces;
use App\Models\Section;

interface QuestionsRepositoryInterface
{
	public function getQuestionsList();
	public function getSectionQuestionsList(Section $section);
}
