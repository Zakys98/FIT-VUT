<?php

namespace App\Repositories\Interfaces;

interface TestsRepositoryInterface
{
	public function getTestsList();
}
