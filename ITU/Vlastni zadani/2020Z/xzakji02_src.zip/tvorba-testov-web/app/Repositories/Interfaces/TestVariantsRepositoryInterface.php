<?php

namespace App\Repositories\Interfaces;
use App\Models\Test;
use App\Models\TestHistory;

interface TestVariantsRepositoryInterface
{
	public function generateVariant(Test $test, $userId, ?string $name, $forPrinting, ?TestHistory $testHistory);

	public function generatePrintVariants(Test $test, $nVariants);

	public function generateOnlineVariant(Test $test, $userId, TestHistory $testHistory);

	public function getPrintVariantsList(Test $test);
}
