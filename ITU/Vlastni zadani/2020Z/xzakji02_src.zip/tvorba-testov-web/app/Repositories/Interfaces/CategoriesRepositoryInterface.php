<?php

namespace App\Repositories\Interfaces;

interface CategoriesRepositoryInterface
{
	public function getCategoriesTree();
}
