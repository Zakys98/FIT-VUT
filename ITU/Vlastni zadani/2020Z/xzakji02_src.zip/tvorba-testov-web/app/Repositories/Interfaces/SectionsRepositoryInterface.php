<?php

namespace App\Repositories\Interfaces;
use App\Models\Test;

interface SectionsRepositoryInterface
{
	public function getSectionsList(Test $test);
}
