<?php

namespace App\Repositories;

use App\Repositories\Interfaces\TestsRepositoryInterface;
use App\Models\Test;
use Illuminate\Support\Facades\Auth;

class TestsRepository implements TestsRepositoryInterface
{
	public function getTestsList()
	{
        // return Auth::user()->createdTests()->select('id','name')->get();
		return Test::select('id','name')->get();
	}
}
