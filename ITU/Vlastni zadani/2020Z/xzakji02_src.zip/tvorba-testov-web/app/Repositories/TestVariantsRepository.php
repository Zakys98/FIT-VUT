<?php

namespace App\Repositories;

use App\Repositories\Interfaces\TestsRepositoryInterface;
use App\Repositories\Interfaces\TestVariantsRepositoryInterface;

use Illuminate\Http\Request;
use App\Models\Approval;
use App\Models\Test;
use App\Models\TestHistory;
use App\Models\Answer;
use App\Models\TestVariant;
use App\Models\VariantQuestion;
use DB;

class TestVariantsRepository implements TestVariantsRepositoryInterface
{
    public function generateVariant(Test $test, $userId, ?string $name, $forPrinting, ?TestHistory $testHistory)
    {
        $testVariant = new TestVariant;
        if ($name != NULL) {
            $testVariant->name = $name;
        }
        if ($testHistory != NULL) {
            $testVariant->test_history_id = $testHistory->id;
        }
        if ($userId != NULL) {
            $testVariant->user_id = $userId;
        }
        $testVariant->for_printing = $forPrinting;
        $testVariant->checked = false;
        $test->testVariants()->save($testVariant);

        $qNumber = 1; // question Number

        foreach ($test->sections as $section)
        {
            $chosenQuestions = 0; // how many are already chosen
            $questions = $section->questions->shuffle();

            foreach ($questions as $question)
            {
                if ($chosenQuestions >= $section->question_count)
                    break;
                $variantQuestion = new VariantQuestion;

                $variantQuestion->number = $qNumber++;
                $variantQuestion->test_variant_id = $testVariant->id;
                $variantQuestion->question_id = $question->id;
                $variantQuestion->max_score = $section->question_score;
                $variantQuestion->save();

                $answer = new Answer;
                $answer->variant_question_id = $variantQuestion->id;
                $answer->save();

                $chosenQuestions++;
            }
        }
    }

    public function generatePrintVariants(Test $test, $nVariants)
    {

        $tmpVariant = $test->testVariants()->where('id', DB::raw("(select max(id) from test_variants where test_id = {$test->id})"))->where('for_printing', 1)->get();
        $startId = $tmpVariant->count() ? $tmpVariant[0]->id : 1;
        for ($i = 0; $i < $nVariants; $i++)
        {
            $this->generateVariant($test, NULL, "Skupina ".++$startId, true, NULL);
        }
    }

    public function generateOnlineVariant(Test $test, $userId, TestHistory $testHistory)
    {
        if (Approval::where('test_id', '=', $test->id)
            ->where('user_id', '=', $userId)
            ->where('approved', '=', 1)
            ->where('type', '=', 'do'))
        {
            $this->generateVariant($test, $userId, NULL, false, $testHistory);
        }
    }

    // public function checkVariants()
    // {
    //     return;
    // }

    public function getPrintVariantsList(Test $test)
    {
        return $test->testVariants()->select('test_variants.id','name')->where('for_printing', 1)->get();
    }
}
