<?php

namespace App\Repositories;

use App\Repositories\Interfaces\SectionsRepositoryInterface;
use App\Models\Section;
use App\Models\Test;

class SectionsRepository implements SectionsRepositoryInterface
{
	public function getSectionsList(Test $test)
	{
		return $test->sections()->select('sections.id','name')->get();
	}
}
