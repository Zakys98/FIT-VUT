<?php

namespace App\Repositories;

use App\Repositories\Interfaces\CategoriesRepositoryInterface;
use App\Models\Category;
use Illuminate\Support\Facades\Auth;

class CategoriesRepository implements CategoriesRepositoryInterface
{
	public function getCategoriesTree()
	{
		// return Auth::user()->categories()->whereNull('supercategory_id')->get();
		return Category::whereNull('supercategory_id')->get();
	}
}
