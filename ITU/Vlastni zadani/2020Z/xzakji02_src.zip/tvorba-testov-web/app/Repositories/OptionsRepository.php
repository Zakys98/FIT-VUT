<?php

namespace App\Repositories;

use App\Repositories\Interfaces\OptionsRepositoryInterface;
use App\Models\Option;

class OptionsRepository implements OptionsRepositoryInterface
{
	public function getOptionsList()
	{
		return Option::select('id','text')->get();
	}
}
