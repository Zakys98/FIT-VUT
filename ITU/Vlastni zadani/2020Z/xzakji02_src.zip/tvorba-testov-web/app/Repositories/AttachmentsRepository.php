<?php

namespace App\Repositories;

use App\Repositories\Interfaces\AttachmentsRepositoryInterface;
use App\Models\Attachment;

class AttachmentsRepository implements AttachmentsRepositoryInterface
{
	public function getAttachmentsList()
	{
		return Attachment::select('id','title', 'type')->get();
	}
}
