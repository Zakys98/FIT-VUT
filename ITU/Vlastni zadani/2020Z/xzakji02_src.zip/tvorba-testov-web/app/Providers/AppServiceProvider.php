<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use App\Repositories\Interfaces\CategoriesRepositoryInterface;
use App\Repositories\Interfaces\QuestionsRepositoryInterface;
use App\Repositories\Interfaces\TestsRepositoryInterface;
use App\Repositories\Interfaces\OptionsRepositoryInterface;
use App\Repositories\Interfaces\AttachmentsRepositoryInterface;
use App\Repositories\Interfaces\SectionsRepositoryInterface;
use App\Repositories\Interfaces\TestVariantsRepositoryInterface;
use App\Repositories\CategoriesRepository;
use App\Repositories\QuestionsRepository;
use App\Repositories\TestsRepository;
use App\Repositories\OptionsRepository;
use App\Repositories\AttachmentsRepository;
use App\Repositories\SectionsRepository;
use App\Repositories\TestVariantsRepository;
use Illuminate\Routing\UrlGenerator;

class AppServiceProvider extends ServiceProvider
{
    public $bindings = [
        CategoriesRepositoryInterface::class => CategoriesRepository::class,
        QuestionsRepositoryInterface::class => QuestionsRepository::class,
        TestsRepositoryInterface::class => TestsRepository::class,
        OptionsRepositoryInterface::class => OptionsRepository::class,
        AttachmentsRepositoryInterface::class => AttachmentsRepository::class,
        SectionsRepositoryInterface::class => SectionsRepository::class,
        TestVariantsRepositoryInterface::class => TestVariantsRepository::class,
    ];

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot(UrlGenerator $url)
    {
        Schema::defaultStringLength(191);

        if (env('APP_ENV') !== 'local')
        {
            $url->forceScheme('https');
        }
    }
}
