<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    use HasFactory;

    protected $hidden = ['pivot'];
    protected $fillable = ['type', 'text', 'answer_text', 'is_multichoice', 'attachment_id'];

    public function sections()
    {
    	return $this->belongsToMany('App\Models\Section');
    }

    public function attachment()
    {
    	return $this->belongsTo('App\Models\Attachment');
    }
    
    public function options()
    {
    	return $this->hasMany('App\Models\Option');
    }

    public function variantQuestions()
    {
        return $this->hasMany('App\Models\VariantQuestion');
    }
}
