<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VariantQuestion extends Model
{
    use HasFactory;

    protected $fillable = ['number', 'testvariant_id', 'question_id', 'max_score'];

    public function testVariant()
    {
    	return $this->belongsTo('App\Models\TestVariant');
    }

    public function question()
    {
    	return $this->belongsTo('App\Models\Question');
    }

    public function answer()
    {
        return $this->hasOne('App\Models\Answer');
    }
}
