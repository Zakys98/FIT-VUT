<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TestVariant extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'test_id', 'user_id', 'test_history_id', 'checked'];

    public function test()
    {
    	return $this->belongsTo('App\Models\Test');
    }

    public function testHistory() //printable variant doen't have history
    {
        return $this->belongsTo('App\Models\TestHistory');
    }

    public function user()
    {
    	return $this->belongsTo('App\Models\User');
    }

    public function variantQuestions()
    {
        return $this->hasMany('App\Models\VariantQuestion');
    }
}
