<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TestHistory extends Model
{
    use HasFactory;

    protected $fillable = ['test_id', 'duration', 'end'];

    public function test()
    {
    	return $this->belongsTo('App\Models\Test');
    }

    public function testVariants()
    {
        return $this->hasMany('App\Models\TestVariant');
    }
}
