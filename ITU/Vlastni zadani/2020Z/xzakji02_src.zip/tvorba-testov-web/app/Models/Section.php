<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Section extends Model
{
    use HasFactory;

    protected $hidden = ['pivot'];
    protected $fillable = ['name', 'test_id', 'question_score', 'question_count'];

    public function test()
    {
    	return $this->belongsTo('App\Models\Test');
    }

    public function questions()
    {
    	return $this->belongsToMany('App\Models\Question');
    }
}
