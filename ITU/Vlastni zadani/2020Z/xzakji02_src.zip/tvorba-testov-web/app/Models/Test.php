<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Test extends Model
{
    use HasFactory;

    protected $hidden = ['pivot'];
    protected $fillable = ['name', 'category_id', 'user_id', 'test_score'];

    public function creator() // creator
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }

    public function category()
    {
    	return $this->belongsTo('App\Models\Category');
    }

    public function sections()
    {
    	return $this->hasMany('App\Models\Section');
    }

    public function testVariants()
    {
        return $this->hasMany('App\Models\TestVariant');
    }

    public function approvals() // assistants and students
    {
        return $this->hasMany('App\Models\Approval');
    }
    public function testHistories()
    {
        return $this->hasMany('App\Models\TestHistory');
    }
}
