<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Approval extends Model
{
    use HasFactory;

    protected $with = ['user', 'test'];
    protected $fillable = ['user_id', 'test_id', 'approved'];

    public function user() // assistant or student
    {
    	return $this->belongsTo('App\Models\User');
    }

    public function test()
    {
    	return $this->belongsTo('App\Models\Test');
    }
}
