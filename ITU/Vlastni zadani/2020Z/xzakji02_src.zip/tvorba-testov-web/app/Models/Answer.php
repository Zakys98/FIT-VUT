<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Answer extends Model
{
    use HasFactory;

    protected $fillable = ['variant_question_id', 'score', 'answer_text'];

    public function VariantQuestion()
    {
        return $this->belongsTo('App\Models\VariantQuestion');
    }

    public function options()
    {
    	return $this->belongsToMany('App\Models\Option');
    }
}
