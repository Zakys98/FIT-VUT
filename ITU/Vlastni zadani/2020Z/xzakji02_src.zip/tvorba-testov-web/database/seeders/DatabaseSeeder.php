<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        //USERS
        DB::table('users')->insert([
            'name' => 'Administrator',
            'email' => 'admin@admin.com',
            'role' => 'admin',
            'password' => Hash::make('admin'),
        ]);
        $prof1 = DB::table('users')->insertGetId([
            'name' => 'Professor1',
            'email' => 'prof1@prof.com',
            'role' => 'professor',
            'password' => Hash::make('prof'),
        ]);
        $prof2 = DB::table('users')->insertGetId([
            'name' => 'Professor2',
            'email' => 'prof2@prof.com',
            'role' => 'professor',
            'password' => Hash::make('prof'),
        ]);
        $assist1 = DB::table('users')->insertGetId([
            'name' => 'Assistant1',
            'email' => 'assist1@assist.com',
            'role' => 'assistant',
            'password' => Hash::make('assist'),
        ]);
        $assist2 = DB::table('users')->insertGetId([
            'name' => 'Assistant2',
            'email' => 'assist2@assist.com',
            'role' => 'assistant',
            'password' => Hash::make('assist'),
        ]);
        $stud1 = DB::table('users')->insertGetId([
            'name' => 'Student1',
            'email' => 'stud1@stud.com',
            'role' => 'student',
            'password' => Hash::make('stud'),
        ]);
        $stud2 = DB::table('users')->insertGetId([
            'name' => 'Student2',
            'email' => 'stud2@stud.com',
            'role' => 'student',
            'password' => Hash::make('stud'),
        ]);
        // DB::table('users')->insert([
        //     'name' => 'ITU Professor',
        //     'email' => 'itu@itu.com',
        //     'role' => 'professor',
        //     'password' => Hash::make('prof'),
        // ]);
        // for ITU send this to header: b6GXvZVhVkrbJ6XATqj6DbeUeRkwsSPAeBR0mOJ5
        // DB::table('personal_access_tokens')->insert([
        //     'tokenable_type' => 'App\Models\User',
        //     'tokenable_id' => '5',
        //     'name' => 'Tvorba testov - desktop',
        //     'token' => 'e2ffd15021718938678464d32d836930c10f1b3f6cd10063b756f2c51e4f7c98',
        //     'abilities' => '["create"]',
        // ]);


        // mkdir("storage/app/images", 0700);
        // file_put_contents("storage/app/images/1.jpg", fopen("https://unsplash.com/photos/vvk9VoMTUwg/download?force=true&w=1920", 'r'));

        //ATTACHMENTS
        $attach1 = DB::table('attachments')->insertGetId([
            'title' => 'Image of Paris',
            'type' => 'image',
            'file' => '1.jpg',
        ]);
        $attach2 = DB::table('attachments')->insertGetId([
            'title' => 'Prezident Turecka',
            'type' => 'text',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus enim tortor, dapibus vitae neque sit amet, semper semper magna. Donec finibus urna non tortor varius varius eu et velit. Integer condimentum finibus dui et volutpat. Vestibulum egestas risus risus, vel porttitor lorem hendrerit ac. Curabitur at augue eget risus vestibulum tincidunt eleifend a velit. Morbi sit amet mollis justo. Nunc vehicula ultrices condimentum. Quisque nisi sem, luctus vel tincidunt sit amet, posuere vitae eros. Quisque tempor ipsum lectus, ac laoreet nunc pretium id. Integer ullamcorper fermentum malesuada. Donec ut nisi nulla. Quisque id eros eget risus tristique suscipit. Pellentesque euismod lorem orci, nec efficitur risus sodales in. Pellentesque vestibulum id nunc vitae bibendum. Morbi consequat ex et malesuada congue.',
        ]);

        //QUESTIONS
        $question1 = DB::table('questions')->insertGetId([
        	'text' => 'Vyber 2 hlavné mestá z možností',
            'type' => 'choice',
            'is_multichoice' => true,
        ]);
        $question2 = DB::table('questions')->insertGetId([
        	'text' => 'Vyber hlavné mesto Francúzska (1 správna)',
            'type' => 'choice',
            'is_multichoice' => false,
            'attachment_id' => $attach1,
        ]);
        $question3 = DB::table('questions')->insertGetId([
            'text' => 'Aké je hlavné mesto Francúzska?',
            'answer_text' => 'Paríž',
            'type' => 'fulltext',
            'attachment_id' => $attach1,
        ]);
        $question4 = DB::table('questions')->insertGetId([
            'text' => 'Kto je prezidentom Turecka?',
            'answer_text' => 'Recep Tayyip Erdoğan',
            'type' => 'fulltext',
            'attachment_id' => $attach2,
        ]);
        $question5 = DB::table('questions')->insertGetId([
            'text' => 'Čo je zmyslom života a vúbec',
            'answer_text' => '42',
            'type' => 'fulltext',
        ]);

        //OPTIONS
        DB::table('options')->insert([
            'text' => 'Paríž',
            'is_true' => true,
            'question_id' => $question1,
        ]);
        DB::table('options')->insert([
            'text' => 'Londýn',
            'is_true' => true,
            'question_id' => $question1,
        ]);
        DB::table('options')->insert([
            'text' => 'Brezno',
            'is_true' => false,
            'question_id' => $question1,
        ]);
        DB::table('options')->insert([
            'text' => 'Paríž',
            'is_true' => true,
            'question_id' => $question2,
        ]);
        DB::table('options')->insert([
            'text' => 'Morava',
            'is_true' => false,
            'question_id' => $question2,
        ]);
        DB::table('options')->insert([
            'text' => 'Brezno',
            'is_true' => false,
            'question_id' => $question2,
        ]);

        //CATEGORIES
        $cat1 = DB::table('categories')->insertGetId([
            'name' => 'ROOT category',
            'user_id' => $prof1,
        ]);
        DB::table('categories')->insert([
            'name' => 'ROOT category2',
            'user_id' => $prof1,
        ]);
        $cat2 = DB::table('categories')->insertGetId([
            'name' => 'Subcategory',
            'supercategory_id' => $cat1,
            'user_id' => $prof1,
        ]);
        DB::table('categories')->insert([
            'name' => 'Subsubcategory',
            'supercategory_id' => $cat2,
            'user_id' => $prof1,
        ]);

        //TESTS
        $test1 = DB::table('tests')->insertGetId([
            'name' => 'Test in category',
            'category_id' => $cat1,
            'user_id' => $prof1,
            'test_score' => 3
        ]);
        $test2 = DB::table('tests')->insertGetId([
            'name' => 'Test in subcategory',
            'category_id' => $cat2,
            'user_id' => $prof1,
            'test_score' => 5
        ]);

        //SECTIONS
        $section1 = DB::table('sections')->insertGetId([
            'name' => 'Section1',
            'test_id' => $test1,
        ]);
        $section2 = DB::table('sections')->insertGetId([
            'name' => 'Section2',
            'test_id' => $test1,
        ]);
        $section3 = DB::table('sections')->insertGetId([
            'name' => 'Section1',
            'test_id' => $test2,
        ]);
        $section4 = DB::table('sections')->insertGetId([
            'name' => 'Section2',
            'test_id' => $test2,
        ]); 

        //JOIN SECTIONS AND QUESTIONS
        DB::table('question_section')->insert([
            'question_id' => $question1,
            'section_id' => $section1,
        ]);
        DB::table('question_section')->insert([
            'question_id' => $question2,
            'section_id' => $section1,
        ]);
        DB::table('question_section')->insert([
            'question_id' => $question3,
            'section_id' => $section2,
        ]);
        DB::table('question_section')->insert([
            'question_id' => $question1,
            'section_id' => $section3,
        ]);
        DB::table('question_section')->insert([
            'question_id' => $question2,
            'section_id' => $section3,
        ]);
        DB::table('question_section')->insert([
            'question_id' => $question3,
            'section_id' => $section4,
        ]);
        DB::table('question_section')->insert([
            'question_id' => $question4,
            'section_id' => $section4,
        ]);
        DB::table('question_section')->insert([
            'question_id' => $question5,
            'section_id' => $section4,
        ]);

        //APPROVALS
        DB::table('approvals')->insert([
            'user_id' => $assist1,
            'test_id' => $test1,
            'type' => 'fix',
            'approved' => true,
        ]);
        DB::table('approvals')->insert([
            'user_id' => $assist1,
            'test_id' => $test2,
            'type' => 'fix',
            'approved' => true,
        ]);
        DB::table('approvals')->insert([
            'user_id' => $assist2,
            'test_id' => $test2,
            'type' => 'fix',
            'approved' => false,
        ]);
        DB::table('approvals')->insert([
            'user_id' => $stud1,
            'test_id' => $test1,
            'type' => 'do',
            'approved' => true,
        ]);
        DB::table('approvals')->insert([
            'user_id' => $stud2,
            'test_id' => $test2,
            'type' => 'do',
            'approved' => true,
        ]);
        DB::table('approvals')->insert([
            'user_id' => $stud1,
            'test_id' => $test2,
            'type' => 'do',
            'approved' => false,
        ]);
        DB::table('approvals')->insert([
            'user_id' => $stud2,
            'test_id' => $test1,
            'type' => 'do',
            'approved' => true,
        ]);

        // //TEST_HISTORIES
        // $test_history = DB::table('test_histories')->insertGetId([
        //     'created_at' => '2020-11-27 12:00:00',
        //     'test_id' => $test1
        // ]);

        // //TEST_VARIANTS
        // $test_variant1 = DB::table('test_variants')->insertGetId([
        //     'created_at' => '2020-11-27 12:00:00',
        //     'name' => 'Should not show in results',
        //     'for_printing' => false,
        //     'checked' => true,
        //     'test_id' => $test1,
        //     'user_id' => $stud1,
        //     'test_history_id' => $test_history
        // ]);


        // //VARIANT_QUESTIONS
        // $variant_question1 = DB::table('variant_questions')->insertGetId([
        //     'number' => 1,
        //     'test_variant_id' => $test_variant1,
        //     'question_id' => $question1
        // ]);
        // $variant_question2 = DB::table('variant_questions')->insertGetId([
        //     'number' => 2,
        //     'test_variant_id' => $test_variant1,
        //     'question_id' => $question2
        // ]);
        // $variant_question3 = DB::table('variant_questions')->insertGetId([
        //     'number' => 2,
        //     'test_variant_id' => $test_variant1,
        //     'question_id' => $question3
        // ]);

        // //ANSWERS
        // DB::table('answers')->insertGetId([
        //     'variant_question_id' => $variant_question1,
        //     'score' => 1,
        //     'answer_text' => null
        // ]);
        // DB::table('answers')->insertGetId([
        //     'variant_question_id' => $variant_question2,
        //     'score' => 2,
        //     'answer_text' => null
        // ]);
        // DB::table('answers')->insertGetId([
        //     'variant_question_id' => $variant_question3,
        //     'score' => 2,
        //     'answer_text' => null
        // ]);
    }
}
