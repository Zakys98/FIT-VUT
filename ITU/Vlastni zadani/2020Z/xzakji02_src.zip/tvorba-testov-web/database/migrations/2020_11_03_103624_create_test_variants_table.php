<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTestVariantsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('test_variants', function (Blueprint $table) {
            $table->id();
            $table->timestamps();

            $table->string('name')->nullable(); // A, B, C, D... for printing
            $table->boolean('for_printing')->nullable();
            $table->boolean('checked')->default(0); // true after checked
            $table->foreignId('test_id')
            ->nullable()
            ->constrained()
            ->onDelete('cascade');
            $table->foreignId('user_id') // ... or online for concrete user
            ->nullable()
            ->constrained()
            ->onDelete('cascade');
            $table->foreignId('test_history_id') // ... to check time
            ->nullable()
            ->constrained();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('test_variants');
    }
}
