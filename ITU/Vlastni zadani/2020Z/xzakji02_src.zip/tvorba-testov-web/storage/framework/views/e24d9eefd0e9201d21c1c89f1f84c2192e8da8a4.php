 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Schvaľovanie asistentov
    </h2>
 <?php $__env->endSlot(); ?>

<div class="py-12">
    <?php echo json_encode($approvals); ?>
</div><?php /**PATH D:\Installed\xampp\htdocs\testit\resources\views/livewire/assists.blade.php ENDPATH**/ ?>