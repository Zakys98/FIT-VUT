 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Schvaľovanie užívateľov
    </h2>
 <?php $__env->endSlot(); ?>

<div class="py-12 h-screen bg-center bg-fixed" style="background-image:url('<?php echo e(asset('images/approvals.jpg')); ?>')">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            <?php if(session()->has('message')): ?>
                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm"><?php echo e(session('message')); ?></p>
                    </div>
                  </div>
                </div>
            <?php endif; ?>

            <table class="table-fixed w-full">
                <thead>
                    <tr class="bg-gray-100">
                        <!-- <th class="px-4 py-2 w-20">Id</th> -->
                        <th class="px-4 py-2 w-20">ID testu</th>
                        <th class="px-4 py-2">Test</th>
                        <th class="px-4 py-2">Meno</th>
                        <th class="px-4 py-2">Email</th>
                        <th class="px-4 py-2">Rola</th>
                        <th class="px-4 py-2">Typ</th>
                        <th class="px-4 py-2 md:w-32 xl:w-32">Schválenie</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border px-4 py-2"><?php echo e($approval->test->id); ?></td>
                        <td class="border px-4 py-2"><?php echo e($approval->test->name); ?></td>
                        <td class="border px-4 py-2"><?php echo e($approval->user->name); ?></td>
                        <td class="border px-4 py-2"><?php echo e($approval->user->email); ?></td>
                        <td class="border px-4 py-2"><?php echo e($approval->user->role); ?></td>
                        <td class="border px-4 py-2">
                            <?php if($approval->type=='fix'): ?> Oprava
                            <?php else: ?> Vypĺňanie
                            <?php endif; ?>
                        </td>
                        <td class="border px-4 py-2">
							<div class="flex items-center justify-center w-full">
								<!-- Toggle Button -->
								<label for="toogle<?php echo e($approval->id); ?>" class="flex items-center cursor-pointer">
									<!-- toggle -->
									<div class="relative">
										<!-- input -->
										<input wire:click="edit(<?php echo e($approval->id); ?>)" id="toogle<?php echo e($approval->id); ?>" type="checkbox" class="hidden" <?php if($approval->approved): ?> checked <?php endif; ?> />
										<!-- line -->
										<div class="toggle__line w-10 h-4 bg-gray-400 rounded-full shadow-inner"></div>
										<!-- dot -->
										<div class="toggle__dot absolute w-6 h-6 bg-white rounded-full shadow inset-y-0 left-0"></div>
									</div>
								</label>
							</div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH D:\Installed\xampp\htdocs\testit\resources\views/livewire/approvals.blade.php ENDPATH**/ ?>