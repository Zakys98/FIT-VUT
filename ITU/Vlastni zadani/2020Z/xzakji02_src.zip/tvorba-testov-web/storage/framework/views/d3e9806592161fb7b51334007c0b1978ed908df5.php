 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Oprava varianty
    </h2>
 <?php $__env->endSlot(); ?>

<div class="py-12 min-h-screen bg-center bg-fixed" style="background-image:url('<?php echo e(asset('images/testing.jpg')); ?>')">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">

            <div class="w-full sm:w-full md:w-full lg:w-11/12 xl:w-11/12 mx-auto"> <!-- content -->
            	<div class="text-center text-3xl mb-3 font-bold">
            		<?php echo e($testVariant->test->name); ?> - <?php echo e($testVariant->user->name); ?> (<?php echo e($testVariant->user->email); ?>)
            	</div>
            	<?php $__currentLoopData = $testVariant->variantQuestions()->orderBy('number')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variantQuestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('check-variant-question-component', ['variantQuestion' => $variantQuestion])->html();
} elseif ($_instance->childHasBeenRendered($variantQuestion->id)) {
    $componentId = $_instance->getRenderedChildComponentId($variantQuestion->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($variantQuestion->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($variantQuestion->id);
} else {
    $response = \Livewire\Livewire::mount('check-variant-question-component', ['variantQuestion' => $variantQuestion]);
    $html = $response->html();
    $_instance->logRenderedChild($variantQuestion->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="w-full mt-5 overflow-hidden">
            	   <button wire:click="save" class="bg-green-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded my-3 float-right">Uložiť hodnotenie</button>
                </div>
            </div>
            <?php if($message == 'error'): ?>
                <div class="bg-red-100 border-t-4 border-red-500 rounded-b text-red-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm">Zadané body musia byť v danom rozmedzí</p>
                    </div>
                  </div>
                </div>
            <?php elseif($message == 'success'): ?>
                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm">Body za jednotlivé úlohy boli úspešne uložené.</p>
                    </div>
                  </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH D:\Installed\xampp\htdocs\testit\resources\views/livewire/check-variant.blade.php ENDPATH**/ ?>