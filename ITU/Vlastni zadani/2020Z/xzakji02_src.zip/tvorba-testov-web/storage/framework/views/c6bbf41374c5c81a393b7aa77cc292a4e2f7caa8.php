 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Moje Výsledky
    </h2>
 <?php $__env->endSlot(); ?>

<div class="py-12 h-screen bg-center bg-fixed" style="background-image:url('<?php echo e(asset('images/approvals.jpg')); ?>')">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            <?php if(session()->has('message')): ?>
                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm"><?php echo e(session('message')); ?></p>
                    </div>
                  </div>
                </div>
            <?php endif; ?>

            <?php if($detail): ?>
            <div class="flex justify-start items-center">
                <button  wire:click="back">
                <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                    <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                </svg>
                </button>
                <h3 class="p-2 font-bold"><?php echo e($detailTestName); ?></h3>
            </div>
            <?php endif; ?>

            <table class="table-fixed w-full">
                <?php if($detail): ?>
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="px-4 py-2 w-24">Otázka</th>
                            <th class="px-4 py-2">Zadanie</th>
                            <th class="px-4 py-2 w-32">Hodnotenie</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $testQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="border px-4 py-2"><?php echo e($question->number); ?></td>
                            <td class="border px-4 py-2"><?php echo e($question->text); ?></td>
                            <td class="border px-4 py-2 text-center"><?php echo e($question->score); ?>/<?php echo e($question->fullscore); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                <?php else: ?>
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="px-4 py-2 w-24">ID testu</th>
                            <th class="px-4 py-2">Test</th>
                            <th class="px-4 py-2">Hodnotenie</th>
                            <th class="px-4 py-2">Detail</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $completedTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="border px-4 py-2"><?php echo e($test->test_id); ?></td>
                            <td class="border px-4 py-2"><?php echo e($test->name); ?></td>
                            <td class="border px-4 py-2 text-center">
                            <?php if($test->checked): ?>
                                <?php echo e($test->score); ?>/<?php echo e($test->fullscore); ?>

                            <?php else: ?> 
                                Čaká na opravu
                            <?php endif; ?>
                            </td>
                            <td class="border px-4 py-2 flex justify-center">
                                <button class="bg-transparent hover:bg-green-500 text-green-500 font-semibold hover:text-white py-2 px-4 border border-green-500 hover:border-transparent rounded-full shadow"
                                    id="detail<?php echo e($test->test_id); ?>"
                                    wire:click="detail(<?php echo e($test->id); ?>, '<?php echo e($test->name); ?>')">
                                    Zobraziť Detail
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>
<?php /**PATH D:\Installed\xampp\htdocs\testit\resources\views/livewire/results.blade.php ENDPATH**/ ?>