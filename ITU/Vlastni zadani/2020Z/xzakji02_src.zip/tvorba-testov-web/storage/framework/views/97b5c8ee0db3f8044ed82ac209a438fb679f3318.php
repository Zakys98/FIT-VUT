 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Čakáreň
    </h2>
 <?php $__env->endSlot(); ?>

<div class="py-12 h-screen bg-center bg-fixed" style="background-image:url('<?php echo e(asset('images/testing.jpg')); ?>')">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            <?php if(session()->has('message')): ?>
                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm"><?php echo e(session('message')); ?></p>
                    </div>
                  </div>
                </div>
            <?php endif; ?>

            <?php if($activeVariants->count() == 0): ?>
	            <div class="text-center">
	            	<span class="text-2xl font-bold">Momentálne neprebiehajú žiadne testy</span><br>
	            	<span class="text-xl font-bold">na ktoré ste zaregistrovaný a schválený</span>
	            </div>
	            <div class="mb-4 mt-4 text-sm">
	          		Pozn.: V prípade, že ste neboli zaregistrovaný a schválený v momente, kedy profesor spustil test, tak pre Vás nebola vygenerovaná varianta. Ďalšie pokusy o registráciu budú platiť až na budúce spustené testy.
	        	</div>
            <?php elseif($activeVariants->count() > 1): ?>
	            <form>
	            	<div class="text-center">
		            	<span class="text-2xl font-bold">Aktuálne prebiehajú viaceré testy naraz</span><br>
		            	<span class="text-xl font-bold">Vyberte, ktorý chcete spustiť</span>
		            </div>
		        	<div class="mb-4">
						<label for="chooseTest" class="block text-gray-700 text-sm font-bold mb-2">Test:</label>
						<select name= "testVariantId" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="chooseTest" wire:model="testVariantId">
						<option>Zvoľte test...</option>
						<?php $__currentLoopData = $activeVariants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeVariant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <option value='<?php echo e($activeVariant->id); ?>'><?php echo e($activeVariant->test->name); ?> (ID <?php echo e($activeVariant->test->id); ?>)</option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<?php $__errorArgs = ['testId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		            </div>
		            <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
			          <span class="flex w-full rounded-md shadow-sm sm:ml-3 sm:w-auto">
			            <button wire:click.prevent="redirectToTest()" type="button" class="inline-flex justify-center w-full rounded-md border border-transparent px-4 py-2 bg-green-600 text-base leading-6 font-medium text-white shadow-sm hover:bg-green-500 focus:outline-none focus:border-green-700 focus:shadow-outline-green transition ease-in-out duration-150 sm:text-sm sm:leading-5">
			              Spustiť
			            </button>
			          </span>
			        </div>
		        </form>
		    <?php else: ?> <!-- run test directly -->
		    	<div class="text-center">
	            	<span class="text-2xl font-bold">Spúšťam test</span><br>
	            		<div wire:init="redirectToTest()">
	            	</div>
	            </div>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH D:\Installed\xampp\htdocs\testit\resources\views/livewire/test-lobby.blade.php ENDPATH**/ ?>