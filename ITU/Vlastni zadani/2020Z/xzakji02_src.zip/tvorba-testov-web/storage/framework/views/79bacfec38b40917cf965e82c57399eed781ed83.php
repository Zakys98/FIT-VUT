 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Not found, go back to dashboard
    </h2>
 <?php $__env->endSlot(); ?><?php /**PATH D:\Installed\xampp\htdocs\testit\resources\views/livewire/not-found.blade.php ENDPATH**/ ?>