<?php
use Illuminate\Support\Facades\Storage;
?>

<div class="mt-10">
	<div class="text-xl mb-3 font-bold">
		<?php echo e($variantQuestion->number); ?>. <?php echo e($variantQuestion->question->text); ?>

	</div>

	<?php if($variantQuestion->question->attachment()->count()): ?>
		<?php if($variantQuestion->question->attachment->type == 'image'): ?>
			<img class="w-full mx-auto mb-3" style="max-width:700px;max-height:700px;" src="<?php echo e(asset('testImage/'.$variantQuestion->question->attachment->id)); ?>" alt="obrazová príloha">
		<?php else: ?>

		<?php endif; ?>
	<?php endif; ?>

	<div class="ml-6 mr-6">
		<?php if($variantQuestion->question->type == 'fulltext'): ?>
			<div class="font-bold text-lg">Očakávaná odpoveď:</div>
			<div class="ml-6"><?php echo e($variantQuestion->question->answer_text); ?></div>
			<div class="font-bold text-lg">Študentova odpoveď:</div>
			<div class="ml-6"><?php echo e($variantQuestion->answer->answer_text); ?></div>
		<?php else: ?>
			<div class="font-bold text-lg">Možnosti:</div>
			<ul class="list-disc ml-6">
			<?php $__currentLoopData = $variantQuestion->question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($option->is_true): ?><li class="text-green-500 font-bold"><?php else: ?><li><?php endif; ?>
					<?php echo e($option->text); ?>

				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
			<div class="font-bold text-lg">Študentova odpoveď:</div>
			<ul class="list-disc ml-6">
			<?php $__currentLoopData = $variantQuestion->answer->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($studOption->is_true): ?><li class="text-green-500 font-bold"><?php else: ?><li class="text-red-500 font-bold"><?php endif; ?>
					<?php echo e($studOption->text); ?>

				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		<?php endif; ?>

		<div class="font-bold text-lg">Hodnotnie (max <?php echo e($variantQuestion->max_score); ?>b):</div>
		<input type="number" step="0.01" wire:model="score" min="0" max="<?php echo e($variantQuestion->max_score); ?>" class="mt-2 shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline w-28" required>
		<?php $__errorArgs = ['score'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500">0 až <?php echo e($variantQuestion->max_score); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

	</div>
</div><?php /**PATH D:\Installed\xampp\htdocs\testit\resources\views/livewire/check-variant-question.blade.php ENDPATH**/ ?>