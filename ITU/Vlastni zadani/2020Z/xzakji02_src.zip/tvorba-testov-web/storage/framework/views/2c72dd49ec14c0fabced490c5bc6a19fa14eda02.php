<?php
use Illuminate\Support\Facades\Storage;
?>

<div class="mt-10">
	<div class="text-xl mb-3">
		<?php echo e($variantQuestion->number); ?>. <?php echo e($variantQuestion->question->text); ?>

	</div>

	<?php if($variantQuestion->question->attachment()->count()): ?>
		<?php if($variantQuestion->question->attachment->type == 'image'): ?>
			<img class="w-full mx-auto mb-3" style="max-width:700px;max-height:700px;" src="<?php echo e(asset('testImage/'.$variantQuestion->question->attachment->id)); ?>" alt="obrazová príloha">
		<?php else: ?>

		<?php endif; ?>
	<?php endif; ?>

	<div class="ml-6 mr-6">
		<?php if($variantQuestion->question->type == 'fulltext'): ?>
			<input type="text" name="fulltext_<?php echo e($variantQuestion->id); ?>" id="fulltext_<?php echo e($variantQuestion->id); ?>" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="Odpoveď..." wire:model="fulltextAnswer">
		<?php else: ?>
			<?php $__currentLoopData = $variantQuestion->question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($variantQuestion->question->is_multichoice): ?>
					<input id="option_<?php echo e($variantQuestion->id); ?>_<?php echo e($option->id); ?>" type="checkbox" wire:model="options.<?php echo e($option->id); ?>">
					<label class="container" for="option_<?php echo e($variantQuestion->id); ?>_<?php echo e($option->id); ?>">
						<?php echo e($option->text); ?>

					</label>
					<br>
				<?php else: ?>
					<input name="option_<?php echo e($variantQuestion->id); ?>_radio" id="option_<?php echo e($variantQuestion->id); ?>_<?php echo e($option->id); ?>" type="radio" wire:model="radioOption" value="<?php echo e($option->id); ?>">
					<label class="container" for="option_<?php echo e($variantQuestion->id); ?>_<?php echo e($option->id); ?>">
						<?php echo e($option->text); ?>

					</label>
					<br>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	</div>
</div><?php /**PATH D:\Installed\xampp\htdocs\testit\resources\views/livewire/do-test-question.blade.php ENDPATH**/ ?>