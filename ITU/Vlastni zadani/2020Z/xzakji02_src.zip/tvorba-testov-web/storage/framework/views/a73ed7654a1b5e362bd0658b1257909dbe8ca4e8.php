 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Registrácia na testy
    </h2>
 <?php $__env->endSlot(); ?>


<div class="py-12 h-screen bg-center bg-fixed" style="background-image:url('<?php echo e(asset('images/approvals.jpg')); ?>')">
    <?php if($userRole == 'assistant'): ?>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <ul class="flex rounded-t bg-gray-200">
          <li class="">
            <button wire:click="setTab( 'do' )" class="<?php if($tab == 'do'): ?> bg-white <?php else: ?> bg-gray-200 hover:bg-gray-300 <?php endif; ?>  inline-block rounded-t py-2 px-5 font-bold">
            Testovanie</button>
          </li>
          <li>
            <button wire:click="setTab( 'fix' )" class="<?php if($tab == 'fix'): ?> bg-white <?php else: ?> bg-gray-200 hover:bg-gray-300 <?php endif; ?>  inline-block rounded-t py-2 px-5 font-bold">
            Oprava</button>
          </li>
        </ul>
        </div>
    <?php endif; ?>

    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4 <?php if($userRole != 'student'): ?> sm:rounded-t-none <?php endif; ?>">
            <?php if(session()->has('message')): ?>
                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm"><?php echo e(session('message')); ?></p>
                    </div>
                  </div>
                </div>
            <?php endif; ?>

            <table class="table-fixed w-full">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-4 py-2 w-24">ID testu</th>
                        <th class="px-4 py-2">Test</th>
                        <th class="px-4 py-2">Vytvoril</th>
                        <th class="px-4 py-2">Registrácia</th>
                        <th class="px-4 py-2">Stav</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($tab == 'do'): ?>
                       <?php $__currentLoopData = $doTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $availTest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                                <td class="border px-4 py-2"><?php echo e($availTest->id); ?></td>
                                <td class="border px-4 py-2"><?php echo e($availTest->name); ?></td>
                                <td class="border px-4 py-2 text-center"><?php echo e($availTest->creator); ?></td>
                                <td class="border px-4 py-2">
							        <div class="flex items-center justify-center w-full">
                                        <div>
                                            <?php if($availTest->state === "waiting" or $availTest->state === "approved"): ?>
                                                <button class="bg-transparent hover:bg-red-500 text-red-500 font-semibold hover:text-white py-2 px-4 border border-red-500 hover:border-transparent rounded-full shadow"
                                                    id="unregisterBtn<?php echo e($availTest->id); ?>"
                                                    wire:click="unregister(<?php echo e($availTest->approvalId); ?>)">
                                                    Odhlásiť
                                                </button>
                                            <?php else: ?>
                                                <button class="bg-transparent hover:bg-green-500 text-green-500 font-semibold hover:text-white py-2 px-4 border border-green-500 hover:border-transparent rounded-full shadow"
                                                    id="registerBtn<?php echo e($availTest->id); ?>"
                                                    wire:click="register(<?php echo e($availTest->id); ?>, 'do')">
                                                    Prihlásiť
                                                </button>
                                            <?php endif; ?>
                                        </div>
							        </div>
                                </td>
                                <td class="border px-4 py-2">
                                    <div class="text-center">
                                        <?php if($availTest->state === "waiting"): ?>
                                            Čaká na schválenie
                                        <?php elseif($availTest->state === "approved"): ?>
                                            Prihlásený
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if($tab == 'fix'): ?>
                        <?php $__currentLoopData = $fixTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $availTest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                                <td class="border px-4 py-2"><?php echo e($availTest->id); ?></td>
                                <td class="border px-4 py-2"><?php echo e($availTest->name); ?></td>
                                <td class="border px-4 py-2 text-center"><?php echo e($availTest->creator); ?></td>
                                <td class="border px-4 py-2">
							        <div class="flex items-center justify-center w-full">
                                        <div>
                                            <?php if($availTest->state === "waiting" or $availTest->state === "approved"): ?>
                                                <button class="bg-transparent hover:bg-red-500 text-red-500 font-semibold hover:text-white py-2 px-4 border border-red-500 hover:border-transparent rounded-full shadow"
                                                    id="unregisterBtn<?php echo e($availTest->id); ?>"
                                                    wire:click="unregister(<?php echo e($availTest->approvalId); ?>)">
                                                    Odhlásiť
                                                </button>
                                            <?php else: ?>
                                                <button class="bg-transparent hover:bg-green-500 text-green-500 font-semibold hover:text-white py-2 px-4 border border-green-500 hover:border-transparent rounded-full shadow"
                                                    id="registerBtn<?php echo e($availTest->id); ?>"
                                                    wire:click="register(<?php echo e($availTest->id); ?>, 'fix')">
                                                    Prihlásiť
                                                </button>
                                            <?php endif; ?>
                                        </div>
							        </div>
                                </td>
                                <td class="border px-4 py-2">
                                    <div class="text-center">
                                        <?php if($availTest->state === "waiting"): ?>
                                            Čaká na schválenie
                                        <?php elseif($availTest->state === "approved"): ?>
                                            Prihlásený
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH D:\Installed\xampp\htdocs\testit\resources\views/livewire/registration.blade.php ENDPATH**/ ?>