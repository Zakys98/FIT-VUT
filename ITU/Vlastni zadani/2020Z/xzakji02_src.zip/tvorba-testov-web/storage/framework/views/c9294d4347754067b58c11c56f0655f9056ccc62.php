<?php
use Carbon\Carbon;
?>

 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Spúšťanie testov
    </h2>
 <?php $__env->endSlot(); ?>

<div class="py-12 h-screen bg-bottom bg-fixed" style="background-image:url('<?php echo e(asset('images/testing.jpg')); ?>')">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            <?php if(session()->has('message')): ?>
                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm"><?php echo e(session('message')); ?></p>
                    </div>
                  </div>
                </div>
            <?php endif; ?>

            <button wire:click="create()" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded my-3">Spustiť test</button>

            <?php if($modalOpened): ?>
                <?php echo $__env->make('livewire.choose-run-test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <table class="table-fixed w-full">
            	<caption class="text-2xl font-bold">História</caption>
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-4 py-2 w-32">Dátum</th>
                        <th class="px-4 py-2">Test</th>
                        <th class="px-4 py-2 w-48">Začiatok</th>
                        <th class="px-4 py-2 w-48">Koniec</th>
                        <th class="px-4 py-2 w-48">Stav</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $testHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border px-4 py-2"><?php echo e($testHistory->created_at->toDateString()); ?></td>
                        <td class="border px-4 py-2"><?php echo e($testHistory->test->name); ?> (ID <?php echo e($testHistory->test->id); ?>)</td>
                        <td class="border px-4 py-2"><?php echo e($testHistory->created_at->toTimeString()); ?></td>
                        <td class="border px-4 py-2"><?php echo e(Carbon::parse($testHistory->end)->toTimeString()); ?></td>
                        <td class="border px-4 py-2">
                        	<div class="flex items-center justify-center w-full">
                                <div>
			                        <?php if(Carbon::now()->gt($testHistory->created_at) && Carbon::now()->lt($testHistory->end)): ?>
			                        	<span>Prebieha</span>
			                        <?php else: ?>
			                        	<?php if(Carbon::now()->gt($testHistory->end)): ?>
			                        		<span>Ukončené</spav>
			                        	<?php endif; ?>
			                        <?php endif; ?>
                    			</div>
                    		</div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH D:\Installed\xampp\htdocs\testit\resources\views/livewire/run-test.blade.php ENDPATH**/ ?>