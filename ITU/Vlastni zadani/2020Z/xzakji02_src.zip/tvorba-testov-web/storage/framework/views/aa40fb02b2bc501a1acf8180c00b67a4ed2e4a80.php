 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Oprava testov
    </h2>
 <?php $__env->endSlot(); ?>

<div class="py-12 h-screen bg-center bg-fixed" style="background-image:url('<?php echo e(asset('images/testing.jpg')); ?>')">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            <?php if(session()->has('message')): ?>
                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm"><?php echo e(session('message')); ?></p>
                    </div>
                  </div>
                </div>
            <?php endif; ?>

            <?php if($modalOpened): ?>
                <?php echo $__env->make('livewire.choose-check-variant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <div class="text-center">
            	<span class="text-2xl font-bold">Zvoľte test pre zobrazenie variant</span>
	        </div>

            <table class="table-fixed w-full mt-4">
                <thead>
                    <tr class="bg-gray-100">
                        <!-- <th class="px-4 py-2 w-20">Id</th> -->
                        <th class="px-4 py-2 w-24 text-center">ID testu</th>
                        <th class="px-4 py-2">Test</th>
                        <?php if($actualRole == 'assistant'): ?>
                        	<th class="px-4 py-2">Autor testu</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr wire:click="checkTest(<?php echo e($test->id); ?>)" class="hover:bg-blue-300 cursor-pointer">
                        <td class="border px-4 py-2 text-center"><?php echo e($test->id); ?></td>
                        <td class="border px-4 py-2"><?php echo e($test->name); ?></td>
                        <?php if($actualRole == 'assistant'): ?>
                        	<td class="border px-4 py-2">
                        		<?php echo e($test->creator->name); ?> (<?php echo e($test->creator->email); ?>)
                        	</td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH D:\Installed\xampp\htdocs\testit\resources\views/livewire/check-tests.blade.php ENDPATH**/ ?>