 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Professor Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 h-screen bg-top bg-fixed" style="background-image:url('<?php echo e(asset('images/dashboard.jpg')); ?>')">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 m-auto">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-5 bg-opacity-0">
				<div class="flex flex-wrap -mx-2">
                    <div class="w-full sm:w-full md:w-1/2 lg:w-1/3 xl:w-1/3 px-2 py-2">
                        <a href="<?php echo e(route('test-creator')); ?>" class="bg-red-500 h-12 text-center py-3 text-white font-semibold block">Vytvoriť test</a>
                    </div>
                    <div class="w-full sm:w-full md:w-1/2 lg:w-1/3 xl:w-1/3 px-2 py-2">
                        <a href='<?php echo e(route('check-tests')); ?>' class="bg-blue-500 h-12 text-center py-3 text-white font-semibold block">Opraviť testy</a>
                    </div>
                    <div class="w-full sm:w-full md:w-1/2 lg:w-1/3 xl:w-1/3 px-2 py-2">
                        <a href="<?php echo e(route('approvals')); ?>" class="bg-purple-500 h-12 text-center py-3 text-white font-semibold block">Schvaľovanie</a>
                    </div>
                    <div class="w-full sm:w-full md:w-1/2 lg:w-1/3 xl:w-1/3 px-2 py-2">
                        <a href='<?php echo e(route('registration')); ?>' class="bg-yellow-500 h-12 text-center py-3 text-white font-semibold block">Registrovať na test</a>
                    </div>
                    <div class="w-full sm:w-full md:w-1/2 lg:w-1/3 xl:w-1/3 px-2 py-2 ml-auto">
                        <a href='<?php echo e(route('test-lobby')); ?>' class="bg-teal-500 h-12 text-center py-3 text-white font-semibold block">Vyplniť test</a>
                    </div>
                    <div class="w-full sm:w-full md:w-1/2 lg:w-1/3 xl:w-1/3 px-2 py-2 ml-auto">
                        <a href="<?php echo e(route('run-test')); ?>" class="bg-green-500 h-12 text-center py-3 text-white font-semibold block">Spustiť test</a>
                    </div>
                    <div class="w-full sm:w-full md:w-1/2 lg:w-1/3 xl:w-1/3 px-2 py-2 ml-auto mr-auto">
                        <a href='<?php echo e(route('results')); ?>' class="bg-orange-500 h-12 text-center py-3 text-white font-semibold block">Moje Výsledky</a>
                    </div>
				</div>
			</div>
         </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH D:\Installed\xampp\htdocs\testit\resources\views/prof-dashboard.blade.php ENDPATH**/ ?>