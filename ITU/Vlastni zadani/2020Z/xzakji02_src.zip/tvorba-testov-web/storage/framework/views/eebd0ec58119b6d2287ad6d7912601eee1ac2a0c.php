 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Vypĺňanie testu
    </h2>
 <?php $__env->endSlot(); ?>

<div class="py-12 min-h-screen bg-center bg-fixed" style="background-image:url('<?php echo e(asset('images/testing.jpg')); ?>')">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            <?php if($ended): ?>
                <div class="text-center mb-8">
                    <span class="text-2xl font-bold">Test skončil</span><br>
                </div>
                <span>Opravený test nájdete v sekcii Moje Výsledky. Otázky s možnosťami sú opravované automaticky, tie s plnou odpoveďou Vám opraví Váš učiteľ, prípadne pridelený asistent.</span>

            <?php else: ?>
                <div class="w-full sm:w-full md:w-full lg:w-11/12 xl:w-11/12 mx-auto"> <!-- content -->
                	<div class="text-center text-3xl mb-3 font-bold">
                		<?php echo e($testVariant->test->name); ?>

                	</div>
                	<?php $__currentLoopData = $testVariant->variantQuestions()->orderBy('number')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variantQuestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('do-test-question-component', ['variantQuestion' => $variantQuestion])->html();
} elseif ($_instance->childHasBeenRendered($variantQuestion->id)) {
    $componentId = $_instance->getRenderedChildComponentId($variantQuestion->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($variantQuestion->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($variantQuestion->id);
} else {
    $response = \Livewire\Livewire::mount('do-test-question-component', ['variantQuestion' => $variantQuestion]);
    $html = $response->html();
    $_instance->logRenderedChild($variantQuestion->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="w-full mt-5 overflow-hidden">
                	   <button wire:click="$emit('testSaved')" class="bg-green-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded my-3 float-right">Uložiť</button>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(session()->has('message')): ?>
                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm"><?php echo e(session('message')); ?></p>
                    </div>
                  </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH D:\Installed\xampp\htdocs\testit\resources\views/livewire/do-test.blade.php ENDPATH**/ ?>