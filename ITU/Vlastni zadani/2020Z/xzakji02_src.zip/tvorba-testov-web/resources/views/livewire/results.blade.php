<x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Moje Výsledky
    </h2>
</x-slot>

<div class="py-12 h-screen bg-center bg-fixed" style="background-image:url('{{asset('images/approvals.jpg')}}')">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            @if (session()->has('message'))
                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm">{{ session('message') }}</p>
                    </div>
                  </div>
                </div>
            @endif

            @if ($detail)
            <div class="flex justify-start items-center">
                <button  wire:click="back">
                <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                    <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                </svg>
                </button>
                <h3 class="p-2 font-bold">{{ $detailTestName }}</h3>
            </div>
            @endif

            <table class="table-fixed w-full">
                @if ($detail)
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="px-4 py-2 w-24">Otázka</th>
                            <th class="px-4 py-2">Zadanie</th>
                            <th class="px-4 py-2 w-32">Hodnotenie</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($testQuestions as $question)
                        <tr>
                            <td class="border px-4 py-2">{{ $question->number }}</td>
                            <td class="border px-4 py-2">{{ $question->text }}</td>
                            <td class="border px-4 py-2 text-center">{{ $question->score }}/{{ $question->fullscore }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                @else
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="px-4 py-2 w-24">ID testu</th>
                            <th class="px-4 py-2">Test</th>
                            <th class="px-4 py-2">Hodnotenie</th>
                            <th class="px-4 py-2">Detail</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($completedTests as $test)
                        <tr>
                            <td class="border px-4 py-2">{{ $test->test_id }}</td>
                            <td class="border px-4 py-2">{{ $test->name }}</td>
                            <td class="border px-4 py-2 text-center">
                            @if ($test->checked)
                                {{ $test->score }}/{{ $test->fullscore }}
                            @else 
                                Čaká na opravu
                            @endif
                            </td>
                            <td class="border px-4 py-2 flex justify-center">
                                <button class="bg-transparent hover:bg-green-500 text-green-500 font-semibold hover:text-white py-2 px-4 border border-green-500 hover:border-transparent rounded-full shadow"
                                    id="detail{{ $test->test_id }}"
                                    wire:click="detail({{ $test->id }}, '{{ $test->name }}')">
                                    Zobraziť Detail
                                </button>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                @endif
            </table>
        </div>
    </div>
</div>
