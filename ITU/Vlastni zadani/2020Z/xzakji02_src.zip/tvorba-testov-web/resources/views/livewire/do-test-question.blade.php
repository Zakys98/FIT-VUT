<?php
use Illuminate\Support\Facades\Storage;
?>

<div class="mt-10">
	<div class="text-xl mb-3">
		{{ $variantQuestion->number }}. {{ $variantQuestion->question->text }}
	</div>

	@if ($variantQuestion->question->attachment()->count())
		@if($variantQuestion->question->attachment->type == 'image')
			<img class="w-full mx-auto mb-3" style="max-width:700px;max-height:700px;" src="{{asset('testImage/'.$variantQuestion->question->attachment->id)}}" alt="obrazová príloha">
		@else

		@endif
	@endif

	<div class="ml-6 mr-6">
		@if ($variantQuestion->question->type == 'fulltext')
			<input type="text" name="fulltext_{{$variantQuestion->id}}" id="fulltext_{{$variantQuestion->id}}" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="Odpoveď..." wire:model="fulltextAnswer">
		@else
			@foreach ($variantQuestion->question->options as $option)
				@if ($variantQuestion->question->is_multichoice)
					<input id="option_{{$variantQuestion->id}}_{{$option->id}}" type="checkbox" wire:model="options.{{ $option->id }}">
					<label class="container" for="option_{{$variantQuestion->id}}_{{$option->id}}">
						{{ $option->text }}
					</label>
					<br>
				@else
					<input name="option_{{$variantQuestion->id}}_radio" id="option_{{$variantQuestion->id}}_{{$option->id}}" type="radio" wire:model="radioOption" value="{{$option->id}}">
					<label class="container" for="option_{{$variantQuestion->id}}_{{$option->id}}">
						{{ $option->text }}
					</label>
					<br>
				@endif
			@endforeach
		@endif
	</div>
</div>