<x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Vypĺňanie testu
    </h2>
</x-slot>

<div class="py-12 min-h-screen bg-center bg-fixed" style="background-image:url('{{asset('images/testing.jpg')}}')">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            @if ($ended)
                <div class="text-center mb-8">
                    <span class="text-2xl font-bold">Test skončil</span><br>
                </div>
                <span>Opravený test nájdete v sekcii Moje Výsledky. Otázky s možnosťami sú opravované automaticky, tie s plnou odpoveďou Vám opraví Váš učiteľ, prípadne pridelený asistent.</span>

            @else
                <div class="w-full sm:w-full md:w-full lg:w-11/12 xl:w-11/12 mx-auto"> <!-- content -->
                	<div class="text-center text-3xl mb-3 font-bold">
                		{{ $testVariant->test->name }}
                	</div>
                	@foreach($testVariant->variantQuestions()->orderBy('number')->get() as $variantQuestion)
                		<livewire:do-test-question-component :variantQuestion="$variantQuestion" :key="$variantQuestion->id">
                	@endforeach
                    <div class="w-full mt-5 overflow-hidden">
                	   <button wire:click="$emit('testSaved')" class="bg-green-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded my-3 float-right">Uložiť</button>
                    </div>
                </div>
            @endif
            @if (session()->has('message'))
                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm">{{ session('message') }}</p>
                    </div>
                  </div>
                </div>
            @endif
        </div>
    </div>
</div>