<div class="fixed z-10 inset-0 overflow-y-auto ease-out duration-400">
  <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
      
    <div class="fixed inset-0 transition-opacity">
      <div class="absolute inset-0 bg-gray-500 opacity-75" wire:click="closeModal()"></div>
    </div>
  
    <!-- This element is to trick the browser into centering the modal contents. -->
<!--     <span class="hidden sm:inline-block sm:align-middle sm:h-screen"></span>​ -->
  
    <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle max-w-7xl sm:w-full" role="dialog" aria-modal="true" aria-labelledby="modal-headline">
      <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 sm:w-full">
        <div class="text-center">
          <span class="text-2xl font-bold">Oprava testových variant</span>
        </div>

        <div class="px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
          <span class="mt-3 flex w-full rounded-md shadow-sm sm:mt-0 sm:w-auto sm:ml-3">
            <button wire:click="closeModal()" type="button" class="inline-flex justify-center w-full rounded-md border border-gray-300 px-4 py-2 bg-white text-base leading-6 font-medium text-gray-700 shadow-sm hover:text-white focus:outline-none focus:border-blue-300 focus:shadow-outline-blue transition ease-in-out duration-150 sm:text-sm sm:leading-5 hover:bg-red-500 focus:border-red-700">
              Zavrieť
            </button>
          </span>
          <span class="mt-3 flex w-full rounded-md shadow-sm sm:mt-0 sm:w-auto">
            <button wire:click="automaticCheck()" type="button" class="inline-flex justify-center w-full rounded-md border border-transparent px-4 py-2 bg-green-600 text-base leading-6 font-medium text-white shadow-sm hover:bg-green-500 focus:outline-none focus:border-green-700 focus:shadow-outline-green transition ease-in-out duration-150 sm:text-sm sm:leading-5">
              Automatická oprava
            </button>
          </span>
        </div>

        <div class="text-center">
          <span class="text-xl">Automatická oprava slúži len pre otázky s 1 správnou možnosťou</span><br>
          <span class="text-sm">V budúcnosti sa uvažuje o módoch pre opravu s viacerými možnosťami (napr. strhávať body vs nestrhávať)</span>
        </div>

        <table class="table-fixed w-full mt-4">
          <thead>
              <tr class="bg-gray-100">
                  <!-- <th class="px-4 py-2 w-20">Id</th> -->
                  <th class="px-4 py-2 w-32 text-center">Dátum</th>
                  <th class="px-4 py-2 w-32 text-center">ID varianty</th>
                  <th class="px-4 py-2 text-center">Užívateľ</th>
                  <th class="px-4 py-2 w-36 text-center">Stav</th>
                  <th class="px-4 py-2 w-24 text-center">Body</th>
                  <th class="px-4 py-2 w-44 text-center">Manuálna oprava</th>
              </tr>
          </thead>
          <tbody>
              @foreach($testVariants as $testVariant)
              <tr>
                  <td class="border px-4 py-2 text-center">{{ $testVariant->created_at->toDateString() }}</td>
                  <td class="border px-4 py-2">{{ $testVariant->id }}</td>
                  <td class="border px-4 py-2">{{$testVariant->user->name}} ({{$testVariant->user->email}})</td>
                  @if($testVariant->checked)
                    <td class="border px-4 py-2 text-center bg-green-500 text-white">Opravené</td>
                  @else
                    <td class="border px-4 py-2 text-center bg-red-500 text-white">Čaká na opravu</td>
                  @endif
                  <td class="border px-4 py-2 text-center">
                      <div wire:loading>
                          loading
                      </div>
                      <div wire:loading.remove>
                        @if(is_null($testVariant->score))
                        -
                        @else
                        {{ $testVariant->score }}
                        @endif
                        /{{ $testVariant->max_score }}
                      </div>
                  </td>
                  <td class="border px-4 py-2">
                    <div class="flex items-center justify-center w-full">
                      <button wire:click="checkVariant({{ $testVariant->id }})" class="bg-transparent hover:bg-green-500 text-green-500 font-semibold hover:text-white py-2 px-4 border border-green-500 hover:border-transparent rounded-full shadow" wire:click="checkVariant({{ $testVariant->id }} )">
                          Opraviť
                      </button>
                    </div>
                  </td>
              </tr>
              @endforeach
          </tbody>
        </table>
      </div>

    </div>
        
  </div>
</div>
