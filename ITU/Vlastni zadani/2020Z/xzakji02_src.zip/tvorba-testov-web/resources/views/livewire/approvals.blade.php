<x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Schvaľovanie užívateľov
    </h2>
</x-slot>

<div class="py-12 h-screen bg-center bg-fixed" style="background-image:url('{{asset('images/approvals.jpg')}}')">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            @if (session()->has('message'))
                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm">{{ session('message') }}</p>
                    </div>
                  </div>
                </div>
            @endif

            <table class="table-fixed w-full">
                <thead>
                    <tr class="bg-gray-100">
                        <!-- <th class="px-4 py-2 w-20">Id</th> -->
                        <th class="px-4 py-2 w-20">ID testu</th>
                        <th class="px-4 py-2">Test</th>
                        <th class="px-4 py-2">Meno</th>
                        <th class="px-4 py-2">Email</th>
                        <th class="px-4 py-2">Rola</th>
                        <th class="px-4 py-2">Typ</th>
                        <th class="px-4 py-2 md:w-32 xl:w-32">Schválenie</th>

                    </tr>
                </thead>
                <tbody>
                    @foreach($approvals as $approval)
                    <tr>
                        <td class="border px-4 py-2">{{ $approval->test->id }}</td>
                        <td class="border px-4 py-2">{{ $approval->test->name }}</td>
                        <td class="border px-4 py-2">{{ $approval->user->name }}</td>
                        <td class="border px-4 py-2">{{ $approval->user->email }}</td>
                        <td class="border px-4 py-2">{{ $approval->user->role }}</td>
                        <td class="border px-4 py-2">
                            @if($approval->type=='fix') Oprava
                            @else Vypĺňanie
                            @endif
                        </td>
                        <td class="border px-4 py-2">
							<div class="flex items-center justify-center w-full">
								<!-- Toggle Button -->
								<label for="toogle{{$approval->id}}" class="flex items-center cursor-pointer">
									<!-- toggle -->
									<div class="relative">
										<!-- input -->
										<input wire:click="edit({{ $approval->id }})" id="toogle{{$approval->id}}" type="checkbox" class="hidden" @if($approval->approved) checked @endif />
										<!-- line -->
										<div class="toggle__line w-10 h-4 bg-gray-400 rounded-full shadow-inner"></div>
										<!-- dot -->
										<div class="toggle__dot absolute w-6 h-6 bg-white rounded-full shadow inset-y-0 left-0"></div>
									</div>
								</label>
							</div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>