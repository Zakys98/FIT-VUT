<x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Oprava testov
    </h2>
</x-slot>

<div class="py-12 h-screen bg-center bg-fixed" style="background-image:url('{{asset('images/testing.jpg')}}')">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            @if (session()->has('message'))
                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm">{{ session('message') }}</p>
                    </div>
                  </div>
                </div>
            @endif

            @if($modalOpened)
                @include('livewire.choose-check-variant')
            @endif

            <div class="text-center">
            	<span class="text-2xl font-bold">Zvoľte test pre zobrazenie variant</span>
	        </div>

            <table class="table-fixed w-full mt-4">
                <thead>
                    <tr class="bg-gray-100">
                        <!-- <th class="px-4 py-2 w-20">Id</th> -->
                        <th class="px-4 py-2 w-24 text-center">ID testu</th>
                        <th class="px-4 py-2">Test</th>
                        @if($actualRole == 'assistant')
                        	<th class="px-4 py-2">Autor testu</th>
                        @endif
                    </tr>
                </thead>
                <tbody>
                    @foreach($tests as $test)
                    <tr wire:click="checkTest({{ $test->id }})" class="hover:bg-blue-300 cursor-pointer">
                        <td class="border px-4 py-2 text-center">{{ $test->id }}</td>
                        <td class="border px-4 py-2">{{ $test->name }}</td>
                        @if($actualRole == 'assistant')
                        	<td class="border px-4 py-2">
                        		{{ $test->creator->name }} ({{ $test->creator->email }})
                        	</td>
                        @endif
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>