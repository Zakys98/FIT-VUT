<x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Registrácia na testy
    </h2>
</x-slot>


<div class="py-12 h-screen bg-center bg-fixed" style="background-image:url('{{asset('images/approvals.jpg')}}')">
    @if ($userRole == 'assistant')
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <ul class="flex rounded-t bg-gray-200">
          <li class="">
            <button wire:click="setTab( 'do' )" class="@if($tab == 'do') bg-white @else bg-gray-200 hover:bg-gray-300 @endif  inline-block rounded-t py-2 px-5 font-bold">
            Testovanie</button>
          </li>
          <li>
            <button wire:click="setTab( 'fix' )" class="@if($tab == 'fix') bg-white @else bg-gray-200 hover:bg-gray-300 @endif  inline-block rounded-t py-2 px-5 font-bold">
            Oprava</button>
          </li>
        </ul>
        </div>
    @endif

    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4 @if($userRole != 'student') sm:rounded-t-none @endif">
            @if (session()->has('message'))
                <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                  <div class="flex">
                    <div>
                      <p class="text-sm">{{ session('message') }}</p>
                    </div>
                  </div>
                </div>
            @endif

            <table class="table-fixed w-full">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-4 py-2 w-24">ID testu</th>
                        <th class="px-4 py-2">Test</th>
                        <th class="px-4 py-2">Vytvoril</th>
                        <th class="px-4 py-2">Registrácia</th>
                        <th class="px-4 py-2">Stav</th>
                    </tr>
                </thead>
                <tbody>
                    @if($tab == 'do')
                       @foreach($doTests as $availTest)
                           <tr>
                                <td class="border px-4 py-2">{{ $availTest->id }}</td>
                                <td class="border px-4 py-2">{{ $availTest->name }}</td>
                                <td class="border px-4 py-2 text-center">{{ $availTest->creator }}</td>
                                <td class="border px-4 py-2">
							        <div class="flex items-center justify-center w-full">
                                        <div>
                                            @if ($availTest->state === "waiting" or $availTest->state === "approved")
                                                <button class="bg-transparent hover:bg-red-500 text-red-500 font-semibold hover:text-white py-2 px-4 border border-red-500 hover:border-transparent rounded-full shadow"
                                                    id="unregisterBtn{{ $availTest->id }}"
                                                    wire:click="unregister({{ $availTest->approvalId }})">
                                                    Odhlásiť
                                                </button>
                                            @else
                                                <button class="bg-transparent hover:bg-green-500 text-green-500 font-semibold hover:text-white py-2 px-4 border border-green-500 hover:border-transparent rounded-full shadow"
                                                    id="registerBtn{{ $availTest->id }}"
                                                    wire:click="register({{ $availTest->id }}, 'do')">
                                                    Prihlásiť
                                                </button>
                                            @endif
                                        </div>
							        </div>
                                </td>
                                <td class="border px-4 py-2">
                                    <div class="text-center">
                                        @if ($availTest->state === "waiting")
                                            Čaká na schválenie
                                        @elseif ($availTest->state === "approved")
                                            Prihlásený
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    @endif
                    @if ($tab == 'fix')
                        @foreach($fixTests as $availTest)
                           <tr>
                                <td class="border px-4 py-2">{{ $availTest->id }}</td>
                                <td class="border px-4 py-2">{{ $availTest->name }}</td>
                                <td class="border px-4 py-2 text-center">{{ $availTest->creator }}</td>
                                <td class="border px-4 py-2">
							        <div class="flex items-center justify-center w-full">
                                        <div>
                                            @if ($availTest->state === "waiting" or $availTest->state === "approved")
                                                <button class="bg-transparent hover:bg-red-500 text-red-500 font-semibold hover:text-white py-2 px-4 border border-red-500 hover:border-transparent rounded-full shadow"
                                                    id="unregisterBtn{{ $availTest->id }}"
                                                    wire:click="unregister({{ $availTest->approvalId }})">
                                                    Odhlásiť
                                                </button>
                                            @else
                                                <button class="bg-transparent hover:bg-green-500 text-green-500 font-semibold hover:text-white py-2 px-4 border border-green-500 hover:border-transparent rounded-full shadow"
                                                    id="registerBtn{{ $availTest->id }}"
                                                    wire:click="register({{ $availTest->id }}, 'fix')">
                                                    Prihlásiť
                                                </button>
                                            @endif
                                        </div>
							        </div>
                                </td>
                                <td class="border px-4 py-2">
                                    <div class="text-center">
                                        @if ($availTest->state === "waiting")
                                            Čaká na schválenie
                                        @elseif ($availTest->state === "approved")
                                            Prihlásený
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>
