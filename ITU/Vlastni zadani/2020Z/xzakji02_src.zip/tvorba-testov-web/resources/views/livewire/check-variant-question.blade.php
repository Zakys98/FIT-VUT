<?php
use Illuminate\Support\Facades\Storage;
?>

<div class="mt-10">
	<div class="text-xl mb-3 font-bold">
		{{ $variantQuestion->number }}. {{ $variantQuestion->question->text }}
	</div>

	@if ($variantQuestion->question->attachment()->count())
		@if($variantQuestion->question->attachment->type == 'image')
			<img class="w-full mx-auto mb-3" style="max-width:700px;max-height:700px;" src="{{asset('testImage/'.$variantQuestion->question->attachment->id)}}" alt="obrazová príloha">
		@else

		@endif
	@endif

	<div class="ml-6 mr-6">
		@if ($variantQuestion->question->type == 'fulltext')
			<div class="font-bold text-lg">Očakávaná odpoveď:</div>
			<div class="ml-6">{{ $variantQuestion->question->answer_text }}</div>
			<div class="font-bold text-lg">Študentova odpoveď:</div>
			<div class="ml-6">{{ $variantQuestion->answer->answer_text }}</div>
		@else
			<div class="font-bold text-lg">Možnosti:</div>
			<ul class="list-disc ml-6">
			@foreach ($variantQuestion->question->options as $option)
				@if($option->is_true)<li class="text-green-500 font-bold">@else<li>@endif
					{{ $option->text }}
				</li>
			@endforeach
			</ul>
			<div class="font-bold text-lg">Študentova odpoveď:</div>
			<ul class="list-disc ml-6">
			@foreach ($variantQuestion->answer->options as $studOption)
				@if($studOption->is_true)<li class="text-green-500 font-bold">@else<li class="text-red-500 font-bold">@endif
					{{ $studOption->text }}
				</li>
			@endforeach
			</ul>
		@endif

		<div class="font-bold text-lg">Hodnotnie (max {{ $variantQuestion->max_score }}b):</div>
		<input type="number" step="0.01" wire:model="score" min="0" max="{{ $variantQuestion->max_score }}" class="mt-2 shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline w-28" required>
		@error('score') <span class="text-red-500">0 až {{ $variantQuestion->max_score }}</span>@enderror

	</div>
</div>