<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoriesController;
use App\Http\Controllers\TestsController;
use App\Http\Controllers\SectionsController;
use App\Http\Controllers\QuestionsController;
use App\Http\Controllers\OptionsController;
use App\Http\Controllers\AttachmentsController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PrintVariantsController;

use App\Http\Livewire\UsersComponent;
use App\Http\Livewire\ApprovalsComponent;
use App\Http\Livewire\RegistrationComponent;
use App\Http\Livewire\DoTestComponent;
use App\Http\Livewire\TestsHistoryComponent;
use App\Http\Livewire\TestLobbyComponent;

use App\Http\Livewire\CheckTestsComponent;
use App\Http\Livewire\CheckVariantComponent;
use App\Http\Livewire\ResultsComponent;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    // return view('welcome');
    return redirect('login');
});
///// <API> /////
Route::apiResource('categories', CategoriesController::class);//->middleware('auth:sanctum');
Route::apiResource('tests', TestsController::class);//->middleware('auth:sanctum');

Route::get('questions', [QuestionsController::class, 'allQuestions'])->name('questions.index');
Route::get('questions/{question}', [QuestionsController::class, 'show'])->name('questions.show');
Route::delete('questions/{question}', [QuestionsController::class, 'destroy'])->name('questions.destroy');

Route::get('tests/{test}/sections', [SectionsController::class, 'index'])->name('sections.index');
Route::post('tests/{test}/sections', [SectionsController::class, 'store'])->name('sections.store');
Route::put('tests/{test}/sections/{section}', [SectionsController::class, 'update'])->name('sections.update');
Route::delete('tests/{test}/sections/{section}', [SectionsController::class, 'destroy'])->name('sections.destroy');

Route::get('tests/{test}/testVariants', [PrintVariantsController::class, 'index'])->name('testVariants.index');
Route::post('tests/{test}/testVariants', [PrintVariantsController::class, 'store'])->name('testVariants.store');
Route::get('tests/{test}/testVariants/{testVariant}', [PrintVariantsController::class, 'show'])->name('testVariants.show');
Route::delete('tests/{test}/testVariants/{testVariant}', [PrintVariantsController::class, 'destroy'])->name('testVariants.destroy');

Route::post('tests/{test}/sections/{section}/questions', [QuestionsController::class, 'store'])->name('tests.sections.questions.store');
Route::get('tests/{test}/sections/{section}/questions', [QuestionsController::class, 'index'])->name('tests.sections.questions.index');
Route::put('tests/{test}/sections/{section}/questions/{question}', [QuestionsController::class, 'update'])->name('tests.sections.questions.update');
Route::delete('tests/{test}/sections/{section}/questions/{question}', [QuestionsController::class, 'detach'])->name('tests.sections.questions.detach');
Route::get('tests/{test}/sections/{section}/questions/{question}/attach', [QuestionsController::class, 'attach'])->name('tests.sections.questions.attach');

Route::apiResource('options', OptionsController::class);
Route::apiResource('attachments', AttachmentsController::class);
///// </API> /////


// Route::get('uploader', function (Request $request){
// 	$csrf = csrf_token();
// 	return <<<EOT

// 	<form action="/attachments" method="POST" enctype="multipart/form-data">
// 		<input type="hidden" name="_token" value="$csrf">
// 		<input type="text" name="title">
// 		<input type="text" name="type">
// 		<input type="file" name="file">
// 		<input type="submit">
// 	</form>


// 	EOT;
// });
Route::get('csrf', function (Request $request){
	$csrf = csrf_token();
	return response()->json(['token' => $csrf]);
});

Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', [DashboardController::class, 'render'])->name('dashboard');

Route::get('admin/users', UsersComponent::class)->name('users-management')->middleware('auth:sanctum');
Route::get('approvals', ApprovalsComponent::class)->name('approvals')->middleware('auth:sanctum');
Route::get('testVariant/{testVariant}', DoTestComponent::class)->name('do-test')->middleware('auth:sanctum');
//registration to test
Route::get('registration', RegistrationComponent::class)->name('registration')->middleware('auth:sanctum');
Route::get('testLobby', TestLobbyComponent::class)->name('test-lobby')->middleware('auth:sanctum');
Route::get('runTest', TestsHistoryComponent::class)->name('run-test')->middleware('auth:sanctum');
Route::get('checkTests', CheckTestsComponent::class)->name('check-tests')->middleware('auth:sanctum');
Route::get('checkTests/{testVariant}', CheckVariantComponent::class)->name('check-variant')->middleware('auth:sanctum');
Route::get('results', ResultsComponent::class)->name('results')->middleware('auth:sanctum');

Route::get('test-creator', function (Request $request){
	$files = scandir('react/js');
	$scripts = [];
	foreach($files as $file)
	{
		if(substr($file, -2) === "js")
		{
			$scripts[] = asset('react/js/'.$file);
		}
	}
	$files = scandir('react/css');
	$react_css = [];
	foreach($files as $file)
	{
		if(substr($file, -3) === "css")
		{
			$react_css[] = asset('react/css/'.$file);
		}
	}

	return view('test')->with(['scripts' => $scripts, 'react_css' => $react_css]);
})->name('test-creator')->middleware('auth:sanctum');

Route::get('testImage/{attachment}', [AttachmentsController::class, 'showInVariant'])->name('testImage')->middleware('auth:sanctum');
