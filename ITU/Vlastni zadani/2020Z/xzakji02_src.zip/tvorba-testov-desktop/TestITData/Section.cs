﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace TestITData
{
    public class Section
    {
        public Section(string id, string name, string question_score, string question_count, string test_Id)
        {
            Id = id;
            Name = name;
            Question_Score = question_score;
            Question_Count = question_count;
            Test_Id = test_Id;
        }
        public string Id { get; set; }
        public string Created_At { get; set; }
        public string Updated_At { get; set; }
        public string Name { get; set; }
        public string Question_Score { get; set; }
        public string Question_Count { get; set; }
        public string Test_Id { get; set; }
        public ObservableCollection<Question> Questions { get; set; }
    }
}
