﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestITData
{
    public class VariantQuestion
    {
        public VariantQuestion(string id, string number, string max_score)
        {
            Id = id;
            Number = number;
            Max_Score = max_score;
        }
        public string Id { get; set; }
        public string Created_At { get; set; }
        public string Updated_At { get; set; }
        public string Number { get; set; }
        public string Max_Score { get; set; }
        public string Test_Variant_Id { get; set; }
        public string Question_Id { get; set; }
        public Question Question { get; set; }
    }
}
