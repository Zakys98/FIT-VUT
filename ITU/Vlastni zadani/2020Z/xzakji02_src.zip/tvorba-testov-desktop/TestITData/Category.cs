﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestITData
{
  public class Category
  {
    public Category(string name, string supercategory)
    {
      this.Name = name;
      this.Supercategory_Id = supercategory;
    }
    public string Id { get; set; }
    public string Created_At { get; set; }
    public string Updated_At { get; set; }
    public string Name { get; set; }
    public string Supercategory_Id { get; set; }
    public ObservableCollection<Category> Subcategories { get; set; }
    public ObservableCollection<Test> Tests { get; set; }
  }
}
