﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace TestITData
{
  public class Test
  {
    public Test(string id, string name, string category_id, string user_id, string test_score)
    {
      Id = id;
      Name = name;
      Category_Id = category_id;
      User_Id = user_id;
      Test_Score = test_score;
    }
    public string Id { get; set; }
    public string Created_At { get; set; }
    public string Updated_At { get; set; }
    public string Name { get; set; }
    public string Category_Id { get; set; }
    public string User_Id { get; set; }
    public string Test_Score { get; set; }
    public ObservableCollection<Section> Sections { get; set; }
  }
}
