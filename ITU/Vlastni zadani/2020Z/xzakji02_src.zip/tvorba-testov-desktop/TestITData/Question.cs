﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel;

namespace TestITData
{
    public class Question
    {
        public enum QuestionType
            {
              [Description("S odpoveďou")]
              fulltext,
              [Description("Možnosti")]
              choice
            }

        public string Id { get; set; }
        public string Created_At { get; set; }
        public string Updated_At { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public QuestionType Type { get; set; }
        public string Text { get; set; }
        public string Answer_Text { get; set; }

        public string Is_Multichoice { get; set; }
        public string Attachment_Id {get; set; }
        public ObservableCollection<Option> Options { get; set; }


    }
}
