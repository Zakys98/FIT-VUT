﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestITData
{
    public class Option
    {
        //public Option(string id, string text, bool is_true, string question_id)
        //{
        //    Id = id;
        //    Text = text;
        //    Is_True = is_true;
        //    Question_Id = question_id;
        //}
        public string Id { get; set; }
        public string Created_At { get; set; }
        public string Updated_At { get; set; }
        public string Text { get; set; }
        public string Is_True { get; set; }
        public string Question_Id { get; set; }
    }
}
