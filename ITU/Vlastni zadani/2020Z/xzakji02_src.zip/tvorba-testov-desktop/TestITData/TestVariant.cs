﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace TestITData
{
    public class TestVariant
    {
        public TestVariant(string id, string name, string test_id)
        {
            Id = id;
            Name = name;
            Test_Id = test_id;
        }
        public string Id { get; set; }
        public string Created_At { get; set; }
        public string Updated_At { get; set; }
        public string Name { get; set; }
        public string For_Printing { get; set; }
        public string Checked { get; set; }
        public string Test_Id { get; set; }
        public string User_Id { get; set; }
        public string Test_History_Id { get; set; }
        public ObservableCollection<VariantQuestion> Variant_Questions { get; set; }
    }
}
