﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestIT.Commands
{
  /// <summary>
  ///     https://johnthiriet.com/mvvm-going-async-with-async-command/
  /// </summary>
  public interface IErrorHandler
  {
    void HandleError(Exception ex);
  }
}
