﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using TestIT.Commands;
using TestIT.Services;
using static TestIT.Services.PdfService;

namespace TestIT.ViewModels
{
    public class PdfPopupViewModel : NotifyPropertyChangeBase
    {
        private string _testId;
        private ObservableCollection<PopupElemViewModel> _popupElemViewModels;

        public PdfPopupViewModel(string testId)
        {
          _testId = testId; 
          _popupElemViewModels = new ObservableCollection<PopupElemViewModel>();
          GenerateVariantsCommand = new AsyncCommand<string>(async n => await GenerateVariantsAsync(n));
        }

        public ObservableCollection<PopupElemViewModel> PopupElements
        {
            get { return _popupElemViewModels; }
            set 
            { 
              _popupElemViewModels = value;
              OnPropertyChanged("PopupElements");
            }
        }

        async public void LoadVariants()
        {
            if (_testId != null)
            {
                VariantsListItem[] variantsList = await PdfService.GetVariantsList(_testId);
                _popupElemViewModels.Clear();
                foreach (var variant in variantsList)
                {
                    _popupElemViewModels.Add(new PopupElemViewModel(this, _testId, variant.Id, variant.Name));
                }
            }
        }

        //TODO BIND na view
        public ICommand GenerateVariantsCommand { get; }
        private async Task GenerateVariantsAsync(string n)
        {
            VariantsListItem[] itemlist = await PdfService.GenerateVariantsAsync(_testId, n);
            _popupElemViewModels.Clear();
            foreach (var variant in itemlist)
            {
              _popupElemViewModels.Add(new PopupElemViewModel(this, _testId, variant.Id, variant.Name));
            }
        }

    }
}
