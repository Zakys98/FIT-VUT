﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using TestITData;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Windows.Input;


namespace TestIT.ViewModels
{
  public class MenuItemViewModel : INotifyPropertyChanged
  {
    bool _isExpanded;
    bool _isSelected;
    bool _isEditMode;

    protected ObservableCollection<MenuItemViewModel> _children;
    protected MenuItemViewModel _supercategory;


    protected MenuItemViewModel(MenuItemViewModel supercategory, ObservableCollection<Category> subcategories, ObservableCollection<Test> tests)
    {
      _supercategory = supercategory;

      _children = new ObservableCollection<MenuItemViewModel>();

      if (subcategories != null)
        foreach (var sc in subcategories)
          _children.Add(new SubCategoryViewModel(sc, this));

      if (tests != null)
        foreach (var t in tests)
          _children.Add(new TestViewModel(t, this));

    }

    public ObservableCollection<MenuItemViewModel> Children
    {
      get { return _children; }
      set
      {
        if (value != _children)
        {
          _children = value;
          this.OnPropertyChanged("Children");
        }
      }
    }

    public bool IsExpanded
    {
      get { return _isExpanded; }
      set
      {
        if (value != _isExpanded)
        {
          _isExpanded = value;
          this.OnPropertyChanged("IsExpanded");
        }

        // Expand all the way up to the root.
        if (_isExpanded && _supercategory != null)
          _supercategory.IsExpanded = true;
      }
    }

    public bool IsSelected
    {
      get { return _isSelected; }
      set
      {
        if (value != _isSelected)
        {
          _isSelected = value;
          this.OnPropertyChanged("IsSelected");

          if (!_isSelected) IsEditMode = false;
        }
      }
    }

    public bool IsEditMode
    {
      get { return _isEditMode; }
      set
      {
        if (value != _isEditMode)
        {
          _isEditMode = value;
          this.OnPropertyChanged("IsEditMode");
        }
      }
    }


    public MenuItemViewModel SuperCategory
    {
      get { return _supercategory; }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
      if (this.PropertyChanged != null)
        this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
    }

  }
}
