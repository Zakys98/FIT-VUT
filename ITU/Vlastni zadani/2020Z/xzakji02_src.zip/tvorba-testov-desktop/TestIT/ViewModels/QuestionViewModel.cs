﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestITData;
using System.Windows.Input;
using System.ComponentModel;
using TestIT.Commands;
using TestIT.Services;
using System.Collections.ObjectModel;
using System.Windows.Forms;

namespace TestIT.ViewModels
{
  public class QuestionViewModel : NotifyPropertyChangeBase
  {
    private Question _question;
    private SectionViewModel _parentSection;
    private ObservableCollection<OptionViewModel> _optionViewModels;
    private bool _isFulltext;
    private bool _isChoice;
    private string _attachPath;

    public QuestionViewModel(Question question, SectionViewModel section) {
      _question = question;
      _parentSection = section;
      _optionViewModels = new ObservableCollection<OptionViewModel>();

      if (question.Type == Question.QuestionType.fulltext) _isFulltext = true;
      else _isChoice = true;

      if (question.Options != null)
        foreach (var o in question.Options)
          _optionViewModels.Add(new OptionViewModel(o, this));

      DeleteQuestionCommand = new AsyncCommand(DeleteSelfAsync);
      SaveCommand = new AsyncCommand(SaveAsync);
      AddOptionCommand = new AsyncCommand<string>(async text => await AddOptionAsync(text));
    }

    public IEnumerable<Question.QuestionType> QuestionTypes
    {
      get
      {
        return Enum.GetValues(typeof(Question.QuestionType)).Cast<Question.QuestionType>();
      }
    }

    public Question.QuestionType QuestionType
    {
      get { return _question.Type; }
      set
      {
        if (_question.Type != value)
        {
          _question.Type = value;
          if (_question.Type == Question.QuestionType.fulltext) IsFulltext = true;
          else IsFulltext = false;

          OnPropertyChanged("QuestionType");
        }
      }
    }

    public bool IsFulltext
    {
      get { return _isFulltext; }
      set
      {
        if (_isFulltext != value)
        {
          _isFulltext = value;
          IsChoice = (!_isFulltext);
          IsMultichoice = false;

          OnPropertyChanged("IsFullText");
        }
      }
    }
    public bool IsMultichoice
    {
      get { return (_question.Is_Multichoice == "true") ? true : false; }
      set
      {
        _question.Is_Multichoice = (value) ? "true" : "false";
        OnPropertyChanged("IsMultichoice");

      }
    }

    public bool IsChoice
    {
      get { return _isChoice; }
      set
      {
        if (_isChoice != value)
        {
          _isChoice = value;
          IsFulltext = (!_isChoice);

          OnPropertyChanged("IsChoice");
        }
      }
    }

    public ObservableCollection<OptionViewModel> Options
    {
      get { return _optionViewModels; }
      set { _optionViewModels = value; }
    }

    public string Id
    {
      get { return _question.Id; }
    }

    public string QuestionText {
      get { return _question.Text; }
      set { _question.Text = value; }
    }

    public string AnswerText {
      get { return _question.Answer_Text; }
      set 
      { 
        _question.Answer_Text = value;
        OnPropertyChanged("AnswerText");
      }
    }

    public ICommand DeleteQuestionCommand { get; }
    private async Task DeleteSelfAsync()
    {
      await TestService.DeleteQuestionAsync(_parentSection.TestId, _parentSection.Id, Id);
      _parentSection.Questions.Remove(this);
    }

    public ICommand SaveCommand { get; }
    private async Task SaveAsync()
    {
      if (QuestionType == Question.QuestionType.fulltext)
      {
        foreach (var o in Options) {
          await o.DeleteSelfAsync();
        } 
      }
      else
      {
        AnswerText = null;
        int trueCount = 0;
        if (Options != null)
          foreach (var o in Options)
            if (o.IsTrue)
              trueCount++;

        IsMultichoice = (trueCount > 1) ? true : false;

      }
      await TestService.UpdateQuestionAsync(_parentSection.TestId, _parentSection.Id, _question);
    }

    public ICommand AddOptionCommand { get; }
    private async Task AddOptionAsync(string text)
    {
      Option o = await TestService.AddOptionAsync(text, Id);
      Options.Add(new OptionViewModel(o, this));
    }

    public string AttachPath
    {
      get { return _attachPath; }
      set
      {
        _attachPath = value;
        OnPropertyChanged("AttachPath");
      }
    }

    public void AddAttach()
    {
      using (OpenFileDialog openFileDialog = new OpenFileDialog())
      {
        openFileDialog.InitialDirectory = @"C:\Documents";
        openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png";
        //openFileDialog.FilterIndex = 2;
        openFileDialog.RestoreDirectory = true;

        if (openFileDialog.ShowDialog() == DialogResult.OK)
        {
          //Get the path of specified file
          AttachPath = openFileDialog.FileName;
        }
      }
    }
  }
}
