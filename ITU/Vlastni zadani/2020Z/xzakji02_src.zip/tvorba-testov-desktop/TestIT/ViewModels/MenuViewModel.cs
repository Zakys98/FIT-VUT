﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestITData;
using System.Collections.ObjectModel;
using System.ComponentModel;
using TestIT.Services;
using System.Windows.Input;
using TestIT.Commands;
using System.Windows.Controls;

namespace TestIT.ViewModels
{
  class MenuViewModel
  {
    private ObservableCollection<CategoryViewModel> _categories;

    public MenuViewModel()
    {
      _categories = new ObservableCollection<CategoryViewModel>();
    }

    public event PropertyChangedEventHandler PropertyChanged = delegate { };
    public ObservableCollection<CategoryViewModel> Categories
    {
      get { return _categories; }
      set
      {
        if (value != _categories)
        {
          _categories = value;
          PropertyChanged(this, new PropertyChangedEventArgs("Categories"));
        }

      }
    }

    public async void LoadCategories()
    {
      await ApiHelper.GetCsrfAsync();
      Category[] categories = await CategoriesService.GetCategoriesAsync();
      foreach (var c in categories)
      {
        Categories.Add(new CategoryViewModel(c, Categories));
      }
    }
  }
}
