﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using TestIT.Commands;
using TestIT.Services;

namespace TestIT.ViewModels
{
    public class PopupElemViewModel : NotifyPropertyChangeBase
    {
        private string _testId;
        private string _variantId;
        private string _name;
        PdfPopupViewModel _parent;

        public PopupElemViewModel(PdfPopupViewModel parent, string testId, string variantId, string name)
        {
            _testId = testId;
            _variantId = variantId;
            _name = name;
            _parent = parent;

            VariantCommand = new AsyncCommand(VariantAsync);
            AnswersCommand = new AsyncCommand(AnswersAsync);
            DeleteVariantCommand = new AsyncCommand(DeleteVariantAsync);
        }

        public ICommand VariantCommand { get; }
        private async Task VariantAsync()
        {
            await PdfService.GeneratePdfAsync(_testId, _variantId, false);
        }

        public ICommand AnswersCommand { get; }
        private async Task AnswersAsync()
        {
            await PdfService.GeneratePdfAsync(_testId, _variantId, true);
        }

        public ICommand DeleteVariantCommand { get; }
        private async Task DeleteVariantAsync()
        {
            await PdfService.DeleteVariantAsync(_testId, _variantId);
            _parent.PopupElements.Remove(this);
        }

        public string Name
        {
          get { return _name; }
          set 
          { 
            _name = value;
            OnPropertyChanged("Name");
          }
        }
  }
}
