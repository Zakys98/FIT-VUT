﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestITData;
using TestIT.Services;
using System.Windows.Input;
using TestIT.Commands;
using System.Collections.ObjectModel;

namespace TestIT.ViewModels
{
  public class CategoryViewModel : MenuItemViewModel
  {
    private Category _category;
    private ObservableCollection<CategoryViewModel> _collection;

    public CategoryViewModel(Category category, ObservableCollection<CategoryViewModel> collection)
        : base(null, category.Subcategories, category.Tests)
    {
      _category = category;
      _collection = collection;
      AddSubcategoryCommand = new AsyncCommand(AddSubcategoryAsync);
      AddTestCommand = new AsyncCommand(AddTestAsync);
      DeleteCategoryCommand = new AsyncCommand(DeleteSelfAsync);
    }

    public string Name
    {
      get { return _category.Name; }
      set
      {
        _category.Name = value;
        this.OnPropertyChanged("Name");
      }
    }

    public ICommand AddSubcategoryCommand { get; }

    private async Task AddSubcategoryAsync ()
    {
      Category category = await CategoriesService.CreateCategoryAsync("NováKategória", _category.Id);
      var vm = new SubCategoryViewModel(category, this);
      Children.Add(vm);
      vm.IsSelected = true;
      vm.IsEditMode = true;
      vm.IsExpanded = true;
    }
    public ICommand AddTestCommand { get; }
    private async Task AddTestAsync()
    {
      Test test = await TestService.CreateTestAsync("NovýTest", _category.Id);
      var vm = new TestViewModel(test, this);
      vm.IsSelected = true;
      vm.IsExpanded = true;
      Children.Add(vm);
    }
    public ICommand DeleteCategoryCommand { get; }
    private async Task DeleteSelfAsync()
    {
      await CategoriesService.DeleteCategoryAsync(this._category.Id);
      _collection.Remove(this);
    }


    protected override async void OnPropertyChanged(string propertyName)
    {
      base.OnPropertyChanged(propertyName);
      if (propertyName == "IsEditMode" && !IsEditMode)
      {
        await CategoriesService.UpdateCategoryAsync(this._category);
      }
    }

  }
}
