﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestIT.Commands;
using TestIT.Services;
using TestITData;
using System.Windows.Input;

namespace TestIT.ViewModels
{
  public class OptionViewModel : NotifyPropertyChangeBase
  {
    private Option _option;
    private QuestionViewModel _parentQuestion;
    public OptionViewModel(Option option, QuestionViewModel question)
    {
      _option = option;
      _parentQuestion = question;

      DeleteOptionCommand = new AsyncCommand(DeleteSelfAsync);
      UpdateOptionCommand = new AsyncCommand(UpdateOptionAsync);
    }

    public string Text
    {
      get { return _option.Text; }
      set
      {
        if (_option.Text != value)
        {
          _option.Text = value;
          OnPropertyChanged("Text");
        }
      }
    }

    public bool IsTrue
    {
      get { return (_option.Is_True == "true") ? true : false; }
      set
      {
          _option.Is_True = (value) ? "true" : "false";
          OnPropertyChanged("IsTrue");
      }
    }

    public string Id
    {
      get { return _option.Id; }
    }

    public ICommand DeleteOptionCommand { get; }
    public async Task DeleteSelfAsync()
    {
      await TestService.DeleteOptionAsync(_parentQuestion.Id, Id);
      _parentQuestion.Options.Remove(this);
    }

    public ICommand UpdateOptionCommand { get; }
    private async Task UpdateOptionAsync()
    {
      await TestService.UpdateOptionAsync(_parentQuestion.Id, this._option);
    }
  }
}
