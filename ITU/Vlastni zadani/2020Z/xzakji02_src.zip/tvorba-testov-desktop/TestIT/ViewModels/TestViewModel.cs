﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestITData;
using TestIT.Services;
using System.Collections.ObjectModel;
using TestIT.Commands;
using System.Windows.Input;
using Newtonsoft.Json;
using TestIT.Views;

namespace TestIT.ViewModels
{
  public class TestViewModel : MenuItemViewModel
  {
    private Test _test;
    private Test _testContent;
    private ObservableCollection<SectionViewModel> _sectionViewModels;
    private PdfPopupViewModel _pdfPopup;

    public TestViewModel(Test test, MenuItemViewModel superCategory)
        : base(superCategory, null, null)
    {
        _test = test;
        _sectionViewModels = new ObservableCollection<SectionViewModel>();
        _pdfPopup = new PdfPopupViewModel(test.Id);

        DeleteTestCommand = new AsyncCommand(DeleteSelfAsync);
        AddSectionCommand = new AsyncCommand<string>(async name => await AddSectionAsync(name));
        UpdateTestNameCommand = new AsyncCommand(UpdateTestAsync);
        GetTestContent();
    }

    public PdfPopupViewModel Popup 
    { 
      get { return _pdfPopup; }
      set { _pdfPopup = value; }
    }

    public string Name
    {
      get { return _test.Name; }
      set
      {
        if (_test.Name != value)
        {
          _test.Name = value;
          this.OnPropertyChanged("Name");
        }
      }
    }

    public ObservableCollection<SectionViewModel> Sections
    {
      get { return _sectionViewModels; }
      set 
      {
        if (_sectionViewModels != value)
        {
          _sectionViewModels = value;
          this.OnPropertyChanged("Sections");
        }
         
      }
    }

    public string Id
    {
      get { return _test.Id; }
    }

    public ICommand DeleteTestCommand { get; }
    private async Task DeleteSelfAsync()
    {
      await TestService.DeleteTestAsync(this._test.Id);
      SuperCategory.Children.Remove(this);
    }

    public ICommand AddSectionCommand { get; }
    private async Task AddSectionAsync(string name)
    {
      Section s = await TestService.AddSectionAsync(this._test.Id, name);
      Sections.Add(new SectionViewModel(s, this));
    }

    public ICommand UpdateTestNameCommand { get; }
    private async Task UpdateTestAsync()
    {
      await TestService.UpdateTestNameAsync(this._test.Category_Id, Id, Name);
    }

    private async Task GetTestContent()
    {
        _testContent = await TestService.GetTestAsync(_test.Id);

        foreach (var s in _testContent.Sections)
        {
            _sectionViewModels.Add(new SectionViewModel(s, this));
        }
    }
  }
}
