﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestITData;
using TestIT.Commands;
using System.Windows.Input;
using TestIT.Services;

namespace TestIT.ViewModels
{
  public class SubCategoryViewModel : MenuItemViewModel
  {
    readonly Category _category;

    public SubCategoryViewModel(Category category, MenuItemViewModel superCategory)
        : base(superCategory, category.Subcategories, category.Tests)
    {
      _category = category;
      AddSubcategoryCommand = new AsyncCommand(AddSubcategoryAsync);
      AddTestCommand = new AsyncCommand(AddTestAsync);
      DeleteCategoryCommand = new AsyncCommand(DeleteSelfAsync);
    }

    public string Name
    {
      get { return _category.Name; }
      set
      {
        _category.Name = value;
        this.OnPropertyChanged("Name");
      }
    }

    public ICommand AddSubcategoryCommand { get; }

    private async Task AddSubcategoryAsync()
    {
      Category category = await CategoriesService.CreateCategoryAsync("NováKategória", _category.Id);
      var vm = new SubCategoryViewModel(category, this);
      Children.Add(vm);
      vm.IsSelected = true;
      vm.IsEditMode = true;
      vm.IsExpanded = true;
    }

    public ICommand AddTestCommand { get; }
    private async Task AddTestAsync()
    {
      Test test = await TestService.CreateTestAsync("NovýTest", _category.Id);
      var vm = new TestViewModel(test, this);
      Children.Add(vm);
      vm.IsSelected = true;
      vm.IsExpanded = true;
    }
    public ICommand DeleteCategoryCommand { get; }
    private async Task DeleteSelfAsync()
    {
      await CategoriesService.DeleteCategoryAsync(this._category.Id);
      SuperCategory.Children.Remove(this);
    }

    protected override async void OnPropertyChanged(string propertyName)
    {
      base.OnPropertyChanged(propertyName);
      if (propertyName == "IsEditMode" && !IsEditMode)
      {
        await RenameAsync();
      }
    }

    private async Task RenameAsync()
    {
      await CategoriesService.UpdateCategoryAsync(this._category);
    }
  }
}
