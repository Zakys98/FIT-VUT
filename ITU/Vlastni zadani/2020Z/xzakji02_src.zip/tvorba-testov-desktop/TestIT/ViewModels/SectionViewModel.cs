﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestITData;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Newtonsoft.Json;
using System.ComponentModel;
using TestIT.Commands;
using TestIT.Services;

namespace TestIT.ViewModels
{
  public class SectionViewModel : NotifyPropertyChangeBase
  {
    private Section _section;
    private ObservableCollection<QuestionViewModel> _questionViewModels;
    private TestViewModel _parentTest;

    public SectionViewModel(Section section, TestViewModel test)
    {
        _section = section;
        _parentTest = test;
        _questionViewModels = new ObservableCollection<QuestionViewModel>();
        if (section.Questions != null) { 
          foreach (var q in section.Questions)
          {
              _questionViewModels.Add(new QuestionViewModel(q, this));
          }
        }

        DeleteSectionCommand = new AsyncCommand(DeleteSelfAsync);
        AddQuestionCommand = new AsyncCommand<string>(async name => await AddQuestionAsync(name));
    }

    public string SectionName
    {
      get { return _section.Name; }
      set
      {
        if (_section.Name != value)
        {
          _section.Name = value;
          OnPropertyChanged("SectionName");
        }
      }
    }

    public string Id
    {
      get { return _section.Id; }
    }

    public string TestId
    {
      get { return _parentTest.Id; }
    }

    public ObservableCollection<QuestionViewModel> Questions
    {
        get { return _questionViewModels; }
        set { _questionViewModels = value; }
    }

    public ICommand DeleteSectionCommand { get; }
    private async Task DeleteSelfAsync()
    {
      await TestService.DeleteSectionAsync(TestId, Id);
      _parentTest.Sections.Remove(this);
    }

    public ICommand AddQuestionCommand { get; }
    private async Task AddQuestionAsync(string name)
    {
      Question q = await TestService.AddQuestionAsync(TestId, Id, name);
      Questions.Add(new QuestionViewModel(q, this));
    }

    protected override async void OnPropertyChanged(string propertyName)
    {
      base.OnPropertyChanged(propertyName);
      if (propertyName == "SectionName")
      {
        await TestService.UpdateSectionNameAsync(TestId, Id, SectionName);
      }
    }
  }
}
