﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TestIT.ViewModels;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace TestIT.Views
{
  /// <summary>
  /// Interaction logic for MenuView.xaml
  /// </summary>
  public partial class MenuView : UserControl
  {
    public MainWindow mainWindow;
    public MenuView()
    {
      InitializeComponent();
      mainWindow = (MainWindow)Application.Current.MainWindow;
    }

    private void MenuTreeView_SelectionChanged(object sender, RoutedPropertyChangedEventArgs<Object> e)
    {
      MenuItemViewModel item = (MenuItemViewModel)(((TreeView)sender).SelectedItem);

      item.IsEditMode = false;
      if (item is TestViewModel)
      {
        mainWindow.Test.DataContext = item;
      }
      else mainWindow.Test.DataContext = null;
    }
  }
}
