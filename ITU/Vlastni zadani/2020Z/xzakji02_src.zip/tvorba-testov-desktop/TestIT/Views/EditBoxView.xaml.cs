﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TestIT.ViewModels;

namespace TestIT.Views
{
  /// <summary>
  /// Interaction logic for EditBoxView.xaml
  /// </summary>
  public partial class EditBoxView : UserControl
  {
    public EditBoxView()
    {
      InitializeComponent();
    }

    private void normal_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      //MenuItemViewModel item = (MenuItemViewModel)(sender.DataContext);
      MenuItemViewModel item = (MenuItemViewModel)(((TextBlock)e.OriginalSource).DataContext);
      if (item.IsSelected)
        item.IsEditMode = true;
    }

    private void editable_KeyDown(object sender, KeyEventArgs e)
    {
      if (e.Key == Key.Enter)
      {
        MenuItemViewModel item = (MenuItemViewModel)(((TextBox)e.OriginalSource).DataContext);
        item.IsEditMode = false;
      }
    }

    private void editable_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
    {}

    private void editable_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
    {
      var item = Keyboard.FocusedElement;
    }
  }
}
