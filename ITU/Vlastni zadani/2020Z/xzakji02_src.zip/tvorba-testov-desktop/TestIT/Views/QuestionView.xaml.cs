﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using TestIT.ViewModels;

namespace TestIT.Views
{
  /// <summary>
  /// Interaction logic for Question.xaml
  /// </summary>
  public partial class QuestionView : UserControl
  {
    public QuestionView()
    {
      InitializeComponent();
    }

    private void TextBox_KeyDown(object sender, KeyEventArgs e)
    {
      if (e.Key == Key.Enter)
      {
        var box = (TextBox)sender;
        BindingExpression be = box.GetBindingExpression(TextBox.TextProperty);
        be.UpdateSource();
      }
    }

    private void TextBox_LostFocus(object sender, RoutedEventArgs e)
    {
      var box = (TextBox)sender;
      BindingExpression be = box.GetBindingExpression(TextBox.TextProperty);
      be.UpdateSource();
    }

    
    private void NewOptionTextBox_KeyDown(object sender, KeyEventArgs e)
    {
      if (e.Key == Key.Enter)
        (sender as TextBox).Text = string.Empty;
    }

    private void AddAttach_Click(object sender, RoutedEventArgs e)
    {
      ((QuestionViewModel)DataContext).AddAttach();
    }
  }
}
