﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestIT.Services;
using TestIT.ViewModels;

namespace TestIT
{
  public class MainWindowViewModel
  {
    public MainWindowViewModel()
    {
      CategoryLabel = "Kategórie";
    }

    public string CategoryLabel { get; set; }
    public string AppLabel { get; set; }
  }
}
