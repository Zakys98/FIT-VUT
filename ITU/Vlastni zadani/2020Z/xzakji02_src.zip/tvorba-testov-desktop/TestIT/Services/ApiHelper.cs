﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace TestIT.Services
{
  public class ApiHelper
  {
    public static HttpClient ApiClient { get; set; }
    private static string AccessToken { get; set; }

    private static CsrfToken Token { get; set; }

    public static void InitializeClient()
    {
      //AccessToken of prof1
      AccessToken = "wMEQs0um5Phk3DFdoSj0DDxgHuQwENwiWloZ59Ut";
      
      ApiClient = new HttpClient();
      ApiClient.BaseAddress = new Uri("https://itu-testit.herokuapp.com/");
      ApiClient.DefaultRequestHeaders.Accept.Clear();
      ApiClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      
      ApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AccessToken);

    }

    public static async Task GetCsrfAsync()
    {
      HttpResponseMessage response = await ApiHelper.ApiClient.GetAsync("csrf");
      response.EnsureSuccessStatusCode();
      Token = await response.Content.ReadAsAsync<CsrfToken>();
      ApiClient.DefaultRequestHeaders.Add("X-CSRF-TOKEN", Token.Token);
    }
  }
}
