﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestIT.Services
{
  public class CsrfToken
  {
    public string Token { get; set; }
  }
}
