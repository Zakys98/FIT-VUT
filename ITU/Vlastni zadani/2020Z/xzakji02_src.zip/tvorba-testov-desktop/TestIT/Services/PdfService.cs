﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestITData;
using System.Net.Http;
using System.Collections.ObjectModel;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Kernel;
using iText.Kernel.Geom;
using iText.Layout.Element;
using iText.Layout.Properties;
using System.Windows.Forms;
using iText.Kernel.Font;
using iText.IO.Font.Constants;
using static TestITData.Question;

namespace TestIT.Services
{
    class PdfService
    {
        public class VariantsListItem
        {
            public VariantsListItem(string id, string name)
            {
                Id = id;
                Name = name;
            }
            public string Id { get; set; }
            public string Name { get; set; }
        }

        public static async Task<TestVariant> GetVariantAsync(string testId, string variantId)
        {
            TestVariant testVariant = null;
            HttpResponseMessage response = await ApiHelper.ApiClient.GetAsync("tests/" + testId + "/testVariants/" + variantId);
            if (response.IsSuccessStatusCode)
            {
                String s = await response.Content.ReadAsStringAsync();
                testVariant = await response.Content.ReadAsAsync<TestVariant>();
            }
            return testVariant;
        }

        public static async Task<VariantsListItem[]> GenerateVariantsAsync(string testId, string nVariants)
        {
            VariantsListItem[] variantsList = null;
            var numberJson = new
            {
                number = nVariants,
            };
            HttpResponseMessage response = await ApiHelper.ApiClient.PostAsJsonAsync(
             "tests/" + testId + "/testVariants", numberJson);
            response.EnsureSuccessStatusCode();

            variantsList = await response.Content.ReadAsAsync<VariantsListItem[]>();

            return variantsList;
        }

        public static async Task<VariantsListItem[]> GetVariantsList(string testId)
        {
            VariantsListItem[] variantsList = null;
            HttpResponseMessage response = await ApiHelper.ApiClient.GetAsync("tests/" + testId + "/testVariants");
            if (response.IsSuccessStatusCode)
            {
                variantsList = await response.Content.ReadAsAsync<VariantsListItem[]>();
            }
            return variantsList;
        }

        public static async Task DeleteVariantAsync(string testId, string variantId)
        {
            HttpResponseMessage response = await ApiHelper.ApiClient.DeleteAsync("tests/" + testId + "/testVariants/" + variantId);
            response.EnsureSuccessStatusCode();
        }

        public static async Task GeneratePdfAsync(string testId, string variantId, bool isAnswerSheet)
        {
            SaveFileDialog locDialog = new SaveFileDialog();
            locDialog.InitialDirectory = @"C:\";      
            locDialog.Title = "Save Pdf File";
            //locDialog.CheckFileExists = true;
            locDialog.CheckPathExists = true;
            locDialog.DefaultExt = "pdf";
            locDialog.Filter = "PDF document (*.pdf)|*.pdf";
            locDialog.FilterIndex = 0;
            locDialog.RestoreDirectory = true;
            if (locDialog.ShowDialog() != DialogResult.OK)
                return;

            TestVariant testVariant = await GetVariantAsync(testId, variantId);
            PdfDocument pdf = new PdfDocument(new PdfWriter(locDialog.FileName));
            Document doc = new Document(pdf, PageSize.A4);
            PdfDocumentInfo info = pdf.GetDocumentInfo();
            info.SetTitle(testVariant.Name);

            PdfFont qstTitle = PdfFontFactory.CreateFont(StandardFonts.TIMES_BOLD);
            PdfFont qstBody = PdfFontFactory.CreateFont(StandardFonts.TIMES_ROMAN);

            if (isAnswerSheet) //TODO, ANSWER SHEET in pdf
            {
                Paragraph title = new Paragraph("Odpovede pre opravu (" + testVariant.Name + ")")
                        .SetFontSize(20f).SetTextAlignment(TextAlignment.CENTER);
                title.GetAccessibilityProperties().SetRole(iText.Kernel.Pdf.Tagging.StandardRoles.H1);
                doc.Add(title);

                Table table = new Table(4).UseAllAvailableWidth();
                Cell h1 = new Cell().SetTextAlignment(TextAlignment.CENTER)
                    .Add(new Paragraph("Otázka").SetFont(PdfFontFactory.CreateFont(StandardFonts.TIMES_BOLD)));
                Cell h2 = new Cell().SetTextAlignment(TextAlignment.CENTER)
                    .Add(new Paragraph("Typ").SetFont(PdfFontFactory.CreateFont(StandardFonts.TIMES_BOLD)));
                Cell h3 = new Cell().SetTextAlignment(TextAlignment.CENTER)
                    .Add(new Paragraph("Body").SetFont(PdfFontFactory.CreateFont(StandardFonts.TIMES_BOLD)));
                Cell h4 = new Cell().SetTextAlignment(TextAlignment.CENTER)
                    .Add(new Paragraph("Správne odpovede").SetFont(PdfFontFactory.CreateFont(StandardFonts.TIMES_BOLD)));
                table.AddCell(h1);
                table.AddCell(h2);
                table.AddCell(h3);
                table.AddCell(h4);
                //.SetVerticalAlignment(VerticalAlignment.MIDDLE)

                foreach (VariantQuestion varQuest in testVariant.Variant_Questions)
                {
                    Question qst = varQuest.Question;
                    table.AddCell(new Cell().SetTextAlignment(TextAlignment.CENTER).Add(new Paragraph(varQuest.Number)));
                    if (qst.Type == QuestionType.choice)
                        table.AddCell(new Cell().SetTextAlignment(TextAlignment.CENTER).Add(new Paragraph("výber")));
                    else
                        table.AddCell(new Cell().SetTextAlignment(TextAlignment.CENTER).Add(new Paragraph("fulltext")));
                    table.AddCell(new Cell().SetTextAlignment(TextAlignment.CENTER).Add(new Paragraph(varQuest.Max_Score)));
                    if (qst.Options.Count > 0)
                    {
                        List<string> tmp = new List<string>();
                        char c = 'A';
                        foreach (Option option in qst.Options)
                        {
                            if (option.Is_True == "true")
                                tmp.Add(c.ToString());
                            c++;
                        }
                        table.AddCell(new Cell().SetTextAlignment(TextAlignment.CENTER).Add(new Paragraph(string.Join(",", tmp))));
                    }
                    else
                        table.AddCell(new Cell().SetTextAlignment(TextAlignment.CENTER).Add(new Paragraph(varQuest.Question.Answer_Text)));

                }
                doc.Add(table);
            }
            else // CONCRETE TEST VARIANT in pdf
            {
                Paragraph title = new Paragraph(testVariant.Name)
                        .SetFontSize(20f).SetTextAlignment(TextAlignment.CENTER);
                title.GetAccessibilityProperties().SetRole(iText.Kernel.Pdf.Tagging.StandardRoles.H1);
                doc.Add(title);

                foreach (VariantQuestion varQuest in testVariant.Variant_Questions)
                {
                    Question qst = varQuest.Question;
                    Paragraph qstName = new Paragraph(varQuest.Number + ". " + qst.Text + " (" + varQuest.Max_Score + "b)")
                        .SetFont(qstTitle)
                        .SetFontSize(14)
                        .SetMarginTop(15);

                    doc.Add(qstName);

                    if (qst.Options.Count > 0)
                    {
                        string tmp = "";
                        char c = 'A';
                        foreach (Option option in qst.Options)
                        {
                            tmp += c + ") " + option.Text + "\n";
                            c++;
                        }
                        Paragraph choices = new Paragraph(tmp)
                            .SetFont(qstBody)
                            .SetFontSize(12);
                        doc.Add(choices);
                    }
                    else
                        doc.Add(new Paragraph("\n\n\n"));
                }
            }
            doc.Close();
        }
    }
}
