﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestITData;
using System.Net;
using System.Net.Http;
using System.Collections.ObjectModel;
using System.Web.Script.Serialization;
using System.Windows.Forms;


namespace TestIT.Services
{
  class TestService
  {
    #region Test
      public static async Task<Test> CreateTestAsync(string testName, string category)
      {
        var test = new
        {
          name = testName,
          category_id = category
        };
        HttpResponseMessage response = await ApiHelper.ApiClient.PostAsJsonAsync(
            "tests", test);
        response.EnsureSuccessStatusCode();

        return await response.Content.ReadAsAsync<Test>();
      }

      public static async Task<Test> GetTestAsync(string testId)
      {
        Test test = null;
        HttpResponseMessage response = await ApiHelper.ApiClient.GetAsync("tests/" + testId);
        if (response.IsSuccessStatusCode)
        {
          String s = await response.Content.ReadAsStringAsync();
          test = await response.Content.ReadAsAsync<Test>();
        }
        return test;
      }

      public static async Task UpdateTestNameAsync(string categoryId, string testId, string testName)
      {
        var test = new
        {
          category_id = categoryId,
          name = testName
        };
        HttpResponseMessage response = await ApiHelper.ApiClient.PutAsJsonAsync(
            "tests/" + testId, test);
        response.EnsureSuccessStatusCode();
      }

      public static async Task DeleteTestAsync(string id)
      {
        HttpResponseMessage response = await ApiHelper.ApiClient.DeleteAsync("tests/" + id);
        response.EnsureSuccessStatusCode();
      }

      #endregion

    #region Section

    public static async Task<Section> AddSectionAsync(string testId, string sectionName)
    {
      var section = new
      {
        name = sectionName
      };
      HttpResponseMessage response = await ApiHelper.ApiClient.PostAsJsonAsync("tests/" + testId + "/sections", section);
      response.EnsureSuccessStatusCode();

      return await response.Content.ReadAsAsync<Section>();
    }

    public static async Task DeleteSectionAsync(string testId, string sectionId)
    {
      HttpResponseMessage response = await ApiHelper.ApiClient.DeleteAsync(
        "tests/" + testId + "/sections/" + sectionId );
      response.EnsureSuccessStatusCode();
    }
    
    public static async Task UpdateSectionNameAsync(string testId, string sectionId, string sectionName)
    {
      var section = new
      {
        name = sectionName
      };
      HttpResponseMessage response = await ApiHelper.ApiClient.PutAsJsonAsync(
          "tests/" + testId + "/sections/" + sectionId, section);
      response.EnsureSuccessStatusCode();
    }
    #endregion

    #region Question
    public static async Task<Question> AddQuestionAsync(string testId, string sectionId, string qName)
    {
      
      var question = new
      {
        type = "fulltext",
        text = qName,
        is_multichoice = 0,
        answer_text = (string)null,
        attachment_id = (string)null
      };
      HttpResponseMessage response = await ApiHelper.ApiClient.PostAsJsonAsync(
        "tests/" + testId + "/sections/" + sectionId + "/questions", question);
      response.EnsureSuccessStatusCode();

      return await response.Content.ReadAsAsync<Question>();
    }

    public static async Task UpdateQuestionAsync(string testId, string sectionId, Question q)
    {
      var question = new {
        text = q.Text,
        type = (q.Type == Question.QuestionType.fulltext) ? "fulltext" : "choice",
        answer_text = q.Answer_Text,
        is_multichoice = (q.Is_Multichoice == "true") ? 1 : 0
      };
      HttpResponseMessage response = await ApiHelper.ApiClient.PutAsJsonAsync(
        "tests/" + testId + "/sections/" + sectionId + "/questions/" + q.Id, question);
      response.EnsureSuccessStatusCode();
    }

    public static async Task DeleteQuestionAsync(string testId, string sectionId, string questionId)
    {
      HttpResponseMessage response = await ApiHelper.ApiClient.DeleteAsync(
        "tests/" + testId + "/sections/" + sectionId + "/questions/" + questionId);
      response.EnsureSuccessStatusCode();
    }
    #endregion

    #region Option
    public static async Task<Option> AddOptionAsync(string optionText, string qId)
    {
      var option = new
      {
        text = optionText,
        is_true = 0,
        question_id = qId
      };
      HttpResponseMessage response = await ApiHelper.ApiClient.PostAsJsonAsync(
        "options", option);
      response.EnsureSuccessStatusCode();

      return await response.Content.ReadAsAsync<Option>();
    }

    public static async Task UpdateOptionAsync(string qId, Option o)
    {
      var option = new
      {
        text = o.Text,
        is_true = o.Is_True,
        question_id = qId
      };
      HttpResponseMessage response = await ApiHelper.ApiClient.PutAsJsonAsync(
        "options/" + o.Id, option);
      response.EnsureSuccessStatusCode();
    }

    public static async Task DeleteOptionAsync(string questionId, string optionId)
    {
      HttpResponseMessage response = await ApiHelper.ApiClient.DeleteAsync(
        "options/" + optionId);
      response.EnsureSuccessStatusCode();
    }

    #endregion
  }
}
