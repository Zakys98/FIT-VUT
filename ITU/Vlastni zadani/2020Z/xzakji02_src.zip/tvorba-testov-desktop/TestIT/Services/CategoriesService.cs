﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestITData;
using System.Net.Http;
using System.Collections.ObjectModel;

namespace TestIT.Services
{
  class CategoriesService
  {
    public static async Task<Category[]> GetCategoriesAsync()
    {
      Category[] categories = null;
      HttpResponseMessage response = await ApiHelper.ApiClient.GetAsync("categories");
      if (response.IsSuccessStatusCode)
      {
        categories = await response.Content.ReadAsAsync<Category[]>();
      }
      return categories;
    }
    public static async Task<Category> CreateCategoryAsync(string newName, string supercategory)
    {
      var category = new
      {
        name = newName,
        supercategory_id = supercategory
      };

      HttpResponseMessage response = await ApiHelper.ApiClient.PostAsJsonAsync(
          "categories", category);
      response.EnsureSuccessStatusCode();
      
      return await response.Content.ReadAsAsync<Category>();
    }
    public static async Task DeleteCategoryAsync(string id)
    {
      HttpResponseMessage response = await ApiHelper.ApiClient.DeleteAsync("categories/" + id);
      response.EnsureSuccessStatusCode();
    }

    public static async Task UpdateCategoryAsync(Category c)
    {
      var category = new
      {
        name = c.Name,
        supercategory_id = c.Supercategory_Id
      };
      HttpResponseMessage response = await ApiHelper.ApiClient.PutAsJsonAsync(
          "categories/" + c.Id, category);
      response.EnsureSuccessStatusCode();

    }
  }
}
