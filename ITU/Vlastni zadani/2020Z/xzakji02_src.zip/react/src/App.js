import React, { useState, useEffect } from 'react';

import TheNavigation from './components/TheNavigation'
import CreateTest from './components/CreateTest'
import Service from './services/Service'

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faAngleRight } from '@fortawesome/free-solid-svg-icons'

import './index.scss'

function App() {

  const [categories, setCategories] = useState([])
  const [selectedAddCategoryId, setSelectedAddCategoryId] = useState()
  const [selectedAddSubCategoryId, setSelectedAddSubCategoryId] = useState()

  const [selectedTestId, setSelectedTestId] = useState()

  useEffect(() => {
    retrieveCategories()
  }, [])

  const retrieveCategories = () => {
    Service.getAllCategories()
      .then(response => {
        setCategories(response.data)
      })
      .catch(e => {
        console.log(e)
      })
  }

  const unHideMenu = () => {
        document.getElementsByClassName("test_nav_container")[0].classList.toggle("test_nav_container_hide");
        document.getElementsByClassName("nav_mobile_button")[0].classList.toggle("nav_mobile_button_hide");
    }

  return (
    <>
      <div className="test_nav_container">
        <TheNavigation
          categories={categories}
          setCategories={setCategories}
          selectedAddCategoryId={selectedAddCategoryId}
          setSelectedAddCategoryId={setSelectedAddCategoryId}
          selectedAddSubCategoryId={selectedAddSubCategoryId}
          setSelectedAddSubCategoryId={setSelectedAddSubCategoryId}
          setSelectedTestId={setSelectedTestId}
        />
      </div>

      <div className="nav_mobile_button bg-blue-500" onClick={() => unHideMenu()}>
        <FontAwesomeIcon icon={faAngleRight} size="2x" />
      </div>

      {selectedTestId !== undefined && (
        <CreateTest selectedTestId={selectedTestId} setSelectedTestId={setSelectedTestId} updateMenu={retrieveCategories} />
      )}
    </>
  );
}

export default App;
