import http from "../http-common"

const getAllCategories = () => {
    return http.get("/categories")
}

const getTest = id => {
    return http.get(`/tests/${id}`)
}

const getAllVariants = id => {
    return http.get(`/tests/${id}/testVariants`)
}

const getVariant = (testId, variantId) => {
    return http.get(`/tests/${testId}/testVariants/${variantId}`)
}

const getAllAttachments = () => {
    return http.get("/attachments")
}

const Service = {
    getAllCategories,
    getTest,
    getAllVariants,
    getVariant,
    getAllAttachments
}

export default Service;