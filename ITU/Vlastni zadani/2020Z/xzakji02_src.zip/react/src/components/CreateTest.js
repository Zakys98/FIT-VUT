import React, { useState, useEffect, useRef } from 'react'
import Popup from 'reactjs-popup'
import pdfMake from 'pdfmake/build/pdfmake'
import pdfFonts from 'pdfmake/build/vfs_fonts'

import './scss-components/CreateTest.scss'

import Section from './Section'
import Service from '../services/Service'
import { API_URL } from '../config'

export const SetTest = React.createContext()

export default function CreateTest(props) {

    const { selectedTestId, setSelectedTestId, updateMenu } = props
    const [test, setTest] = useState()
    const sectionName = useRef()
    const [variants, setVariants] = useState()
    const numberOfVariants = useRef()
    pdfMake.vfs = pdfFonts.pdfMake.vfs

    const getTest = id => {
        Service.getTest(id)
            .then(response => {
                setTest(response.data)
            })
            .catch(e => {
                console.log(e)
            })
    }

    const getVariants = id => {
        Service.getAllVariants(id)
            .then(response => {
                setVariants(response.data)
            })
            .catch(e => {
                console.log(e)
            })
    }

    useEffect(() => {
        getTest(selectedTestId)
        getVariants(selectedTestId)
    }, [selectedTestId])

    const handleNewSection = () => {
        let secName = sectionName.current?.value
        if (secName) {
            const newSection = {
                name: secName
            }
            fetch(`${API_URL}/csrf`,
                {
                    credentials: 'include'
                })
                .then(r => r.json())
                .then(d => {
                    fetch(`${API_URL}/tests/${selectedTestId}/sections`,
                        {
                            credentials: 'include',
                            SameSite: "none",
                            method: "POST",
                            headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                            body: JSON.stringify(newSection)
                        }).then(r => {
                            getTest(selectedTestId)
                            sectionName.current.value = ""
                        })
                })
        }
    }

    const handleUpdateTestName = str => {
        setTest(currTest => {
            return { ...currTest, name: str }
        })
    }

    const handleSendUpdatedTest = () => {
        const newTestName = {
            name: test.name,
        }
        fetch(`${API_URL}/csrf`,
            {
                credentials: 'include'
            })
            .then(r => r.json())
            .then(d => {
                fetch(`${API_URL}/tests/${selectedTestId}`,
                    {
                        credentials: 'include',
                        SameSite: "none",
                        method: "PUT",
                        headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                        body: JSON.stringify(newTestName)
                    }).then(r => {
                        getTest(selectedTestId)
                        updateMenu()
                    })
            })
    }

    const handleDeleteTest = () => {
        fetch(`${API_URL}/csrf`,
            {
                credentials: 'include'
            })
            .then(r => r.json())
            .then(d => {
                fetch(`${API_URL}/tests/${selectedTestId}`,
                    {
                        credentials: 'include',
                        SameSite: "none",
                        method: "DELETE",
                        headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                    }).then(r => {
                        setSelectedTestId(undefined)
                        updateMenu()
                    })
            })
    }

    const sendTestToDatabase = () => {
        handleSendUpdatedTest()
    }

    const handleGenerateVariants = () => {
        let numberOfVar = numberOfVariants.current?.value
        if (numberOfVar) {
            const newVariants = {
                number: parseInt(numberOfVar),
            }
            fetch(`${API_URL}/csrf`,
                {
                    credentials: 'include'
                })
                .then(r => r.json())
                .then(d => {
                    fetch(`${API_URL}/tests/${selectedTestId}/testVariants`,
                        {
                            credentials: 'include',
                            SameSite: "none",
                            method: "POST",
                            headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                            body: JSON.stringify(newVariants)
                        }).then(r => {
                            getVariants(selectedTestId)
                            numberOfVariants.current.value = ""
                        })
                })
        }
    }

    const generateQuestions = data => {
        return data.variant_questions.map(varQuest => {
            if (varQuest.question.type === "choice") {
                const alphabet = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
                let tmp = 0
                return {
                    stack: [varQuest.question.text, [varQuest.question.options.map(opt => {
                        return { text: alphabet[tmp++] +") " + opt.text, margin:[15, 3, 0, 0], style: { fontSize: 10 } }
                    })]],
                    margin: [0, 5, 0, 5],
                    style: {
                        fontSize: 15
                    }
                }
            } else {
                return {
                    stack: [varQuest.question.text],
                    margin: [0, 10, 0, 50],
                    style: {
                        fontSize: 15
                    }
                }
            }
        })
    }

    const handleGeneratePdf = id => {
        Service.getVariant(selectedTestId, id)
            .then(response => {
                var doc = {
                    content: [
                        {
                            text: response.data.name,
                            style: 'header'
                        },
                        generateQuestions(response.data)
                    ],
                    styles: {
                        header: {
                            fontSize: 21,
                            bold: true
                        }
                    }
                }
                pdfMake.createPdf(doc).download()
            })
            .catch(e => {
                console.log(e)
            })
    }

    const handleDeleteVariant = id => {
        fetch(`${API_URL}/csrf`,
            {
                credentials: 'include'
            })
            .then(r => r.json())
            .then(d => {
                fetch(`${API_URL}/tests/${selectedTestId}/testVariants/${id}`,
                    {
                        credentials: 'include',
                        SameSite: "none",
                        method: "DELETE",
                        headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                    }).then(r => {
                        getVariants(selectedTestId)
                    })
            })
    }

    return (
        <SetTest.Provider value={setTest} >
            <div className="test" >
                {test && (
                    <div>
                        <div className="test-header items-center justify-between">
                            <input className="default-border p-2" type="text" value={test.name} onChange={(event) => handleUpdateTestName(event.target.value)} />
                            <div>
                                <Popup
                                    trigger={<button className="bg-white hover:bg-gray-100 text-gray-800 font-semibold py-2 px-4 border border-gray-400 rounded mr-2">Vygenerovat varianty</button>}
                                    modal
                                >
                                    {close => (
                                        <div className="modal">
                                            <button className="close" onClick={close}>
                                                &times;
                                            </button>
                                            <div className="header">
                                                Počet generovaných variant:
                                                <input className="default-border" type="text" ref={numberOfVariants} />
                                                <button onClick={handleGenerateVariants} >Generovat</button>
                                            </div>
                                            <div className="content">
                                                {variants && variants.map(variant => (
                                                    <div key={variant.id}>
                                                        <button className="bg-white hover:bg-gray-100 text-gray-800 font-semibold py-2 px-4 border border-gray-400 rounded mr-2" onClick={() => handleGeneratePdf(variant.id)}>{variant.name}</button>
                                                        <button onClick={() => handleDeleteVariant(variant.id)} >Smazat</button>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </Popup>
                                <button onClick={sendTestToDatabase}
                                    className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mr-2"
                                >Uložiť</button>
                                <button onClick={handleDeleteTest}
                                    className="x-btn bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
                                >Vymazať</button>
                            </div>
                        </div>
                        {test.sections.map(section => (
                            <Section key={section.id} section={section} getTest={getTest} selectedTestId={selectedTestId} />
                        ))}
                        <form className="test-footer">
                            <input type="text" ref={sectionName} placeholder="Názov sekcie"
                                className="default-border m-2 px-2 py-2 ml-0"
                            />
                            <input type="button" onClick={handleNewSection} value="Pridať sekciu"
                                className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                            />

                        </form>
                    </div>
                )}
            </div>
        </SetTest.Provider>
    )
}