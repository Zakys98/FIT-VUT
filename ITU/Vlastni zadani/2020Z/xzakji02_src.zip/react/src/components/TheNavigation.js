import React, { useState, useRef } from 'react'

import SubCategories from './SubCategories'
import Service from '../services/Service'

import { MdDelete } from 'react-icons/md'
import './scss-components/TheNavigation.scss'
import {API_URL} from '../config'

export default function TheNavigation(props) {

    const { categories, setCategories, selectedAddCategoryId, setSelectedAddCategoryId } = props

    const [selectedCategoryId, setSelectedCategoryId] = useState()
    const selectedCategory = categories.find(category => category.id === selectedCategoryId)

    const newCategoryName = useRef()
    const newSubCategoryName = useRef()

    const handleAddSubCategory = e => {
        e.preventDefault();
        let subCategoryName = newSubCategoryName.current?.value
        if (subCategoryName) {
            const newSubCategory = {
                name: subCategoryName,
                supercategory_id: selectedAddCategoryId
            }
            fetch(`${API_URL}/csrf`,
                {
                    credentials: 'include'
                })
                .then(r => r.json())
                .then(d => {
                    fetch(`${API_URL}/categories`,
                        {
                            credentials: 'include',
                            SameSite: "none",
                            method: "POST",
                            headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                            body: JSON.stringify(newSubCategory)
                        }).then(r => {
                            Service.getAllCategories()
                                .then(response => {
                                    setCategories(response.data)
                                    newSubCategoryName.current.value = ""
                                })
                                .catch(e => {
                                    console.log(e)
                                })
                        })
                });
        }
    }


    const handleAddCategory = e => {
        e.preventDefault();
        let categoryName = newCategoryName.current?.value
        if (categoryName) {
            const newCategory = {
                name: categoryName,
                supercategory_id: null
            }
            fetch(`${API_URL}/csrf`,
                {
                    credentials: 'include'
                })
                .then(r => r.json())
                .then(d => {
                    fetch(`${API_URL}/categories`,
                        {
                            credentials: 'include',
                            SameSite: "none",
                            method: "POST",
                            headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                            body: JSON.stringify(newCategory)
                        }).then(r => {
                            Service.getAllCategories()
                                .then(response => {
                                    setCategories(response.data)
                                    newCategoryName.current.value = ""
                                })
                                .catch(e => {
                                    console.log(e)
                                })
                        })
                })
        }
    }

    const handleSetSelectedAddCategoryId = (id) => {
        if (id === selectedAddCategoryId)
            setSelectedAddCategoryId(-1)
        else
            setSelectedAddCategoryId(id)
    }

    const handleSetSelectedCategoryId = id => {
        if(id === selectedCategoryId)
            setSelectedCategoryId(-1)
        else
            setSelectedCategoryId(id)
    }

    const handleDeleteCategory = catId => {
        fetch(`${API_URL}/csrf`,
                {
                    credentials: 'include'
                })
                .then(r => r.json())
                .then(d => {
                    fetch(`${API_URL}/categories/${catId}`,
                        {
                            credentials: 'include',
                            SameSite: "none",
                            method: "DELETE",
                            headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                        }).then(r => {
                            Service.getAllCategories()
                                .then(response => {
                                    setCategories(response.data)
                                })
                                .catch(e => {
                                    console.log(e)
                                })
                        })
                })
    }

    return (
        <nav className="navigation" >
            {categories && categories.map(category => (
                <div key={category.id} className="navigation-category">
					<div className={`navigation-category-header header flex justify-start rounded ${category === selectedCategory ?  "active" : "bg-white"  }`}>
						<a className="w-full p-2 bg-transparent rounded" href="##" onClick={() => { handleSetSelectedCategoryId(category.id) }} >{category.name}</a>
                        <a className="w-min bg-transparent p-2 rounded" href="##" title="Odstrániť kategóriu" onClick={() => {handleDeleteCategory(category.id)} }><MdDelete/></a>
						<a className="w-min bg-transparent px-4 py-2 plus rounded" href="##" title="Pridať podkategóriu" onClick={() => { handleSetSelectedAddCategoryId(category.id) }} >+</a>
                    </div>
					{category.id === selectedAddCategoryId && (
                        <form onSubmit={handleAddSubCategory}>
                            <input className="p-2 bg-gray-200 placeholder-gray-300::placeholder rounded" id="add-category" type="text" ref={newSubCategoryName} placeholder="Pridať podkategóriu" />
                        </form>
                    )}
                    {category === selectedCategory && (
                        <SubCategories key={category.id} category={category} setCategories={setCategories} selectedAddSubCategoryId={props.selectedAddSubCategoryId} setSelectedAddSubCategoryId={props.setSelectedAddSubCategoryId} setSelectedTestId={props.setSelectedTestId} />
                    )}
                </div>
            ))}
            <form onSubmit={handleAddCategory}>
                <input className="p-2 bg-gray-200 placeholder-gray-300::placeholder rounded" id="add-category" type="text" ref={newCategoryName} placeholder="Pridať kategóriu" />
            </form>
        </nav>
    )
}
