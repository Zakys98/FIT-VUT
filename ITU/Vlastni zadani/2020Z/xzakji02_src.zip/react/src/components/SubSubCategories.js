import React, { useState, useRef } from 'react'
import PropTypes from 'prop-types'

import Service from '../services/Service'

import './scss-components/SubSubCategories.scss'
import { MdDelete } from 'react-icons/md'
import {API_URL} from '../config'

function SubSubCategories(props) {

    const { subCategory, setSelectedTestId, setCategories } = props

    const [selectedSubSubCategoryId, setSelectedSubSubCategoryId] = useState()
    const selectedSubSubCategory = subCategory.subcategories.find(sub => sub.id === selectedSubSubCategoryId)

    const newSubSubSubTestName = useRef()
    const newSubSubTestName = useRef()

    const handleAddSubSubSubTest = e => {
        e.preventDefault()
        let subSubSubCategoryTestName = newSubSubSubTestName.current?.value
        if (subSubSubCategoryTestName) {
            const newTest = {
                name: subSubSubCategoryTestName,
                category_id: selectedSubSubCategory.id
            }
            fetch(`${API_URL}/csrf`,
                {
                    credentials: 'include'
                })
                .then(r => r.json())
                .then(d => {
                    fetch(`${API_URL}/tests`,
                        {
                            credentials: 'include',
                            SameSite: "none",
                            method: "POST",
                            headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                            body: JSON.stringify(newTest)
                        }).then(r => {
                            Service.getAllCategories()
                                .then(response => {
                                    setCategories(response.data)
                                    newSubSubSubTestName.current.value = ""
                                })
                                .catch(e => {
                                    console.log(e)
                                })
                        })
                })
        }
    }

    const handleAddSubSubTest = e => {
        e.preventDefault()
        let subSubCategoryTestName = newSubSubTestName.current?.value
        if (subSubCategoryTestName) {
            const newTest = {
                name: subSubCategoryTestName,
                category_id: subCategory.id
            }
            fetch(`${API_URL}/csrf`,
                {
                    credentials: 'include'
                })
                .then(r => r.json())
                .then(d => {
                    fetch(`${API_URL}/tests`,
                        {
                            credentials: 'include',
                            SameSite: "none",
                            method: "POST",
                            headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                            body: JSON.stringify(newTest)
                        }).then(r => {
                            Service.getAllCategories()
                                .then(response => {
                                    setCategories(response.data)
                                    newSubSubTestName.current.value = ""
                                })
                                .catch(e => {
                                    console.log(e)
                                })
                        })
                })
        }
    }

    const handleSetSelectedSubSubCategoryId = id => {
        if (id === selectedSubSubCategoryId)
            setSelectedSubSubCategoryId(-1)
        else
            setSelectedSubSubCategoryId(id)
    }

    const handleDeleteCategory = catId => {
        fetch(`${API_URL}/csrf`,
                {
                    credentials: 'include'
                })
                .then(r => r.json())
                .then(d => {
                    fetch(`${API_URL}/categories/${catId}`,
                        {
                            credentials: 'include',
                            SameSite: "none",
                            method: "DELETE",
                            headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                        }).then(r => {
                            Service.getAllCategories()
                                .then(response => {
                                    setCategories(response.data)
                                })
                                .catch(e => {
                                    console.log(e)
                                })
                        })
                })
    }

    const hideMenu = () => {
        document.getElementsByClassName("test_nav_container")[0].classList.toggle("test_nav_container_hide");
        document.getElementsByClassName("nav_mobile_button")[0].classList.toggle("nav_mobile_button_hide");
    }

    return (
        <div className="subSubCategories bg-gray-100 mb-2">
            {subCategory.subcategories.map(subSubCategory => (
                <div key={subSubCategory.id}>
				<div className={`subsub-header header my-2 flex justify-start rounded ${subSubCategory === selectedSubSubCategory ?  "active" : "bg-white"  }`}>
                    <a href="##" className="w-full py-2 bg-transparent rounded" onClick={() => { handleSetSelectedSubSubCategoryId(subSubCategory.id) }} >{subSubCategory.name}</a>
                    <a href="##" className="w-min py-2 bg-transparent rounded" onClick={() => {handleDeleteCategory(subSubCategory.id)} }><MdDelete/></a>
				</div>
                    {subSubCategory === selectedSubSubCategory && (
                        <div className="m-2 rounded">
                            {subSubCategory.tests.map(test => (
                                <a key={test.id} href="##" className="subsub-test bg-white rounded" onClick={() => setSelectedTestId(test.id)} >{test.name}</a>
                            ))}
                            <form onSubmit={handleAddSubSubSubTest} >
                                <input type="text" className="p-2 bg-gray-200 placeholder-gray-300::placeholder rounded" ref={newSubSubSubTestName} placeholder={"Pridať test do " + subSubCategory.name} />
                            </form>
                        </div>
                    )}
                </div>
            ))}
            {subCategory.tests.map(test => (
                <a key={test.id} href="##" className="rounded" onClick={function() {setSelectedTestId(test.id); hideMenu();}} >{test.name}</a>
            ))}
            <form onSubmit={handleAddSubSubTest}>
                <input type="text" className="p-2 bg-gray-200 placeholder-gray-300::placeholder rounded" ref={newSubSubTestName} placeholder={"Pridať test do " + subCategory.name} />
            </form>
        </div >
    )
}

SubSubCategories.propTypes = {
    subSubCategory: PropTypes.shape({
        id: PropTypes.number,
        created_at: PropTypes.number,
        updated_at: PropTypes.number,
        name: PropTypes.string,
        supercategory_id: PropTypes.number,
        subcategories: PropTypes.array,
        tests: PropTypes.array
    })
}

export default SubSubCategories

