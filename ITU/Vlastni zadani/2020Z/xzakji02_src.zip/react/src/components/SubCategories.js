import React, { useState, useRef } from 'react'
import PropTypes from 'prop-types'

import Service from '../services/Service'

import SubSubCategories from './SubSubCategories'

import './scss-components/SubCategories.scss'
import { MdDelete } from 'react-icons/md'
import {API_URL} from '../config'

SubCategories.propTypes = {
    category: PropTypes.shape({
        id: PropTypes.number,
        created_at: PropTypes.string,
        updated_at: PropTypes.string,
        name: PropTypes.string,
        supercategory_id: PropTypes.number,
        subcategories: PropTypes.array,
        tests: PropTypes.array
    })
}

function SubCategories(props) {

    const { category, setCategories, selectedAddSubCategoryId, setSelectedAddSubCategoryId, setSelectedTestId } = props

    const [selectedSubCategoryId, setSelectedSubCategoryId] = useState()
    const selectedSubCategory = category.subcategories.find(sub => sub.id === selectedSubCategoryId)

    const newSubSubCategoryName = useRef()

    const handleAddSubSubCategory = e => {
        e.preventDefault()
        let subSubCategoryName = newSubSubCategoryName.current?.value
        if (subSubCategoryName) {
            const newSubSubCategory = {
                name: subSubCategoryName,
                supercategory_id: selectedAddSubCategoryId
            }
            fetch(`${API_URL}/csrf`,
                {
                    credentials: 'include'
                })
                .then(r => r.json())
                .then(d => {
                    fetch(`${API_URL}/categories`,
                        {
                            credentials: 'include',
                            SameSite: "none",
                            method: "POST",
                            headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                            body: JSON.stringify(newSubSubCategory)
                        }).then(r => {
                            Service.getAllCategories()
                                .then(response => {
                                    setCategories(response.data)
                                    newSubSubCategoryName.current.value = ""
                                })
                                .catch(e => {
                                    console.log(e)
                                })
                        })
                })
        }
    }

    const handleSetSelectedAddSubCategoryId = (id) => {
        if (id === selectedAddSubCategoryId)
            setSelectedAddSubCategoryId(-1)
        else
            setSelectedAddSubCategoryId(id)
    }

    const newSubTestName = useRef()

    const handleAddSubTest = e => {
        e.preventDefault()
        let testName = newSubTestName.current?.value
        if (testName) {
            const newTest = {
                name: testName,
                category_id: category.id
            }
            fetch(`${API_URL}/csrf`,
                {
                    credentials: 'include'
                })
                .then(r => r.json())
                .then(d => {
                    fetch(`${API_URL}/tests`,
                        {
                            credentials: 'include',
                            SameSite: "none",
                            method: "POST",
                            headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                            body: JSON.stringify(newTest)
                        }).then(r => {
                            Service.getAllCategories()
                                .then(response => {
                                    setCategories(response.data)
                                    newSubTestName.current.value = ""
                                })
                                .catch(e => {
                                    console.log(e)
                                })
                        })
                })
        }
    }

    const handleSetSelectedSubCategoryId = id => {
        if (id === selectedSubCategoryId)
            setSelectedSubCategoryId(-1)
        else
            setSelectedSubCategoryId(id)
    }

    const handleDeleteCategory = catId => {
        fetch(`${API_URL}/csrf`,
                {
                    credentials: 'include'
                })
                .then(r => r.json())
                .then(d => {
                    fetch(`${API_URL}/categories/${catId}`,
                        {
                            credentials: 'include',
                            SameSite: "none",
                            method: "DELETE",
                            headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                        }).then(r => {
                            Service.getAllCategories()
                                .then(response => {
                                    setCategories(response.data)
                                })
                                .catch(e => {
                                    console.log(e)
                                })
                        })
                })
    }

    const hideMenu = () => {
        document.getElementsByClassName("test_nav_container")[0].classList.toggle("test_nav_container_hide");
        document.getElementsByClassName("nav_mobile_button")[0].classList.toggle("nav_mobile_button_hide");
    }

    return (
        <div className="subCategory py-2 bg-gray-100 rounded-lg flex flex-col" >
            {category.subcategories.map(subCategory => (
                <div key={subCategory.id} >
					<div className={`subCategory-header my-2 rounded header flex justify-start ${subCategory === selectedSubCategory ?  "active" : "bg-white" }`}>
                    <a href="##" className="w-full p-2 rounded" onClick={() => { handleSetSelectedSubCategoryId(subCategory.id) }} >{subCategory.name}</a>
                    <a href="##" className="w-min p-2 bg-transparent rounded" title="Odstrániť kategóriu" onClick={() => {handleDeleteCategory(subCategory.id)} }><MdDelete/></a>
                    <a href="##" className="w-min px-4 bg-transparent py-2 rounded plus" title="Pridať podkategóriu" onClick={() => { handleSetSelectedAddSubCategoryId(subCategory.id) }} >+</a>
					</div>
				    {subCategory.id === selectedAddSubCategoryId && (
                        <form onSubmit={handleAddSubSubCategory}>
                            <input className="w-full p-2 bg-gray-200 placeholder-gray-300::placeholder rounded" type="text" ref={newSubSubCategoryName} placeholder="Pridať podkategóriu" />
                        </form>
                    )}
                    {subCategory === selectedSubCategory && (
                        <SubSubCategories subCategory={subCategory} setSelectedTestId={setSelectedTestId} setCategories={setCategories} />
                    )}
				</div>
            ))}

            {category.tests.map(test => (
                <div className="subCategory-header my-2 rounded header flex justify-start bg-white" key={test.id} >
                    <a key={test.id} className="w-full p-2 rounded" href="##" onClick={function() {setSelectedTestId(test.id); hideMenu();}} >{test.name}</a>
                </div>
            ))}
            <form onSubmit={handleAddSubTest}>
                <input type="text" className="w-full p-2 bg-gray-200 placeholder-gray-300::placeholder rounded" ref={newSubTestName} placeholder={"Pridať test do " + category.name} />
            </form>
        </div>
    )
}

export default SubCategories