import React, { useRef } from 'react'
import { debounce } from 'lodash'

import Question from './Question'
import {API_URL} from '../config'

import './scss-components/Section.scss'

export default function Section(props) {

    const { section, getTest, selectedTestId } = props
    const questionText = useRef()
    const sectionName = useRef()
    const questionScore = useRef()
    const questionCount = useRef()

    const handleNewQuestion = () => {
        let questName = questionText.current?.value
        if (questName) {
            const newQuestion = {
                type: "fulltext",
                text: questName,
                answer_text: null,
                is_multichoice: 0,
                attachment_id: null,
            }
            fetch(`${API_URL}/csrf`,
                {
                    credentials: 'include'
                })
                .then(r => r.json())
                .then(d => {
                    fetch(`${API_URL}/tests/${selectedTestId}/sections/${section.id}/questions`,
                        {
                            credentials: 'include',
                            SameSite: "none",
                            method: "POST",
                            headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                            body: JSON.stringify(newQuestion)
                        }).then(r => {
                            getTest(selectedTestId)
                            questionText.current.value = ""
                        })
                })
        }
    }

    const deleteSection = () => {
        fetch(`${API_URL}/csrf`,
            {
                credentials: 'include'
            })
            .then(r => r.json())
            .then(d => {
                fetch(`${API_URL}/tests/${selectedTestId}/sections/${section.id}`,
                    {
                        credentials: 'include',
                        SameSite: "none",
                        method: "DELETE",
                        headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' }
                    }).then(r => getTest(selectedTestId))
            })
    }

    const handleUpdateSection = debounce(() => {
        var reg = /^[1-9]{1}\d*$/
        if(!reg.test(questionCount.current.value) || !reg.test(questionScore.current.value))
            return
        const updateSection = {
            name: sectionName.current.value,
            question_score: questionScore.current.value,
            question_count: questionCount.current.value
        }
        fetch(`${API_URL}/csrf`,
            {
                credentials: 'include'
            })
            .then(r => r.json())
            .then(d => {
                fetch(`${API_URL}/tests/${selectedTestId}/sections/${section.id}`,
                    {
                        credentials: 'include',
                        SameSite: "none",
                        method: "PUT",
                        headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                        body: JSON.stringify(updateSection)
                    }).then(r => getTest(selectedTestId))
            })
    }, 500)

    return (
        <div className="section default-border bg-gray-200" >
            <div className="w-full section_settings justify-between px-28" >
                <input className="px-2 rounded default-border" onChange={handleUpdateSection} defaultValue={section.name} ref={sectionName} />
                <button onClick={deleteSection}
					className="bg-white hover:bg-gray-100 text-gray-800 font-semibold py-1 px-4 border border-gray-400 rounded">
					Vymazať sekciu</button>
            </div>
            <div className="w-full section_settings justify-start p-2" >
                <h4>Počet bodov za otázku v tejto sekcii:</h4>
                <input className="default-border mx-4 px-2" type="text" onChange={handleUpdateSection} defaultValue={section.question_score} ref={questionScore} />
            </div>
            <div className="w-full section_settings justify-start p-2" >
                <h4>Počet generovaných otázok:</h4>
                <input className="default-border mx-4 px-2" type="text" onChange={handleUpdateSection} defaultValue={section.question_count} ref={questionCount} />
            </div>
            {section.questions.map(question => (
                <Question key={question.id} question={question} getTest={getTest} selectedTestId={selectedTestId} sectionId={section.id} />
            ))}
			<div className="add-question">
				<input type="text" ref={questionText} placeholder="Zadanie otázky" 
					className="default-border m-2 px-2 ml-0" 
				/>
				<input type="button" onClick={handleNewQuestion} value="Pridať otázku" 
					className="mx-1 my-2 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
				/>
			</div>
		</div>
    )
} 