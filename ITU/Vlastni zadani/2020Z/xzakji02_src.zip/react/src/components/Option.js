import React, { useContext } from 'react'

import { SetTest } from './CreateTest'

import { CgCloseO } from 'react-icons/cg'
import { IconContext } from "react-icons"

function Option(props) {

    const { option, sectionId, questionId } = props
    const setTest = useContext(SetTest)

    const handleChangeOptionBool = () => {
        setTest(currTest => {
            return {
                ...currTest, sections: currTest.sections.map(section => {
                    if (section.id === sectionId)
                        return {
                            ...section, questions: section.questions.map(quest => {
                                if (quest.id === questionId)
                                    return {
                                        ...quest, options: quest.options.map(opt => {
                                            if (opt === option) {
                                                if (opt.http === undefined || opt.http === "put")
                                                    return { ...opt, is_true: !opt.is_true, http: "put" }
                                                return { ...opt, is_true: !opt.is_true }
                                            }
                                            return opt
                                        })
                                    }
                                return quest
                            })
                        }
                    return section
                })
            }
        })
    }

    const handleChangeOptionText = text => {
        setTest(currTest => {
            return {
                ...currTest, sections: currTest.sections.map(section => {
                    if (section.id === sectionId)
                        return {
                            ...section, questions: section.questions.map(quest => {
                                if (quest.id === questionId)
                                    return {
                                        ...quest, options: quest.options.map(opt => {
                                            if (opt === option) {
                                                if (opt.http === undefined || opt.http === "put")
                                                    return { ...opt, text: text, http: "put" }
                                                return { ...opt, text: text }
                                            }
                                            return opt
                                        })
                                    }
                                return quest
                            })
                        }
                    return section
                })
            }
        })
    }

    const handleDeleteOption = () => {
        setTest(currTest => {
            return {
                ...currTest, sections: currTest.sections.map(section => {
                    if (section.id === sectionId)
                        return {
                            ...section, questions: section.questions.map(quest => {
                                if (quest.id === questionId)
                                    return {
                                        ...quest, options: quest.options.map(opt => {
                                            if (opt === option) {
                                                if(opt.http === undefined || opt.http === "put")
                                                    return { ...opt, http: "delete" }
                                                return { ...opt, http: "hidden" }
                                            }
                                            return opt
                                        })
                                    }
                                return quest
                            })
                        }
                    return section
                })
            }
        })
    }

    return (
        <div className="flex flex-nowrap items-center w-1/2">
            <input className="" type="checkbox" onChange={handleChangeOptionBool} checked={option.is_true} />
            <input className="px-2" type="text" onChange={(e) => { handleChangeOptionText(e.target.value) }} value={option.text} />
            <button onClick={handleDeleteOption} >
				<IconContext.Provider value={{ color: "gray", className: "global-class-name", style: { verticalAlign: 'middle' } }}>
					<div>
					<CgCloseO className="default-icon-m" />
					</div>
				</IconContext.Provider>
			</button>
        </div>
    )
}

export default Option