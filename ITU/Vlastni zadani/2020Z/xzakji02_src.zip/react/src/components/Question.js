import React, { useState, useRef, useContext, useEffect } from 'react'

import { SetTest } from './CreateTest'
import Option from './Option'
import Service from '../services/Service'
import { API_URL } from '../config'

import { MdDelete } from 'react-icons/md'
import { IconContext } from "react-icons"
import './scss-components/Question.scss'

export default function Question(props) {

    const { question, getTest, selectedTestId, sectionId } = props

    const [edit, setEdit] = useState(true)
    const [selectedFile, setSelectedFile] = useState(null)
    const optionText = useRef()
    const setTest = useContext(SetTest)
    const [oldQuestion, setOldQuestion] = useState()

    useEffect(() => {
        setOldQuestion(question)
    }, [question])

    const handleChange = () => {
        setEdit(prevEdit => !prevEdit)
        setTest(currTest => {
            return {
                ...currTest, sections: currTest.sections.map(section => {
                    if (section.id === sectionId)
                        return {
                            ...section, questions: section.questions.map(quest => {
                                if (quest === question)
                                    return oldQuestion
                                return quest
                            })
                        }
                    return section
                })
            }
        })
    }

    const handleQuestionText = text => {
        setTest(currTest => {
            return {
                ...currTest, sections: currTest.sections.map(section => {
                    if (section.id === sectionId)
                        return {
                            ...section, questions: section.questions.map(quest => {
                                if (quest === question)
                                    return { ...quest, text: text, http: "put" }
                                return quest
                            })
                        }
                    return section
                })
            }
        })
    }

    const handleQuestionAnswerText = text => {
        setTest(currTest => {
            return {
                ...currTest, sections: currTest.sections.map(section => {
                    if (section.id === sectionId)
                        return {
                            ...section, questions: section.questions.map(quest => {
                                if (quest === question)
                                    return { ...quest, answer_text: text, http: "put" }
                                return quest
                            })
                        }
                    return section
                })
            }
        })
    }

    const handleChangeTypeOfQuestion = str => {
        setTest(currTest => {
            return {
                ...currTest, sections: currTest.sections.map(section => {
                    if (section.id === sectionId)
                        return {
                            ...section, questions: section.questions.map(quest => {
                                if (quest === question)
                                    return { ...quest, type: str, http: "put" }
                                return quest
                            })
                        }
                    return section
                })
            }
        })
    }

    const handleAddOption = e => {
        e.preventDefault()
        let optText = optionText.current?.value
        if (optText) {
            const newOption = {
                text: optText,
                is_true: 0,
                question_id: question.id,
                http: "post"
            }
            setTest(currTest => {
                return {
                    ...currTest, sections: currTest.sections.map(section => {
                        if (section.id === sectionId)
                            return {
                                ...section, questions: section.questions.map(quest => {
                                    if (quest === question)
                                        return { ...quest, options: [...quest.options, newOption] }
                                    return quest
                                })
                            }
                        return section
                    })
                }
            })
        }
        optionText.current.value = ""
    }

    const handleSelectFile = event => {
        setSelectedFile(event.target.files[0])
    }

    const handleSaveSelectedFile = () => {
        if (selectedFile === null)
            return
        var formData = new FormData()
        formData.append("title", selectedFile.name)
        formData.append("type", selectedFile.type.split('/')[0])
        formData.append("file", selectedFile)
        fetch(`${API_URL}/csrf`,
            {
                credentials: 'include'
            })
            .then(r => r.json())
            .then(d => {
                fetch(`${API_URL}/attachments`,
                    {
                        credentials: 'include',
                        SameSite: "none",
                        method: "POST",
                        headers: { 'X-CSRF-TOKEN': d.token },
                        body: formData
                    }).then(r => {
                        Service.getAllAttachments()
                            .then(response => {
                                let idOfLastAttachments = -1
                                response.data.forEach(att => {
                                    idOfLastAttachments = att.id
                                })
                                setTest(currTest => {
                                    return {
                                        ...currTest, sections: currTest.sections.map(section => {
                                            if (section.id === sectionId)
                                                return {
                                                    ...section, questions: section.questions.map(quest => {
                                                        if (quest === question)
                                                            return { ...quest, attachment_id: idOfLastAttachments, http: "put" }
                                                        return quest
                                                    })
                                                }
                                            return section
                                        })
                                    }
                                })
                            })
                            .catch(e => {
                                console.log(e)
                            })
                    })
            })
    }

    const deleteQuestion = () => {
        fetch(`${API_URL}/csrf`,
            {
                credentials: 'include'
            })
            .then(r => r.json())
            .then(d => {
                fetch(`${API_URL}/tests/${selectedTestId}/sections/${sectionId}/questions/${question.id}`,
                    {
                        credentials: 'include',
                        SameSite: "none",
                        method: "DELETE",
                        headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' }
                    }).then(r => getTest(selectedTestId))
            })
    }

    const handleDeleteAttachments = () => {
        setTest(currTest => {
            return {
                ...currTest, sections: currTest.sections.map(section => {
                    if (section.id === sectionId)
                        return {
                            ...section, questions: section.questions.map(quest => {
                                if (quest === question)
                                    return { ...quest, attachment_id: null, http: "put" }
                                return quest
                            })
                        }
                    return section
                })
            }
        })
    }

    const handleSaveQuestion = () => {
        fetch(`${API_URL}/csrf`,
            {
                credentials: 'include'
            })
            .then(r => r.json())
            .then(d => {
                let multiChoice = 0
                question.options.forEach(opt => {
                    if (opt.is_true)
                        multiChoice++
                })
                if (multiChoice === 0 && question.type === "choice")
                    return
                let is_multi = false
                if (multiChoice > 1)
                    is_multi = true
                const updateQuestion = {
                    text: question.text,
                    type: question.type,
                    answer_text: question.answer_text,
                    is_multichoice: is_multi,
                    attachment_id: question.attachment_id
                }
                fetch(`${API_URL}/tests/${selectedTestId}/sections/${sectionId}/questions/${question.id}`,
                    {
                        credentials: 'include',
                        SameSite: "none",
                        method: "PUT",
                        headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                        body: JSON.stringify(updateQuestion)
                    }).then(r => getTest(selectedTestId))

                question.options.forEach(opt => {
                    if (opt.http !== undefined && opt.http === "post") {
                        fetch(`${API_URL}/options`,
                            {
                                credentials: 'include',
                                SameSite: "none",
                                method: "POST",
                                headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                                body: JSON.stringify({ text: opt.text, is_true: opt.is_true, question_id: opt.question_id })
                            }).then(r => getTest(selectedTestId))
                    } else if (opt.http !== undefined && opt.http === "put") {
                        fetch(`${API_URL}/options/${opt.id}`,
                            {
                                credentials: 'include',
                                SameSite: "none",
                                method: "PUT",
                                headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                                body: JSON.stringify({ text: opt.text, is_true: opt.is_true, question_id: opt.question_id })
                            }).then(r => getTest(selectedTestId))
                    } else if (opt.http !== undefined && opt.http === "delete") {
                        fetch(`${API_URL}/options/${opt.id}`,
                            {
                                credentials: 'include',
                                SameSite: "none",
                                method: "DELETE",
                                headers: { 'X-CSRF-TOKEN': d.token, 'content-type': 'application/json' },
                            }).then(r => getTest(selectedTestId))
                    }
                })
            })
        setEdit(prevEdit => !prevEdit)
    }

    if (edit) {
        return (
            <div className="question" >
                <div className="question-type">
                    <div>
                        <strong><label>Typ úlohy </label></strong>
                        <select className="default-border" onChange={(e) => { handleChangeTypeOfQuestion(e.target.value) }} value={question.type} >
                            <option value="fulltext" >Fulltext</option>
                            <option value="choice" >Choice</option>
                        </select>
                    </div>
                    <button onClick={deleteQuestion}
                        className="bg-white hover:bg-gray-100 text-gray-800 font-semibold py-1 px-4 border border-gray-400 rounded">
                        Vymazať otázku</button>
                </div>
                <div className="question-header">
                    <label>Zadanie:</label>
                    <input className="default-border" type="text" onChange={(e) => { handleQuestionText(e.target.value) }} value={question.text} />
                </div>
                {question.type === "fulltext" && (
                    <textarea className="default-border resize_none" onChange={(e) => { handleQuestionAnswerText(e.target.value) }} value={question.answer_text} />
                )}
                {question.type === "choice" && (
                    <div className="options flex flex-col justify-start" >
                        {question.options && (question.options.map(opt => (
                            (opt.http === undefined || opt.http === "post" || opt.http === "put") && (
                                <Option key={opt.id} option={opt} sectionId={sectionId} questionId={question.id}
                                />
                            ))))}
                        <form className="w-1/2 flex justify-start" onSubmit={handleAddOption}>
                            <input type="text" ref={optionText} placeholder="+ Pridať možnosť" />
                        </form>
                    </div>
                )}

                <div className="question-attachment">
                    <input type="file" accept="image/*" onChange={(e) => handleSelectFile(e)} />
                    <input type="button" value="Pridať prílohu" onClick={handleSaveSelectedFile}
                        className="bg-white hover:bg-gray-100 text-gray-800 font-semibold py-1 px-4 border border-gray-400 rounded"
                    />
                </div>
                {question.attachment_id && question.attachment && (
                    <div className="added-attachements">
                        <h4>Príloha: </h4> {question.attachment.title}
                        <IconContext.Provider value={{ color: "gray", className: "global-class-name", style: { verticalAlign: 'middle' } }}>
                            <div>
                                <MdDelete onClick={handleDeleteAttachments} className="default-icon-m" />
                            </div>
                        </IconContext.Provider>
                    </div>
                )}
                <div className="flex justify-end">
                    <button onClick={handleSaveQuestion}
                        className="mr-2 bg-transparent hover:bg-green-500 text-green-500 font-semibold hover:text-white py-1 px-4 border border-green-500 hover:border-transparent rounded">
                        Uložiť</button>
                    <button onClick={handleChange}
                        className="bg-transparent hover:bg-red-500 text-red-500 font-semibold hover:text-white py-1 px-4 border border-red-500 hover:border-transparent rounded">
                        Zrušiť</button>
                </div>
            </div>
        )
    } else {
        return (
            <div className="question" >
                <div className="question-type">
                    <div>
                        <strong><label>Typ úlohy </label></strong>
                        <select className="default-border" onChange={(e) => { handleChangeTypeOfQuestion(e.target.value) }} value={question.type} disabled >
                            <option value="fulltext" >Fulltext</option>
                            <option value="choice" >Choice</option>
                        </select>
                    </div>
                    <button onClick={handleChange}
                        className="bg-white hover:bg-gray-100 text-gray-800 font-semibold py-1 px-4 border border-gray-400 rounded">Edit</button>
                </div>
                <div className="question-header">
                    <label>Zadanie: </label>
                    <span className="question-text">{question.text}</span>
                </div>
                {question.type === "fulltext" && (
                    <textarea className="default-border resize_none" value={question.answer_text} disabled />
                )}
                {question.type === "choice" && (
                    <div className="options flex flex-col justify-start" >
                        {question.options && (question.options.map(opt => (
                            (opt.http === undefined || opt.http === "post" || opt.http === "put") && (
                                <div key={opt.id} className="flex flex-nowrap items-center w-1/2" >
                                    <input type="checkbox" checked={opt.is_true} disabled />
                                    <span className="px-2">{opt.text}</span>
                                </div>
                            ))))}
                    </div>
                )}
                {question.attachment_id && question.attachment && (
                    <div className="added-attachements">
                        <h4>Príloha: </h4> {question.attachment.title}
                    </div>
                )}
            </div>
        )
    }
}
