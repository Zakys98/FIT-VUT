
export const API_URL = "https://itu-testit.herokuapp.com";
// export const API_URL = "localhost";