
########## WEBOVKA ##########

Source kódy ku tvorbe testov sa nachádzajú v adresári react.
Tento kód sa však musí buildnúť pomocou npm run-script build a presunúť z
	react/build/static/
do
	tvorba-testov-web/public/react

Potom platí následovné....

Požiadavky:
	PHP 7.4
	Composer 1.10.17 (lokálne testované na 1.6.5)
	Databáza PostgreSQL, alebo MySQL

Inštalácia:
	Inštalácia PHP a Composeru na serveri
	Prekopírovanie súborov na server (v prípade .zip aj rozbaliť) a spustenie príkazov:
		$ mv .env.example .env
		$ composer install
		$ php artisan key:generate
	Do súboru .env doplnenie riadkov:
		SESSION_SECURE_COOKIE=false
		SESSION_SAME_SITE=lax
		TZ=Europe/Prague
	Nastavenie databázy:
		v .env nastaviť všetky premenné DB_
	Príkaz pre vytvorenie tabuliek a naplnenie dátami:
		$ php artisan migrate:fresh --seed
	V prípade, že composer nedoinštaloval Livewire:
		$ composer require livewire/livewire

########## DESKTOP ##########

- aplikácia sa spúšťa v programe VisualStudio (tvorba-testov-desktop/TestIT/TestIT.sln)
- inštalátor nebol implementovaný