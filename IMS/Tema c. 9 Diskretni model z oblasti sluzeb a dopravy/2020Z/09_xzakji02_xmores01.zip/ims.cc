/**
 * Projekt IMS 2020
 * Diskretni model z oblasti sluzeb a dopravy
 * Autori: Jiri Zak(xzakji02), Eva Moresova(xmores01)  
*/

#include "simlib.h"
#include <iostream>
#include <string>

Facility *normal;
Store self("Samoobslužné pokladny", 6);
int numberOfNormal;

class Customer : public Process
{
	void Behavior()
	{
		//vyber medzi samoobsluznou a klasickou pokladnou
		if (Random() <= 0.53)
		{
			Enter(self, 1);
			Wait(Normal(120, 30));
			Leave(self, 1);
		}
		else
		{
			int idx = 0;
			//vyber najkratsej fronty
			for (int i = 0; i < numberOfNormal; i++)
			{
				if (normal[i].QueueLen() < normal[idx].QueueLen() || 
				(normal[i].QueueLen() == normal[idx].QueueLen() && !normal[i].Busy() && normal[idx].Busy()))
				{
					idx = i;
				}
			}
			Seize(normal[idx]);
			Wait(Normal(150, 30));
			Release(normal[idx]);
		}
	}
};

class Generator : public Event
{
	void Behavior()
	{
		(new Customer)->Activate();
		Activate(Time + Exponential(30));
	}
};

int main(int argc, char **argv)
{
	if (argc != 3)
	{
		std::cout << "Invalid arguments\n";
	}
	else
	{
		std::string arg1 = argv[1]; //pocet klasickych pokladni
		std::string arg2 = argv[2]; //pocet samoobsluznych pokladni
		try
		{
			std::size_t pos;
			numberOfNormal = std::stoi(arg1, &pos);
			if (pos < arg1.size())
			{
				std::cerr << "error\n";
				return 1;
			}
			normal = new Facility[numberOfNormal];
			if (normal == nullptr) 
			{
				std::cerr << "error\n";
				return 1;
			}
			int numberOfSelf = std::stoi(arg2, &pos);
			if (pos < arg2.size())
			{
				std::cerr << "error\n";
				return 1;
			}
			self.SetCapacity(numberOfSelf);
			
		}
		catch (std::invalid_argument const &er)
		{
			std::cerr << "Invalid arguments\n";
			return 1;
		}


		SetOutput("ims.out");
		//simulujeme 1 hodinu
		Init(0, 3600);
		(new Generator)->Activate(); 
		Run();
		self.Output();
		for (int i = 0; i < numberOfNormal; i++)
		{
			normal[i].Output();
		}
		delete [] normal;
	}
	return 0;
}
