﻿IPK - projekt 2
Varianta ZETA: Sniffer paketů
Autor: Jiří Žák

Zadání:
    Vytvořit síťový analyzátor, který bude na určitém síťovém rozhraní zachytávat a filtrovat pakety

Spuštění:
    1. Vytvoření spustitelného souboru příkazem make přiloženým Makefilem
    2. Samotné spuštění přes ./ipk-sniffer
    3. Program můžeme spustit i s příslušnými argumenty (více popsáno v manuálu)

Odevzdanné soubory:
    ipk-sniffer.c - soubor s programem vytvořeným v jazyce C
    Makefile - soubor pro překlad programu
    manual.pdf - soubor s uživatelským manuálem k programu
