/**
 * IPK projekt 2 - packet sniffer
 * Autor: Jiří Žák - xzakji02
 * Datum: 29.4.2020
 

Copyright 2018 Dominik Liebler

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom
the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#include <arpa/inet.h>
#include <net/ethernet.h>
#include <netdb.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <pcap.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>

//argument struct
typedef struct args {
    char i[10];
    int p;
    bool tcp;
    bool udp;
    int n;
} Args;

//Globals
Args *arguments;
pcap_t *open;

//Prototypes
void parse_packet(u_char *, const struct pcap_pkthdr *, const u_char *);
void print_tcp(const u_char *, int);
void print_udp(const u_char *, int);
void print_data(const u_char *, int);
void getTime();
void printName(struct sockaddr_in);

int main(int argc, char **argv) {
    //pocatecni incializace struktury pro argumenty
    arguments = malloc(sizeof(struct args));
    if (arguments == NULL) return -1;
    arguments->tcp = false;
    arguments->udp = false;
    arguments->n = 1;
    arguments->p = -1;
    memset(arguments->i, 0, 10);

    // nacitani a osetreni vstupnich argumentu
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-t") == 0 || strcmp(argv[i], "--tcp") == 0)
            arguments->tcp = true;
        if (strcmp(argv[i], "-u") == 0 || strcmp(argv[i], "--udp") == 0)
            arguments->udp = true;
        if (strcmp(argv[i], "-i") == 0)
            if(argv[i + 1] != NULL)
                strcpy(arguments->i, argv[i + 1]);
        if (strcmp(argv[i], "-n") == 0)
            if(argv[i + 1] != NULL)
                arguments->n = (int)strtol(argv[i + 1], NULL, 10);
        if (strcmp(argv[i], "-p") == 0)
            if(argv[i + 1] != NULL)
                arguments->p = (int)strtol(argv[i + 1], NULL, 10);
    }

    char error[PCAP_ERRBUF_SIZE];
    // kontrola jeslti je zadán parametr -i
    if (arguments->i[0] == '\0') {
        pcap_if_t *interfaces, *temp;
        if (pcap_findalldevs(&interfaces, error) == -1) {
            printf("Error in pcap_findalldevs\n");
        }
        for (temp = interfaces; temp; temp = temp->next) {
            printf("%s\n", temp->name);
        }
    } else {
        const char *a = arguments->i;
        open = pcap_open_live(a, 65536, 1, 1000, error);
        if (open == NULL) {
            printf("%s\n", error);
            free(arguments);
            return -1;
        } else {
            //kontrola jeslti je zadán -p port kvůli filtru
            if (arguments->p == -1) {
                pcap_loop(open, 0, parse_packet, NULL);
            } else {
                struct bpf_program fp;
                char filter[10] = "port ";
                char port[7];
                sprintf(port, "%d", arguments->p);
                strcat(filter, port);
                if (pcap_compile(open, &fp, filter, 0, PCAP_NETMASK_UNKNOWN) ==
                    -1) {
                    printf("error in pcap_compile");
                    free(arguments);
                    return -1;
                }
                if (pcap_setfilter(open, &fp) == -1) {
                    printf("error in pcap_setfilter");
                    free(arguments);
                    return -1;
                }
                pcap_loop(open, 0, parse_packet, NULL);
            }
            pcap_close(open);
        }
    }
    //uklid na konec programu
    free(arguments);

    return 0;
}

// funkce pro výpis aktuálního času
void getTime() {
    char buffer[30];
    struct timeval tv;
    time_t curtime;
    gettimeofday(&tv, NULL);
    curtime = tv.tv_sec;
    strftime(buffer, 30, "%T.", localtime(&curtime));
    printf("%s%ld ", buffer, tv.tv_usec);
}

// funkce pro překlad IP adresy
void printName(struct sockaddr_in source){
    struct sockaddr_in sa;
    memset(&sa, 0, sizeof sa);
    sa.sin_family = AF_INET;
    char node[50];
    const char *text = inet_ntoa(source.sin_addr);
    inet_pton(AF_INET, text, &sa.sin_addr);
    
    int res = getnameinfo((struct sockaddr *)&sa, sizeof(sa), node, sizeof(node), NULL, 0, 0);

    printf("%s", node); 
}

// funkce pro výpis TCP packetu
void print_tcp(const u_char *data, int size) {
    struct iphdr *iph = (struct iphdr *)(data + sizeof(struct ethhdr));
    unsigned short iphdrlen = iph->ihl * 4;
    struct tcphdr *tcph =
        (struct tcphdr *)(data + iphdrlen + sizeof(struct ethhdr));
    int header_size = sizeof(struct ethhdr) + iphdrlen + tcph->doff * 4;

    struct sockaddr_in dest, source;
    memset(&source, 0, sizeof(source));
    source.sin_addr.s_addr = iph->saddr;
    memset(&dest, 0, sizeof(dest));
    dest.sin_addr.s_addr = iph->daddr;

    getTime();
    printName(source);
    printf(" : %u > ", ntohs(tcph->source));
    printName(dest);
    printf(" : %u\n", ntohs(tcph->dest));
    printf("\n");

    print_data(data, size);
    printf("\n");
}

// funkce pro výpis UDP packetu
void print_udp(const u_char *data, int size) {
    struct iphdr *iph = (struct iphdr *)(data + sizeof(struct ethhdr));
    unsigned short iphdrlen = iph->ihl * 4;
    struct udphdr *udph =
        (struct udphdr *)(data + iphdrlen + sizeof(struct ethhdr));
    int header_size = sizeof(struct ethhdr) + iphdrlen + sizeof(udph);

    struct sockaddr_in dest, source;
    memset(&source, 0, sizeof(source));
    source.sin_addr.s_addr = iph->saddr;
    memset(&dest, 0, sizeof(dest));
    dest.sin_addr.s_addr = iph->daddr;
    getTime();
    printName(source);
    printf(" : %u > ", ntohs(udph->source));
    printName(dest);
    printf(" : %u\n", ntohs(udph->dest));
    printf("\n");

    print_data(data, size);
    printf("\n");
}

// callback funkce pro prijimani packetu a jejich rozliseni
void parse_packet(u_char *args, const struct pcap_pkthdr *header,
                  const u_char *buffer) {
    struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));
    if (arguments->n != 0) {
        if ((arguments->tcp == false && arguments->udp == false) ||
            (arguments->tcp == true && arguments->udp == true)) {
            switch (iph->protocol) {
                case IPPROTO_TCP:
                    print_tcp(buffer, header->len);
                    arguments->n--;
                    break;
                case IPPROTO_UDP:
                    print_udp(buffer, header->len);
                    arguments->n--;
                    break;
                default:
                    break;
            }
        } else if (arguments->tcp == true && arguments->udp == false) {
            switch (iph->protocol) {
                case IPPROTO_TCP:
                    print_tcp(buffer, header->len);
                    arguments->n--;
                    break;
                default:
                    break;
            }
        } else {
            switch (iph->protocol) {
                case IPPROTO_UDP:
                    print_udp(buffer, header->len);
                    arguments->n--;
                    break;
                default:
                    break;
            }
        }
        if(arguments->n == 0)
            pcap_breakloop(open);
    } else {
        pcap_breakloop(open);
    }
}

// funkce pro vypis dat z pameti
// převzatá a upravená funkce
void print_data(const u_char *data, int size) {
    int i;
    unsigned char buff[17];
    for (i = 0; i < size; i++) {

        if ((i % 16) == 0) {
            if (i != 0) printf("  %s\n", buff);

            printf("  0x%04x: ", i);
        }

        printf(" %02x", data[i]);

        if ((data[i] < 0x20) || (data[i] > 0x7e)) {
            buff[i % 16] = '.';
        } else {
            buff[i % 16] = data[i];
        }

        buff[(i % 16) + 1] = '\0';
    }
    while ((i % 16) != 0) {
        printf("   ");
        i++;
    }
    printf("  %s\n", buff);
}