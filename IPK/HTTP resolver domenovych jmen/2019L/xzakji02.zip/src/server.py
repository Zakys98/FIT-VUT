import sys
import socket
import re

PORT = int(sys.argv[1])
mistake = False
message_body = ""
if (PORT < 1024 or PORT > 65536):
    print("Bad port")
    exit()

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind(('', PORT))
    s.listen()
    while True:
        conn, addr = s.accept()
        with conn:
            data = conn.recv(1024)
            if not data:
                break
            splt = data.decode().split(' ')
            if (splt[0] == 'GET'):
                resolve = splt[1].split('?')
                if(resolve[0] != "/resolve"):
                    mistake = True
                    message_head = "HTTP/1.1 400 Bad Request \r\n\r\n"
                res = re.split('=|&', resolve[1])
                if(res[3] == 'A'):
                    try:
                        ip_get = socket.gethostbyname(res[1])    
                    except socket.gaierror as error_sga:
                        mistake = True
                        message_head = "HTTP/1.1 404 Not Found \r\n\r\n"
                    if(res[1] == ip_get) or (res[1] == ""):
                        mistake = True
                        message_head = "HTTP/1.1 400 Bad Request \r\n\r\n"
                    if(mistake == False):
                        message_body = res[1] + ":" + res[3] + "=" + ip_get + "\n"
                elif(res[3] == 'PTR'):
                    try:
                        if(res[1] != ""):
                            url_get_name, url_get_alias, url_get_addrlist = socket.gethostbyaddr(res[1])
                        else:
                            mistake = True
                            url_get_name = ""
                            message_head = "HTTP/1.1 400 Bad Request \r\n\r\n"
                    except socket.gaierror as error_sga:
                        mistake = True
                        message_head = "HTTP/1.1 404 Not Found \r\n\r\n"
                    if(res[1] == url_get_name):
                        mistake = True
                        message_head = "HTTP/1.1 400 Bad Request \r\n\r\n"
                    if(mistake == False):
                        message_body = res[1] + ":" + res[3] + "=" + url_get_name + "\n"
                else:
                    mistake = True
                    message_head = "HTTP/1.1 400 Bad Request \r\n\r\n"
                if(mistake == False):
                    message_head = "HTTP/1.1 200 OK \r\n\r\n"
                message = message_head + message_body
            elif (splt[0] == 'POST'):
                if(splt[1] != "/dns-query"):
                    mistake = True
                    message_head = "HTTP/1.1 400 Bad Request \r\n\r\n"
                haha = data.decode().split('\r\n\r\n')
                res = re.split('\n', haha[1])
                for i in range(len(res)):
                    res[i] = res[i].replace(" ", "")          
                if(len(res) == 1) and (mistake == False):           # soubor je prazdny a /dns-query je spravne
                    mistake = True
                    message_head = "HTTP/1.1 400 Bad Request \r\n\r\n"
                if(mistake == False):
                    for i in range(len(res)):
                        roz = res[i].split(':')
                        if(roz[0] == "") and (i+1 != len(res)) and (len(roz) == 1):     # osetreni prazdneho radku uprostred souboru
                            mistake = True
                            message_head = "HTTP/1.1 400 Bad Request \r\n\r\n"
                            message_body = ""
                            break
                        miss = False
                        if(roz[1] == 'A'):
                            try:
                                ip_get = socket.gethostbyname(roz[0])
                            except socket.gaierror as error_sga:
                                miss = True
                            if(roz[0] == ip_get) or (roz[0] == ""):
                                miss = True
                            if(miss == False):
                                message_body += roz[0] + ":" + roz[1] + "=" + ip_get + "\r\n"
                        elif(roz[1] == 'PTR'):
                            try:
                                if(roz[0] != ""):
                                    url_get_name, url_get_alias, url_get_addrlist = socket.gethostbyaddr(roz[0])
                                else:
                                    miss = True
                            except socket.gaierror as error_sga:
                                miss = True
                            if(roz[0] == url_get_name):
                                miss = True
                            if(miss == False):
                                message_body += roz[0] + ":" + roz[1] + "=" + url_get_name + "\r\n"
                if(mistake == False):
                    message_head = "HTTP/1.1 200 OK \r\n\r\n"
                if(message_body == "") and (message_head != "HTTP/1.1 404 Not Found \r\n\r\n"):
                    message_head = "HTTP/1.1 400 Bad Request \r\n\r\n"
                message = message_head + message_body
            else:
                message = "HTTP/1.1 405 Method Not Allowed \r\n\r\n"
            conn.sendall(message.encode())
            message_body = ""
            mistake = False
            conn.close()
