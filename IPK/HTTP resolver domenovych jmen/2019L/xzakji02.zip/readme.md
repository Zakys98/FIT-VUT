DNS resolver

  - podporuje GET a POST
  - překládá doménová jména
  - kontroluje chyby a vrací příslušné chybové hlášky
  - implementované v jazyce Python3.6
  - server se spouští příkazem: make run PORT=5353
  - server se ukončuje CTRL + C

  GET:
      curl localhost:5353/resolve?name=www.fit.vutbr.cz\&type=A   - ukázka použití

  POST:
      curl --data-binary @queries.txt -X POST http://localhost:5353/dns-query   - ukázka použití
      soubor queries.txt:
          www.fit.vutbr.cz:A
          www.google.com:A
          www.seznam.cz:A
          147.229.14.131:PTR
          ihned.cz:A