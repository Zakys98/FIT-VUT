﻿Testovací scénáře do předmětu ITS 
Žák Jiří

Testovací sada obsahuje 3 feature soubory. Každý soubor obsahuje testy
pro jeden element webu OpenCart.

Feature soubory:

    • cart
    • overall
    • user

Sada cart:

    • Přidání položky do prázdného koše
    • Přidání položky do neprázdného koše
    • Přidání položky přímo z hlavní stránky webu do koše
    • Vytvořit objednávku
    • Zadaní validního kupón kódu
    • Zadaní nevalidního kupón kódu
    • Zadaní nevalidního dárkového kódu

Sada overall:

    • Přístupnost
    • Měna
    • Vrácení na hlavní stránku
    • Kontaktování prodejce

Sada user:

    • Registrace
    • Správný login
    • Špatný login
    • Změna hesla
    • Změna údajů
    • Odhlášení 
    • Přidání položky do wish listu
    • Odstranění položky z wish listu
    • Změna odběru

