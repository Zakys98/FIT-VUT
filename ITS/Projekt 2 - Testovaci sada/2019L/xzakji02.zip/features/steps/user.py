from behave import *
from selenium.webdriver.support.ui import WebDriverWait

@given("Uživatel se nachází na stránce, kde se může zaregistrovat")
def step_impl(context):
    context.driver.get("http://mys01.fit.vutbr.cz:8057/index.php?route=account/register")

@when("Uživatel vyplní správně všechny textové pole s hvězdičkou")
def step_impl(context):
    context.driver.find_element_by_xpath("//input[@id='input-firstname']").send_keys("Pavel")
    context.driver.find_element_by_xpath("//input[@id='input-lastname']").send_keys("Novak")
    context.driver.find_element_by_xpath("//input[@id='input-telephone']").send_keys("602685369")
    context.driver.find_element_by_xpath("//input[@id='input-address-1']").send_keys("Bozetechova 111")
    context.driver.find_element_by_xpath("//input[@id='input-city']").send_keys("London")
    context.driver.find_element_by_xpath("//input[@id='input-postcode']").send_keys("57001")
    context.driver.find_element_by_xpath("//input[@id='input-password']").send_keys("123456789")
    context.driver.find_element_by_xpath("//select[@id='input-zone']").click()
    context.driver.find_element_by_xpath("//select[@id='input-zone']/option[2]").click()
    context.driver.find_element_by_xpath("//form/div/div/input").click()

@when("Heslo musí mít více než 3 znaky")
def step_impl(context):
    context.driver.find_element_by_xpath("//input[@id='input-confirm']").send_keys("123456789")

@when("Email musí mít správný formát")
def step_impl(context):
    context.driver.find_element_by_xpath("//input[@id='input-email']").send_keys("novak_pavel29@seznam.cz")

@when("Stiskne tlačítko Continue")
def step_impl(context):
    context.driver.find_element_by_xpath("//form/div/div/input[2]").click()

@then("Uživatel je přesměrován na další stránku")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'Your Account Has Been Created!')]")
    context.driver.find_element_by_xpath("//div[@id='content']/div/div").click()

@then("Uživatel je zaregistrován do databáze")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'My Orders')]")



@given("Uživatel se nachází na stránce, kde se může přihlásit")
def step_impl(context):
    context.driver.get("http://mys01.fit.vutbr.cz:8057/index.php?route=account/login")

@when("Uživatel vyplní správně emailovou adresu a heslo")
def step_impl(context):
    context.driver.find_element_by_xpath("//input[@id='input-email']").send_keys("novak_pavel@seznam.cz")
    context.driver.find_element_by_xpath("//input[@id='input-password']").send_keys("123456")

@when("Stiskne tlačítko Login")
def step_impl(context):
    context.driver.find_element_by_xpath("//div[@class='well']/form/input").click()

@then("Uživatel je přesměrován na stránku s jeho účtem")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'My Orders')]")



@when("Uživatel vyplní špatně emailovou adresu nebo heslo")
def step_impl(context):
    context.driver.find_element_by_xpath("//input[@id='input-email']").send_keys("novhhhjakel@seznalklm.cz")
    context.driver.find_element_by_xpath("//input[@id='input-password']").send_keys("123asda466556")

@then("Stránka vypíše chybovou hlášku")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'Warning: No match for E-Mail Address and/or Password.')]")



@given("Uživatel je přihlášen")
def step_impl(context):
    context.driver.get("http://mys01.fit.vutbr.cz:8057/index.php?route=account/login")
    context.driver.find_element_by_xpath("//input[@id='input-email']").send_keys("novak_pavel@seznam.cz")
    context.driver.find_element_by_xpath("//input[@id='input-password']").send_keys("123456")
    context.driver.find_element_by_xpath("//div[@class='well']/form/input").click()

@given("Nachází se na stránce, kde si může změnit heslo")
def step_impl(context):
    context.driver.find_element_by_xpath("//a[contains(text(),'Change your password')]").click()

@when("Vyplní obě textová pole novým stejným heslem")
def step_impl(context):
    context.driver.find_element_by_xpath("//input[@id='input-password']").send_keys("123456")
    context.driver.find_element_by_xpath("//input[@id='input-confirm']").send_keys("123456")

@when("Stiskne tlačítko Continue upravující stránce")
def step_impl(context):
    context.driver.find_element_by_xpath("//form/div/div[@class='pull-right']").click()

@then("Heslo se úspěšně změní")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'Success: Your password has been successfully updated.')]")



@given("Nachází se na stránce, kde si může změnit svoje údaje")
def step_impl(context):
    context.driver.find_element_by_xpath("//a[contains(text(),'Edit your account information')]").click()

@when("Změní některý z údajů")
def step_impl(context):
    context.driver.find_element_by_xpath("//input[@id='input-firstname']").clear()
    context.driver.find_element_by_xpath("//input[@id='input-firstname']").send_keys("Jana")
    context.driver.find_element_by_xpath("//input[@id='input-lastname']").clear()
    context.driver.find_element_by_xpath("//input[@id='input-lastname']").send_keys("Novakova")
    
@when("Stiskne tlačítko Continue na stránce změny údajů")
def step_impl(context):
    context.driver.find_element_by_xpath("//form/div/div[@class='pull-right']").click()

@then("Údaje se úspěšně změní")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'Success: Your account has been successfully updated.')]")



@when("Uživatel stiskne tlačítko srdce u vybraného produktu")
def step_impl(context):
    context.driver.find_element_by_xpath("//div/div[1]/div/div[3]/button[2]").click()

@then("Vybraná položka se přidá do jeho wish listu")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'Wish List (1)')]")



@given("Nachází se na stránkách svého wish listu")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'Wish List (1)')]").click()

@when("Uživatel stiskne tlačítko s křížkem u některé položky")
def step_impl(context):
    context.driver.find_element_by_xpath("//tr[1]/td[6]/a").click()

@then("Položka se odstraní z wish listu")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'Wish List (0)')]")



@given("Nachází se na stránce, kde si může změnit odběr")
def step_impl(context):
    context.driver.find_element_by_xpath("//a[contains(text(),'Subscribe / unsubscribe to newsletter')]").click()

@when("Uživatel změní radio button")
def step_impl(context):
    context.driver.find_element_by_xpath("//form/fieldset/div/div/label[1]").click()

@when("Stiskne tlačítko Continue na stránce s odběrem")
def step_impl(context):
    context.driver.find_element_by_xpath("//form/div/div[@class='pull-right']").click()

@then("Odběr se úspěšně změní")
def step_impl(context):
     context.driver.find_element_by_xpath("//*[contains(text(),'Success: Your newsletter subscription has been successfully updated!')]")



@when("Uživatel otevře bar My Account v menu")
def step_impl(context):
    context.driver.find_element_by_xpath("//span[contains(.,'My Account')]").click()

@when("Stiskne tlačítko Logout")
def step_impl(context):
    context.driver.find_element_by_xpath("//a[contains(text(),'Logout')]").click()

@then("Přesměrován na stránku odhlášení")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'Account Logout')]")

