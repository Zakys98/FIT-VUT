from behave import *
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By


@given("Uživatel má libovolný prohlížeč")
def step_impl(context):
    pass

@given("Uživatel je přípojený k internetu")
def step_impl(context):
    context.driver.get("https://ismyinternetworking.com/")
    context.driver.find_element_by_id("yeslink")

@when("Uživatel otevře nákupní stránku")
def step_impl(context):
    context.driver.get("http://mys01.fit.vutbr.cz:8057/")

@then("Stránka se načte bez problému")
def step_impl(context):
    context.driver.find_element_by_class_name("common-home")

@then("Objeví se v prohlížeči")
def step_impl(context):
    context.driver.save_screenshot("whole_website.png")



@given("Uživatel se nachází na stránce s produkty")
def step_impl(context):
    context.driver.get("http://mys01.fit.vutbr.cz:8057/")

@when("Změní měnu na jinou než aktuálně má")
def step_impl(context):
    button = context.driver.find_element_by_xpath("//span[contains(.,'Currency')]")
    button.click()

    libra = context.driver.find_element_by_xpath("//button[contains(.,'£ Pound Sterling')]")
    libra.click()

@then("Ceny produktů se změní do zvolené měny")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'£481.96')]")
    context.driver.find_element_by_xpath("//*[contains(text(),'£98.63')]")



@given("Uživatel se nachází na nehlavní stránce")
def step_impl(context):
    context.driver.get("http://mys01.fit.vutbr.cz:8057/")
    context.driver.find_element_by_xpath("//span[contains(.,'Shopping Cart')]").click()

@when("Stiskne logo Opencart")
def step_impl(context):
    home = context.driver.find_element_by_xpath("//div/div[@id='logo']")
    home.click()

@then("Uživatel je přesměrován na hlavní stránku")
def step_impl(context):
    context.driver.find_element_by_xpath("//div[@class='owl-item']/div[@class='item']/a/img")



@given("Uživatel se nachází na stránce Contact Us")
def step_impl(context):
    context.driver.get("http://mys01.fit.vutbr.cz:8057/")
    context.driver.find_element_by_xpath("//a[contains(.,'Contact Us')]").click()

@when("Vylpní správně jméno a email")
def step_impl(context):
    context.driver.find_element_by_xpath("//input[@id='input-name']").send_keys("Pavel Dvorak")
    context.driver.find_element_by_xpath("//input[@id='input-email']").send_keys("dvorak@google.com")

@when("Napíše svůj dotaz")
def step_impl(context):
    context.driver.find_element_by_xpath("//textarea[@id='input-enquiry']").send_keys("Dobry den, kdy budou slevy?")

@when("Stiskne tlačítko Submit")
def step_impl(context):
    context.driver.find_element_by_xpath("//div[@class='buttons']/div[@class='pull-right']/input").click()


@then("Uživatel je přesměrován na další stránku Contact Us")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'Your enquiry has been successfully sent to the store owner!')]")