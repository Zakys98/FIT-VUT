from behave import *
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

@given("Uživatel se nachází na stránce konkrétní položky")
def step_impl(context):
    context.driver.get("http://mys01.fit.vutbr.cz:8057/index.php?route=product/product&product_id=40")

@given("Nákupní koš je prázdný")
def step_impl(context):
    context.driver.find_element_by_xpath("//span[contains(text(),'0 item(s) - $0.00')]")

@when("Uživatel přidá položku do koše")
def step_impl(context):
    context.driver.find_element_by_xpath("//button[contains(text(),'Add to Cart')]").click()

@then("Položka se přidá do koše")
def step_impl(context):
    WebDriverWait(context.driver, 5)

@then("Objeví se v koši")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'1 item(s) - $123.20')]")



@given("Nákupní koš je neprázdný")
def step_impl(context):
    context.driver.find_element_by_xpath("//button[contains(text(),'Add to Cart')]").click()
    context.driver.find_element_by_xpath("//*[contains(text(),'1 item(s) - $123.20')]")

@then("Objeví se v koši s dalšími položkami")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'2 item(s) - $246.40')]")



@given("Uživatel se nachází na hlavní stránce webu")
def step_impl(context):
    context.driver.get("http://mys01.fit.vutbr.cz:8057/")

@when("Uživatel přidá položku do koše z hlavní stránky")
def step_impl(context):
    context.driver.find_element_by_xpath("//div[1]/div/div[3]/button").click()

@then("Položka je v koši")
def step_impl(context):
    try:
        context.driver.find_element_by_xpath("//*[contains(text(), '0 item(s) - $0.00')]")
    except:
        pass



@given("Uživatel se nachází na stránce nákupního košíku")
def step_impl(context):
    context.driver.get("http://mys01.fit.vutbr.cz:8057/")
    context.driver.find_element_by_xpath("//div[1]/div/div[3]/button").click()
    context.driver.get("http://mys01.fit.vutbr.cz:8057/index.php?route=checkout/cart")

@given("Uživatel má nějakou položku v koši")
def step_impl(context):
    try:
        context.driver.find_element_by_xpath("//*[contains(text(), '0 item(s) - $0.00')]")
    except:
        pass

@when("Uživatel zadá do textováho pole nevalidní kód kupónu")
def step_impl(context):
    context.driver.find_element_by_xpath("//div/div[1]/div[1]/h4/a").click()
    WebDriverWait(context.driver, 5)
    context.driver.find_element_by_xpath("//div/div[1]/div[2]/div/div/input").send_keys("asdada")

@when("Stiskne tlačítko Apply Coupon")
def step_impl(context):
    context.driver.find_element_by_xpath("//div/div[1]/div[2]/div/div/span").click()

@then("Stránka vypíše chybovou hlášku nevalidního kupón kódu")
def step_impl(context):
    WebDriverWait(context.driver, 5)
    context.driver.find_element_by_xpath("//*[contains(text(), 'Warning: Coupon is either invalid, expired or reached its usage limit!')]")



@when("Uživatel zadá do textováho pole špatný dárkový kód")
def step_impl(context):
    context.driver.find_element_by_xpath("//div/div[2]/div[1]/h4/a").click()
    WebDriverWait(context.driver, 5)
    context.driver.find_element_by_xpath("//div/div[2]/div[2]/div/div/input").send_keys("asdada")

@when("Stiskne tlačítko Apply Gift Certificate")
def step_impl(context):
    context.driver.find_element_by_xpath("//div/div[2]/div[2]/div/div/span").click()

@then("Stránka vypíše chybovou hlášku nevalidního dárkového kódu")
def step_impl(context):
    WebDriverWait(context.driver, 5)
    context.driver.find_element_by_xpath("//*[contains(text(), 'Warning: Gift Certificate is either invalid or the balance has been used up!')]")



@given("Uživatel má nějaké položky v nákupním košíku")
def step_impl(context):
    try:
        context.driver.find_element_by_xpath("//*[contains(text(), '0 item(s) - $0.00')]")
    except:
        pass

@when("Uživatel stiskne tlačítko Checkout")
def step_impl(context):
    context.driver.find_element_by_xpath("//div[@id='content']/div[@class='buttons']/div[@class='pull-right']").click()

@when("Vyplní správně formulář")
def step_impl(context):
    WebDriverWait(context.driver, 15).until(EC.element_to_be_clickable((By.XPATH, "//input[@id='button-payment-address']"))).click()
    WebDriverWait(context.driver, 15).until(EC.element_to_be_clickable((By.XPATH, "//div[@id='collapse-payment-method']/div/div[2]/div/input"))).click()
    context.driver.find_element_by_xpath("//input[@id='button-payment-method']").click()

@when("Potvrdí objednávku")
def step_impl(context):
    WebDriverWait(context, 5)
    context.driver.find_element_by_xpath("//input[@id='button-confirm']").click()

@then("Uživatel je přesměrován na další stránku objednávky")
def step_impl(context):
    WebDriverWait(context.driver, 5)

@then("Objednávka je potvrzená")
def step_impl(context):
    context.driver.find_element_by_xpath("//*[contains(text(),'Your order has been placed!')]")